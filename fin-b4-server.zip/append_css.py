
file_path = r"d:/xampp/htdocs/finatoniq/assets/css/pages.css"

custom_css = """
/* Custom Styles for Investment Solutions Page */
.header.style-absolute {
    background-color: transparent !important;
    position: absolute;
    width: 100%;
    z-index: 1000;
}
.page-title.bg-img-6 {
    background-image: url(../../image/page-title/page-title-home-8.jpg);
    background-size: cover;
    background-position: center center;
    background-repeat: no-repeat;
    position: relative;
    padding-top: 200px;
    padding-bottom: 100px;
}
.page-title.bg-img-6::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(39, 47, 121, 0.8);
    z-index: 0;
}
.page-title .tf-container {
    position: relative;
    z-index: 1;
}
.page-title h2, .page-title .sub-title, .page-title .breadkcum, .page-title .breadkcum a, .page-title .breadkcum span {
    color: #fff !important;
}
.breadkcum .arrow-svg path {
    stroke: #fff !important;
}
"""

try:
    with open(file_path, "a", encoding="utf-8") as f:
        f.write(custom_css)
    print("Successfully appended custom CSS.")
except Exception as e:
    print(f"Error appending CSS: {e}")
