document.addEventListener('DOMContentLoaded', function () {
    console.log("Initializing Custom Scripts...");

    // ==========================================
    // 1. BOOTSTRAP COMPONENTS
    // ==========================================
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl)
    });

    var popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'))
    var popoverList = popoverTriggerList.map(function (popoverTriggerEl) {
        return new bootstrap.Popover(popoverTriggerEl)
    });

    // Manually initialize tabs if they don't work automatically
    var tabTriggerList = [].slice.call(document.querySelectorAll('a[data-bs-toggle="tab"]'))
    tabTriggerList.forEach(function (tabTriggerEl) {
        var tab = new bootstrap.Tab(tabTriggerEl)
        tabTriggerEl.addEventListener('click', function (event) {
            event.preventDefault()
            tab.show()
        })
    });


    // ==========================================
    // 2. SWIPER SLIDERS
    // ==========================================

    // Hero Slider
    if (document.querySelector('.sw-auto')) {
        new Swiper('.sw-auto', {
            slidesPerView: 1,
            loop: true,
            effect: 'fade',
            autoplay: {
                delay: 4000,
                disableOnInteraction: false,
            },
            navigation: {
                nextEl: '.swiper-button-next',
                prevEl: '.swiper-button-prev',
            },
            pagination: {
                el: '.swiper-pagination',
                clickable: true,
            },
        });
    }

    // Success Stories / Case Studies
    const caseStudiesList = document.querySelector('.section-project-inner .sw-case-studies');
    if (caseStudiesList) {
        const projectItems = caseStudiesList.querySelectorAll('.project-item');
        const projectImages = document.querySelectorAll('.list-image-project .image-project');

        if (projectItems.length > 0 && projectImages.length > 0) {

            // Set initial active state if none
            if (!caseStudiesList.querySelector('.project-item.active')) {
                projectItems[0].classList.add('active');
                if (projectImages[0]) projectImages[0].classList.add('active');
            }

            projectItems.forEach((item, index) => {
                // Mouse enter event
                item.addEventListener('mouseenter', () => {
                    // Remove active class from all
                    projectItems.forEach(pi => pi.classList.remove('active'));
                    projectImages.forEach(img => img.classList.remove('active'));

                    // Add active class to current
                    item.classList.add('active');
                    if (projectImages[index]) {
                        projectImages[index].classList.add('active');
                    }
                });
            });
        }
    }

    // Swiper for Testimonials and other .sw-case-studies that are NOT part of the custom list
    var successStories = document.querySelectorAll('.sw-case-studies');
    successStories.forEach(function (el) {
        // Skip if this is the Success Stories vertical list
        if (el.closest('.section-project-inner')) return;

        new Swiper(el, {
            slidesPerView: 1,
            spaceBetween: 30,
            loop: true,
            pagination: {
                el: el.querySelector('.swiper-pagination'),
                clickable: true,
            },
            navigation: {
                nextEl: el.querySelector('.swiper-button-next'),
                prevEl: el.querySelector('.swiper-button-prev'),
            },
            breakpoints: {
                768: {
                    slidesPerView: 2,
                },
                1024: {
                    slidesPerView: 3,
                },
            }
        });
    });

    // Testimonials / Others
    document.querySelectorAll('.sw-new, .swiper-container').forEach(function (el) {
        if (!el.swiper) {
            new Swiper(el, {
                slidesPerView: 1,
                spaceBetween: 30,
                loop: true,
                breakpoints: {
                    768: {
                        slidesPerView: 2,
                    },
                    1024: {
                        slidesPerView: 3,
                    },
                }
            });
        }
    });


    // ==========================================
    // 3. COUNTER ANIMATION
    // ==========================================
    const animateCounter = (el) => {
        const target = parseInt(el.getAttribute('data-count') || el.innerText || "0");
        const duration = 2000; // 2 seconds
        const stepTime = 20;
        const steps = duration / stepTime;
        const increment = target / steps;

        let current = 0;
        const timer = setInterval(() => {
            current += increment;
            if (current >= target) {
                el.innerText = target;
                clearInterval(timer);
            } else {
                el.innerText = Math.floor(current);
            }
        }, stepTime);
    };

    const observerOptions = {
        root: null,
        rootMargin: '0px',
        threshold: 0.1
    };

    const observer = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const el = entry.target;
                animateCounter(el);
                observer.unobserve(el); // Run only once
            }
        });
    }, observerOptions);

    document.querySelectorAll('.odometer').forEach(el => {
        if (el.innerText.trim() === '0' && !el.hasAttribute('data-count')) {
            if (el.closest('.number-counter') && el.closest('.number-counter').querySelector('.plus')) {
                el.setAttribute('data-count', '20');
            } else {
                el.setAttribute('data-count', '95');
            }
        }
        observer.observe(el);
    });

    console.log("All components initialized.");

    // ==========================================
    // 4. BACK TO TOP BUTTON
    // ==========================================
    const scrollTopBtn = document.getElementById('scroll-top');
    if (scrollTopBtn) {
        window.addEventListener('scroll', function () {
            if (window.scrollY > 300) {
                scrollTopBtn.classList.add('show');
            } else {
                scrollTopBtn.classList.remove('show');
            }
        });

        scrollTopBtn.addEventListener('click', function (e) {
            e.preventDefault();
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        });
    }

    // ==========================================
    // 5. STICKY HEADER
    // ==========================================
    const header = document.getElementById('header');
    const headerLogo = document.getElementById('header-logo');

    if (header) {
        window.addEventListener('scroll', function () {
            if (window.scrollY > 100) {
                header.classList.add('is-fixed');
                if (headerLogo) headerLogo.src = 'image/logo.svg';
            } else {
                header.classList.remove('is-fixed');
                if (headerLogo) headerLogo.src = 'image/logo.svg';
            }
        });
    }

    // ==========================================
    // 6. SCROLLSPY & ACTIVE MENU
    // ==========================================
    // Capture default active item on load
    var defaultActive = document.querySelector('.main-menu li.current-menu-item');

    function onScroll(event) {
        var scrollPos = document.documentElement.scrollTop || document.body.scrollTop;
        scrollPos += 150;

        var menuItems = document.querySelectorAll('.main-menu a[href*="#"]');
        var foundMatch = false;

        // 1. Bottom Check (Contact Us / Footer)
        if ((window.innerHeight + (document.documentElement.scrollTop || document.body.scrollTop)) >= document.body.offsetHeight - 50) {
            var footerLink = document.querySelector('.main-menu a[href*="#footer"]');
            if (footerLink) {
                setActive(footerLink);
                foundMatch = true;
            }
        }

        // 2. Loop Check (If not already matched at bottom)
        if (!foundMatch) {
            menuItems.forEach(function (currLink) {
                try {
                    var hash = currLink.getAttribute("href").split('#')[1];
                    var refElement = hash ? document.querySelector('#' + hash) : null;

                    if (refElement) {
                        if (refElement.offsetTop <= scrollPos && (refElement.offsetTop + refElement.offsetHeight) > scrollPos) {
                            setActive(currLink);
                            foundMatch = true;
                        }
                    }
                } catch (e) { }
            });
        }

        // 3. Fallback: If no scroll target matched, restore default active
        if (!foundMatch && defaultActive) {
            clearActive();
            defaultActive.classList.add("current-menu-item");
            // Optional: Restore parent class if needed, but usually handled by CMS/PHP structure
            if (defaultActive.classList.contains('menu-item-has-children')) {
                defaultActive.classList.add('current-menu-parent');
            }
        }
    }

    function clearActive() {
        document.querySelectorAll('.main-menu li').forEach((li) => {
            li.classList.remove("current-menu-item");
            li.classList.remove("current-menu-parent");
        });
    }

    function setActive(link) {
        clearActive();
        link.closest('li').classList.add("current-menu-item");
    }

    window.addEventListener('scroll', onScroll);
    setTimeout(onScroll, 100);

    var menuLinks = document.querySelectorAll('.main-menu a[href*="#"]');
    menuLinks.forEach(function (link) {
        link.addEventListener('click', function () {
            document.querySelectorAll('.main-menu li').forEach((li) => li.classList.remove("current-menu-item"));
            this.closest('li').classList.add("current-menu-item");
            setTimeout(onScroll, 600);
        });
    });

});


// ==========================================
// 7. POPUP LOGIC (Robust Event Delegation)
// ==========================================
document.addEventListener('click', function (e) {
    // Find closest trigger
    const trigger = e.target.closest('.open-popup-trigger');
    if (trigger) {
        e.preventDefault();
        const modalElement = document.getElementById('requestCallModal');

        if (modalElement) {
            // Dynamic Header Update
            const pageTitleEl = document.querySelector('.title-page-title') || document.querySelector('h1');
            const pageTitle = pageTitleEl ? pageTitleEl.innerText.trim() : 'Request a Call';

            const modalTitle = document.getElementById('requestCallModalLabel');
            if (modalTitle) {
                const customTitle = trigger.getAttribute('data-popup-title');
                modalTitle.innerText = customTitle ? customTitle : "Connect With Us";
            }

            // Initialize or Get Bootstrap Modal
            if (typeof bootstrap !== 'undefined') {
                let bsModal = bootstrap.Modal.getInstance(modalElement);
                if (!bsModal) {
                    bsModal = new bootstrap.Modal(modalElement);
                }
                bsModal.show();
            } else {
                console.error("Bootstrap 5 is not loaded or detected.");
            }
        } else {
            console.error("Modal element #requestCallModal not found in DOM.");
        }
    }
});

// Form Validation Logic
const form = document.getElementById('requestCallForm');
if (form) {
    form.addEventListener('submit', function (e) {
        e.preventDefault();

        const mobileInput = document.getElementById('rcMobile');
        const mobileError = document.getElementById('mobileError');
        const mobileValue = mobileInput.value.trim();

        // Strictly 10 digits
        const mobileRegex = /^[0-9]{10}$/;

        if (!mobileRegex.test(mobileValue)) {
            if (mobileError) mobileError.classList.remove('d-none');
            mobileInput.focus();
            return;
        } else {
            if (mobileError) mobileError.classList.add('d-none');
        }

        // Success Action
        alert('Thank you! We will connect with you shortly.');

        // Close Modal
        const modalElement = document.getElementById('requestCallModal');
        if (typeof bootstrap !== 'undefined') {
            const bsModal = bootstrap.Modal.getInstance(modalElement);
            if (bsModal) bsModal.hide();
        }

        form.reset();
    });

    // Global Input Restriction for Mobile Numbers
    document.addEventListener('input', function (e) {
        if (e.target && (
            e.target.matches('input[type="tel"]') ||
            e.target.matches('input[name*="mobile"]') ||
            e.target.matches('input[name*="phone"]') ||
            e.target.matches('input[id*="mobile"]') ||
            e.target.matches('input[id*="phone"]')
        )) {
            e.target.value = e.target.value.replace(/[^0-9]/g, '').substring(0, 10);
        }
    });
}