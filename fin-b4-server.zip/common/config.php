<?php
// Define the Base URL
// Change this to your live domain when uploading to the server
// Example: $base_url = "https://www.yourdomain.com/";

 $base_url = "https://finatoniq.com/";

//$base_url = "http://localhost/finatoniq/";
?>