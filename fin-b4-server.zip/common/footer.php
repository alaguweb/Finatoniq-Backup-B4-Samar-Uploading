<footer class="footer" id="footer">
  <div class="tf-container">
    <div class="row">
      <div class="col-12">
        <div class="footer-top">
          <div class="footer-left">
            <div class="logo-footer">
              <a class="logo" href="<?php echo $base_url; ?>">
                <img src="image/logo.svg" alt="Finatoniq Logo">
              </a>
            </div>
            <div class="text caption-1">
            </div>
            <div class="contact-footer">
              <div class="address contact-top contact-footer-content">
                <p class="caption-2">Our address</p>
                <a href="#">No. 86, 1<sup>st</sup> Cross Rd, Vysya Bank Colony, <br/> Stage 2, BTM Layout, Bengaluru,<br/>
                  Karnataka - 560076</a>
              </div>
              <div class="contact-bottom">

                <div class="contact-footer-content">
                  <p class="caption-2">Email Address</p>
                  <a href="#">connect@finatoniq.com</a>
                </div>
              </div>
            </div>
          </div>
          <div class="footer-center" style="flex-direction: column; gap: 20px; max-width: 100%;">
            <div style="display: flex; gap: 47px; flex-wrap: nowrap; justify-content: center;">
              <div class="footer-content our-services footer-col-block">

                <!--
                      <div class="title-mobile label text-btn-uppercase">Categories<i class="icon-arrow-51">
                        </i>
                      </div>
                    -->
                <div class="tf-collapse-content">
                  <ul>
                    <li class="support-item-footer caption-1">
                      <a href="javascript:void(0);" class="open-popup-trigger" data-popup-title="Partner With Us">
                        Partner with Finatoniq</a>
                    </li>


                  </ul>
                </div>




              </div>
              <div class="footer-content our-services footer-col-block">
                <!--
                      <div class="title-mobile label text-btn-uppercase">Quick Links<i class="icon-arrow-51">
                        </i>
                      </div>
                    -->
                <div class="tf-collapse-content">
                  <ul>
                    <li class="support-item-footer caption-1">
                      <a href="javascript:void(0);" class="open-popup-trigger"
                        data-popup-title="Connect With Us">Connect
                        for Discussion </a>
                    </li>

                  </ul>

                </div>
              </div>
            </div>
            <div class="footer-content footer-col-block">
              <ul class="tf-social style-border radius-50 g-8 style-2" style="justify-content: center;">

                <li class="item">
                  <a href="#">
                    <div class="icon">
                      <i class="icon-x">
                      </i>
                    </div>
                  </a>
                </li>
                <li class="item">
                  <a href="#">
                    <div class="icon">
                      <i class="icon-ig1">
                      </i>
                    </div>
                  </a>
                </li>

              </ul>
            </div>
          </div>


        </div>
      </div>
    </div>
  </div>
  <div class="footer-bottom">
    <div class="tf-container">
      <div class="row">
        <div class="col-12">
          <div class="footer-bottom-inner">
            <div class="left">
              <div class="text caption-1">&copy; 2026 Finatoniq. All Rights Reserved.</div>
            </div>
            <div class="right">
              <ul>
                <li>
                  <a href="#" class="caption-1">Terms Of Services</a>
                </li>
                <li>
                  <a href="#" class="caption-1">Privacy Policy</a>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <a id="scroll-top" class="scroll-top" href="javascript:void(0);">
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M12 19V5" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
      <path d="M5 12L12 5L19 12" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
    </svg>
  </a>
</footer>