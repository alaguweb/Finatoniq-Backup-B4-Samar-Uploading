</div>
<?php include 'common/offcanvas.php'; ?>
<script src="assets/js/bootstrap.bundle.min.js"></script>
<script src="assets/js/swiper-bundle.min.js"></script>
<script src="assets/js/main.js"></script>
</body>

</html>

<!-- Request Call Popup Modal -->
<div class="modal fade" id="requestCallModal" tabindex="-1" aria-labelledby="requestCallModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="requestCallModalLabel">Request a Call</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form id="requestCallForm" class="contact-form">
          <div class="row">
            <div class="col-md-6 mb-3">
              <label for="rcName" class="form-label">Name <span class="text-danger">*</span></label>
              <input type="text" class="form-control" id="rcName" required placeholder="Your Full Name">
            </div>
            <div class="col-md-6 mb-3">
              <label for="rcCompany" class="form-label">Company Name <span class="text-danger">*</span></label>
              <input type="text" class="form-control" id="rcCompany" required placeholder="Your Company">
            </div>
          </div>
          <div class="row">
            <div class="col-md-6 mb-3">
              <label for="rcEmail" class="form-label">Email <span class="text-danger">*</span></label>
              <input type="email" class="form-control" id="rcEmail" required placeholder="name@company.com">
            </div>
            <div class="col-md-6 mb-3">
              <label for="rcMobile" class="form-label">Mobile Number <span class="text-danger">*</span></label>
              <input type="number" class="form-control" id="rcMobile" required placeholder="10-digit Mobile Number"
                maxlength="10"
                oninput="javascript: if (this.value.length > this.maxLength) this.value = this.value.slice(0, this.maxLength);">
              <div class="form-text text-danger d-none" id="mobileError">Please enter a valid 10-digit mobile number.
              </div>
            </div>
          </div>
          <div class="text-center mt-3">
            <button type="submit" class="tf-btn style-1 px-5">Submit</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>