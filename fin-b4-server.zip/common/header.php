<?php include 'common/config.php'; ?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="assets/css/swiper-bundle.min.css">
  <link rel="stylesheet" href="assets/css/bootstrap.min.css">
  <link rel="stylesheet" href="assets/css/vendor.css">
  <link rel="stylesheet" href="assets/css/main.css">
  <link rel="stylesheet" href="assets/css/range-slider.css">
  <link rel="stylesheet" href="assets/css/custom.css">
  <link rel="preload" as="script" fetchpriority="low" href="_next/static/chunks/webpack-76bfa27ec4f3501e.js">
  <script>
    (function () {
      try {
        // Read cookie
        var m = document.cookie.match(/(?:^|; )rtl=([^;]+)/);
        var isRtl = m && decodeURIComponent(m[1]) === 'true';

        // Apply to <html> immediately
        var html = document.documentElement;
        var nextDir = isRtl ? 'rtl' : 'ltr';
        if (html.getAttribute('dir') !== nextDir) html.setAttribute('dir', nextDir);

        // Ensure .rtl class toggled
        if (isRtl) {
          if (!html.classList.contains('rtl')) html.classList.add('rtl');
        } else {
          if (html.classList.contains('rtl')) html.classList.remove('rtl');
        }
      } catch (e) {
        // fail-safe: do nothing
      }
    })();
  </script>
  <link
    href="css2?family=Archivo:ital,wght@0,100..900;1,100..900&amp;family=Geologica:wght@100..900&amp;family=Inter+Tight:ital,wght@0,100..900;1,100..900&amp;family=Kumbh+Sans:wght@100..900&amp;family=Nunito:ital,wght@0,200..1000;1,200..1000&amp;family=Oxygen:wght@300;400;700&amp;family=Rethink+Sans:ital,wght@0,400..800;1,400..800&amp;family=SUSE:wght@100..800&amp;display=swap"
    rel="stylesheet">
  <title>
    <?php echo isset($pageTitle) ? $pageTitle : 'Finatoniq - Modular, scalable, enterprise-ready offerings'; ?>
  </title>
  <meta name="description"
    content="<?php echo isset($pageMetaDesc) ? $pageMetaDesc : 'Finatoniq - Modular, scalable, enterprise-ready offerings'; ?>">
  <?php if (isset($pageUrl)): ?>
    <link rel="canonical" href="<?php echo $pageUrl; ?>" />
    <meta property="og:url" content="<?php echo $pageUrl; ?>" />
  <?php endif; ?>
  <?php if (isset($pageImage)): ?>
    <meta property="og:image" content="<?php echo $pageImage; ?>" />
    <meta name="twitter:image" content="<?php echo $pageImage; ?>" />
    <meta name="twitter:card" content="summary_large_image" />
  <?php endif; ?>
  <link rel="icon" href="image/favicon.png" type="image/x-icon" sizes="40x40">
  <script>document.querySelectorAll('body link[rel="icon"], body link[rel="apple-touch-icon"]').forEach(el => document.head.appendChild(el))</script>
</head>

<body class="counter-scroll popup-loader">
  <div hidden="">
    <!--$-->
    <!--/$-->
  </div>
  <div class="wrapper">