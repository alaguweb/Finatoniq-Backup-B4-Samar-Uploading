<header class="header style-1 <?php echo isset($headerClass) ? $headerClass : 'style-absolute'; ?> header-fixed"
  id="header">
  <div class="tf-container w-1870">
    <div class="row">
      <div class="col-12">
        <div class="header-content">
          <div class="header-left">
            <div class="logo">
              <a href="<?php echo $base_url; ?>">
                <!--
                      <img alt="" loading="lazy" width="169" height="40" decoding="async" data-nimg="1"
                      style="color:transparent" src="image/logo/logo.svg">
                    -->
                <img id="header-logo" alt="" loading="lazy" width="" height="" decoding="async" data-nimg="1"
                  style="color:transparent" src="image/logo.svg">
              </a>
            </div>
            <nav class="main-menu">
              <ul class=" menu-primary-menu  ">
                <li
                  class="menu-item <?php echo (isset($activeMenu) && $activeMenu === 'home') ? 'current-menu-item' : ''; ?>">
                  <a href="<?php echo $base_url; ?>" class="item-link">
                    Home
                  </a>

                </li>

                <li class="menu-item  position-relative">
                  <a href="<?php echo $base_url; ?>index.php#process" class="item-link">Our Approach</a>

                </li>

                <li
                  class="menu-item menu-item-has-children position-relative <?php echo (isset($activeMenu) && $activeMenu === 'verticals') ? 'current-menu-item' : ''; ?>">
                  <a href="#" class="item-link">Our Verticals </a>
                  <ul class="sub-menu">
                    <li class="sub-menu-item   ">
                      <a class="item-link-2" href="<?php echo $base_url; ?>investment-solutions.php">Manufacturers of
                        Investment Solutions</a>
                    </li>
                    <li class="sub-menu-item   ">
                      <a class="item-link-2"
                        href="<?php echo $base_url; ?>intermediation-operating-stack.php">Distribution & RIA Stack</a>
                    </li>
                    <li class="sub-menu-item   ">
                      <a class="item-link-2"
                        href="<?php echo $base_url; ?>corporate-employee-financial-wellness.php">Corporate Employee
                        Financial Wellness</a>
                    </li>
                    <li class="sub-menu-item   ">
                      <a class="item-link-2"
                        href="<?php echo $base_url; ?>education-institutional-partnerships.php">Education &
                        Institutional Partnerships</a>
                    </li>
                  </ul>
                </li>


                <li
                  class="menu-item <?php echo (isset($activeMenu) && $activeMenu === 'team') ? 'current-menu-item' : ''; ?>">
                  <a class="item-link" href="<?php echo $base_url; ?>team.php">Team</a>
                </li>

                <li class="menu-item    ">
                  <a class="item-link " href="<?php echo $base_url; ?>index.php#footer">Contact Us</a>
                </li>


              </ul>
            </nav>
          </div>
          <div class="header-right">
            <!--
                <div class="nav-btn">
                  <a class="tf-btn bg-white style-1 hover-bg-primary" href="contact-us.html">
                    <span>Schedule A Consultation</span>
                  </a>
                </div>
                -->
            <div class="nav-icon">


              <div class="canvas-btn">
                <a href="#canvasMegamenu" data-bs-toggle="offcanvas">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewbox="0 0 24 24" fill="none">
                    <path d="M4 6H20.5" stroke="white" stroke-width="1.5" stroke-linecap="round"
                      stroke-linejoin="round">
                    </path>
                    <path d="M4 12H16" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
                    </path>
                    <path d="M4 18L17.9647 18" stroke="white" stroke-width="1.5" stroke-linecap="round"
                      stroke-linejoin="round">
                    </path>
                  </svg>
                </a>
              </div>
              <div class="mobile-button">
                <a href="#canvasMobile" data-bs-toggle="offcanvas">
                  <span>
                  </span>
                  <span>
                  </span>
                  <span>
                  </span>
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</header>