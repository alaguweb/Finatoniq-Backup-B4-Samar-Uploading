<!-- Offcanvas Mobile Menu (Left) -->
<div class="offcanvas offcanvas-start" tabindex="-1" id="canvasMobile" aria-labelledby="canvasMobileLabel">
    <div class="offcanvas-header border-bottom">
        <h5 class="offcanvas-title" id="canvasMobileLabel">Menu</h5>
        <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
    </div>
    <div class="offcanvas-body">
        <div class="mobile-menu-wrapper">
            <nav class="mobile-main-menu">
                <ul class="nav flex-column gap-2">
                    <li class="nav-item">
                        <a class="nav-link text-dark fw-bold" href="<?php echo $base_url; ?>">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-dark fw-bold" href="<?php echo $base_url; ?>index.php#process">Our
                            Approach</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-dark fw-bold d-flex justify-content-between align-items-center" href="#"
                            role="button" data-bs-toggle="collapse" data-bs-target="#mobileVerticals"
                            aria-expanded="false">
                            Our Verticals
                            <svg width="12" height="12" viewBox="0 0 12 12" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <path d="M2.25 4.5L6 8.25L9.75 4.5" stroke="currentColor" stroke-width="1.5"
                                    stroke-linecap="round" stroke-linejoin="round" />
                            </svg>
                        </a>
                        <div class="collapse" id="mobileVerticals">
                            <ul class="nav flex-column ms-3 mt-2 gap-2">
                                <li class="nav-item"><a class="nav-link text-secondary"
                                        href="<?php echo $base_url; ?>investment-solutions.php">Investment Solutions
                                        Manufacturers</a></li>
                                <li class="nav-item"><a class="nav-link text-secondary"
                                        href="<?php echo $base_url; ?>intermediation-operating-stack.php">Intermediation
                                        Operating Stack</a></li>
                                <li class="nav-item"><a class="nav-link text-secondary"
                                        href="<?php echo $base_url; ?>corporate-employee-financial-wellness.php">Corporate
                                        Employee
                                        Financial Wellness</a></li>
                                <li class="nav-item"><a class="nav-link text-secondary"
                                        href="<?php echo $base_url; ?>education-institutional-partnerships.php">Education
                                        &
                                        Institutional Partnerships</a></li>
                            </ul>
                        </div>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-dark fw-bold" href="<?php echo $base_url; ?>index.php#footer">Contact
                            Us</a>
                    </li>
                </ul>
            </nav>

            <div class="mt-4 pt-4 border-top">
                <h6 class="mb-3">Contact Info</h6>
                <div class="d-flex flex-column gap-2 text-secondary">
                    <!-- <div><i class="icon-PhoneCall me-2"></i> +91-1234567890</div> -->
                    <div><i class="icon-Envelope me-2"></i> connect@finatoniq.com</div>
                    <!-- <div><i class="icon-MapPin me-2"></i> Bangalore</div> -->
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Offcanvas Mega Menu / Side Bar (Right) -->
<div class="offcanvas offcanvas-end" tabindex="-1" id="canvasMegamenu" aria-labelledby="canvasMegamenuLabel">
    <div class="offcanvas-header">
        <h5 class="offcanvas-title" id="canvasMegamenuLabel">
            <a href="<?php echo $base_url; ?>" class="d-block">
                <h4> FINATONIQ VENTURES PRIVATE LIMITED </h4>
            </a>
        </h5>
        <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
    </div>
    <div class="offcanvas-body">
        <div class="mb-4">
            <p class="text-secondary">
                <i>Structured Financial Intelligence. Behaviour-Led Outcomes. Experts led empowerment</i>
            </p>
            <p>
                Finatoniq Ventures Private Limited is a financial intelligence and engagement firm, a practice
                management thought inspired company
                founded by <b> senior industry professionals </b> with deep experience across asset management, wealth
                advisory, fintech, banking, consulting, training, and education.
            </p>
            <p>
                We operate at the intersection of <b> behavioural finance, risk intelligence, technology platforms, and
                    expert-led human intervention </b> — enabling financial ecosystems to move from <b> transaction-led
                    models to
                    outcome-oriented engagement.</b>
            </p>
        </div>


    </div>
</div>