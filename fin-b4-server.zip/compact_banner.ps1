
$css = @"

/* Compact styling for Investment Solutions Banner */
.page-title.bg-img-6 {
    padding-top: 130px !important;
    padding-bottom: 60px !important;
}

.page-title.bg-img-6 h2.title-page-title {
    font-size: 42px !important;
    line-height: 1.2 !important;
    margin-bottom: 10px !important;
}

.page-title.bg-img-6 .sub-title {
    font-size: 16px !important;
    line-height: 24px !important;
    max-width: 800px;
    margin-top: 0 !important;
}

.page-title.bg-img-6 .breadkcum {
    margin-bottom: 10px !important;
}
"@

Add-Content -Path "d:/xampp/htdocs/finatoniq/assets/css/pages.css" -Value $css
Write-Output "Compact banner styles appended to pages.css."
