<?php
include 'common/config.php';

$pageTitle = "Corporate Employee Financial Wellness - Finatoniq";
$pageMetaDesc = "Holistic financial wellbeing programs designed to reduce stress and improve decision-making at the workplace.";
$pageUrl = $base_url . "corporate-employee-financial-wellness.php";
$pageImage = $base_url . "assets/images/logo/logo.png";
$activeMenu = 'verticals';

// Layout Configuration
$showTopBar = true; // Sample has top bar
$headerClass = 'style-absolute'; // Sample has absolute header

include 'common/header.php';
include 'common/menu.php';
?>


<link rel="stylesheet" href="assets/css/pages.css">
<link rel="stylesheet" href="assets/css/innerpage.css">

<!-- Page Title / Banner -->
<div class="page-title style-1 bg-img-6">
    <div class="tf-container">
        <div class="page-title-content">
            <div class="breadkcum">
                <a class="caption-1 home" href="<?php echo $base_url; ?>">Homepage</a>

                <span class="arrow-svg">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                        <g clip-path="url(#clip0_9360_28061)">
                            <path d="M3.125 10H16.875" stroke="#A2A3AB" stroke-linecap="round" stroke-linejoin="round">
                            </path>
                            <path d="M11.25 4.375L16.875 10L11.25 15.625" stroke="#A2A3AB" stroke-linecap="round"
                                stroke-linejoin="round"></path>
                        </g>
                    </svg>
                </span>

            </div>
            <h2 class="title-page-title">Corporate Employee Financial Wellness</h2>
            <div class="sub-title body-2">

                Financial clarity. Better decisions. Healthier employees.
            </div>
        </div>
    </div>
</div>






<div class="main-content inner">
    <div class="tf-container tf-spacing-2">
        <div class="row rg-60">
            <div class="col-lg-12">
                <div class="tab-content">
                    <div class="tab-pane active show" id="tab-1" role="tabpanel">
                        <div class="service-details-content">

                            <div class="detalis-content mb-60" id="menu-sidebar-1">
                                <h4 class="title-content mb-16">Whom Is This For ?</h4>

                                <ul class="menu-sidebar-tab no-tabs">
                                    <li class="nav-tab-item list-menu-item title"> HR Leaders</li>
                                    <li class="nav-tab-item list-menu-item title"> Corporate Management</li>
                                    <li class="nav-tab-item list-menu-item title"> Employee Engagement Teams</li>
                                </ul>

                            </div>



                        <!--

                            <div class="detalis-content mb-60" id="menu-sidebar-4">
                                <h4 class="title-content mb-20">Program Components</h4>
                                <div class="wg-according" id="According1">
                                    <div class="according-item style-arrow style-small">
                                        <h6><a href="#according1" data-bs-toggle="collapse"
                                                class="title-according collapsed">Personal Finance Profiler <i
                                                    class="icon-chevron-down"></i></a></h6>
                                        <div id="according1" class="collapse" data-bs-parent="#According1">
                                            <div class="according-content">
                                                <p>Confidential assessment to help employees understand financial health
                                                    and gaps.</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="according-item style-arrow style-small">
                                        <h6><a href="#according2" data-bs-toggle="collapse"
                                                class="title-according collapsed">Six Expert-Led Webinars (Annual
                                                Program)<i class="icon-chevron-down"></i></a></h6>
                                        <div id="according2" class="collapse" data-bs-parent="#According1">
                                            <div class="according-content">

                                                <ul>
                                                    <li>
                                                        <i class="icon-checkbox"></i>
                                                        Holistic personal finance framework
                                                    </li>

                                                    <li>
                                                        <i class="icon-checkbox"></i>
                                                        Understanding investment opportunities
                                                    </li>

                                                    <li>
                                                        <i class="icon-checkbox"></i>
                                                        Practical wealth creation
                                                    </li>







                                                    <li>
                                                        <i class="icon-checkbox"></i>
                                                        Life insurance essentials
                                                    </li>

                                                    <li>
                                                        <i class="icon-checkbox"></i>
                                                        Health & general insurance
                                                    </li>

                                                    <li>
                                                        <i class="icon-checkbox"></i>
                                                        Taxation basics & will writing
                                                    </li>




                                                </ul>

                                            </div>
                                        </div>
                                    </div>
                                    <div class="according-item style-arrow style-small">
                                        <h6>
                                            <a href="#according3" data-bs-toggle="collapse"
                                                class="title-according collapsed">
                                                Behavioural Finance Profiler <i class="icon-chevron-down"></i>
                                            </a>
                                        </h6>
                                        <div id="according3" class="collapse" data-bs-parent="#According1">
                                            <div class="according-content">
                                                <p>Identifies money habits, biases, and emotional triggers.</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="according-item style-arrow style-small">
                                        <h6><a href="#according4" data-bs-toggle="collapse"
                                                class="title-according collapsed">Employee and HR Dashboard<i
                                                    class="icon-chevron-down"></i></a></h6>
                                        <div id="according4" class="collapse" data-bs-parent="#According1">
                                            <div class="according-content">
                                                <p>A dashboard to check progress for employees and for HR to track
                                                    relevant data points on program implementation progress.</p>
                                            </div>
                                        </div>
                                    </div>



                                    <div class="according-item style-arrow style-small">
                                        <h6><a href="#according5" data-bs-toggle="collapse"
                                                class="title-according collapsed">Tools Corner<i
                                                    class="icon-chevron-down"></i></a></h6>
                                        <div id="according5" class="collapse" data-bs-parent="#According1">
                                            <div class="according-content">
                                                <p>Self-service calculators for SIPs, goals, retirement, and insurance
                                                    needs.</p>
                                            </div>
                                        </div>
                                    </div>



                                    <div class="according-item style-arrow style-small">
                                        <h6><a href="#according6" data-bs-toggle="collapse"
                                                class="title-according collapsed">Mutual Fund Peer Group Education<i
                                                    class="icon-chevron-down"></i></a></h6>
                                        <div id="according6" class="collapse" data-bs-parent="#According1">
                                            <div class="according-content">
                                                <p>Simplified performance comparisons focused on long-term
                                                    understanding.</p>
                                            </div>
                                        </div>
                                    </div>







                                </div>
                            </div>

                        -->
                        
                        <div class="detalis-content mb-60" id="menu-sidebar-4">
                            <h4 class="title-content mb-20">Program Components</h4>
                        
                            <div class="wg-according">
                        
                                <div class="according-item style-arrow style-small">
                                    <h6 class="title-according">
                                        Personal Finance Profiler
                                    </h6>
                                    <div class="according-content">
                                        <p>
                                            Confidential assessment to help employees understand financial health
                                            and gaps.
                                        </p>
                                    </div>
                                </div>
                        
                                <div class="according-item style-arrow style-small">
                                    <h6 class="title-according">
                                        Six Expert-Led Webinars (Annual Program)
                                    </h6>
                                    <div class="according-content">
                                        <ul>
                                            <li>
                                                <i class="icon-checkbox"></i>
                                                Holistic personal finance framework
                                            </li>
                                            <li>
                                                <i class="icon-checkbox"></i>
                                                Understanding investment opportunities
                                            </li>
                                            <li>
                                                <i class="icon-checkbox"></i>
                                                Practical wealth creation
                                            </li>
                                            <li>
                                                <i class="icon-checkbox"></i>
                                                Life insurance essentials
                                            </li>
                                            <li>
                                                <i class="icon-checkbox"></i>
                                                Health & general insurance
                                            </li>
                                            <li>
                                                <i class="icon-checkbox"></i>
                                                Taxation basics & will writing
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                        
                                <div class="according-item style-arrow style-small">
                                    <h6 class="title-according">
                                        Behavioural Finance Profiler
                                    </h6>
                                    <div class="according-content">
                                        <p>
                                            Identifies money habits, biases, and emotional triggers.
                                        </p>
                                    </div>
                                </div>
                        
                                <div class="according-item style-arrow style-small">
                                    <h6 class="title-according">
                                        Employee and HR Dashboard
                                    </h6>
                                    <div class="according-content">
                                        <p>
                                            A dashboard for employees to track progress and for HR to monitor
                                            relevant data points on program implementation.
                                        </p>
                                    </div>
                                </div>
                        
                                <div class="according-item style-arrow style-small">
                                    <h6 class="title-according">
                                        Tools Corner
                                    </h6>
                                    <div class="according-content">
                                        <p>
                                            Self-service calculators for SIPs, goals, retirement, and insurance
                                            needs.
                                        </p>
                                    </div>
                                </div>
                        
                                <div class="according-item style-arrow style-small">
                                    <h6 class="title-according">
                                        Mutual Fund Peer Group Education
                                    </h6>
                                    <div class="according-content">
                                        <p>
                                            Simplified performance comparisons focused on long-term
                                            understanding.
                                        </p>
                                    </div>
                                </div>
                        
                            </div>
                        </div>



                            <div class="detalis-content mb-30" id="menu-sidebar-3">
                                <div class="desc mb-32 body-2 color-on-suface-variant-1"></div>
                                <div class="process-list style-column">

                                    <div class="process-item style-3 style-3-2 open-popup-trigger"
                                        style="cursor: pointer;">
                                        <div class="icon"><i class="icon-Envelope"></i></div>
                                        <div class="circle"></div>
                                        <div class="process-content">
                                            <h5><a href="javascript:void(0);" class="name-process">Connect</a></h5>

                                        </div>
                                    </div>

                                </div>
                            </div>

                        </div>
                    </div>

                </div>
            </div>

        </div>
    </div>
</div>







<?php
include 'common/footer.php';
include 'common/footerfiles.php';
?>