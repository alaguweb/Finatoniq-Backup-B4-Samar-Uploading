<?php
include 'common/config.php';

$pageTitle = "Education & Institutional Partnerships - Finatoniq";
$pageMetaDesc = "Building long-term financial and behavioural intelligence across schools, colleges, and universities.";
$pageUrl = $base_url . "education-institutional-partnerships.php";
$pageImage = $base_url . "assets/images/logo/logo.png";
$activeMenu = 'verticals';

// Layout Configuration
$showTopBar = true; // Sample has top bar
$headerClass = 'style-absolute'; // Sample has absolute header

include 'common/header.php';
include 'common/menu.php';
?>


<link rel="stylesheet" href="assets/css/pages.css">
<link rel="stylesheet" href="assets/css/innerpage.css">

<!-- Page Title / Banner -->
<div class="page-title style-1 bg-img-6">
    <div class="tf-container">
        <div class="page-title-content">
            <div class="breadkcum">
                <a class="caption-1 home" href="<?php echo $base_url; ?>">Homepage</a>

                <span class="arrow-svg">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                        <g clip-path="url(#clip0_9360_28061)">
                            <path d="M3.125 10H16.875" stroke="#A2A3AB" stroke-linecap="round" stroke-linejoin="round">
                            </path>
                            <path d="M11.25 4.375L16.875 10L11.25 15.625" stroke="#A2A3AB" stroke-linecap="round"
                                stroke-linejoin="round"></path>
                        </g>
                    </svg>
                </span>

            </div>
            <h2 class="title-page-title">Education & Institutional Partnerships</h2>
            <div class="sub-title body-2">

                Building financial intelligence for the future
            </div>
        </div>
    </div>
</div>






<div class="main-content inner">
    <div class="tf-container tf-spacing-2">
        <div class="row rg-60">
            <div class="col-lg-12">
                <div class="tab-content">
                    <div class="tab-pane active show" id="tab-1" role="tabpanel">
                        <div class="service-details-content">

                            <div class="detalis-content mb-60" id="menu-sidebar-1">
                                <h4 class="title-content mb-16">Whom Is This For ?</h4>

                                <ul class="menu-sidebar-tab no-tabs">
                                    <li class="nav-tab-item list-menu-item title"> Schools</li>
                                    <li class="nav-tab-item list-menu-item title"> Colleges</li>
                                    <li class="nav-tab-item list-menu-item title"> Universities</li>
                                    <li class="nav-tab-item list-menu-item title"> Education Boards</li>
                                </ul>

                            </div>



                        <!--

                            <div class="detalis-content mb-60" id="menu-sidebar-4">
                                <h4 class="title-content mb-20">Education Offerings</h4>
                                <div class="wg-according" id="According1">
                                    <div class="according-item style-arrow style-small">
                                        <h6><a href="#according1" data-bs-toggle="collapse"
                                                class="title-according collapsed">Behavioural Finance Lab <i
                                                    class="icon-chevron-down"></i></a></h6>
                                        <div id="according1" class="collapse" data-bs-parent="#According1">
                                            <div class="according-content">
                                                <p>Applied learning environment focused on decision psychology and
                                                    financial behaviour.</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="according-item style-arrow style-small">
                                        <h6><a href="#according2" data-bs-toggle="collapse"
                                                class="title-according collapsed">Financial Literacy for Schools<i
                                                    class="icon-chevron-down"></i></a></h6>
                                        <div id="according2" class="collapse" data-bs-parent="#According1">
                                            <div class="according-content">
                                                <p>Age-appropriate programs introducing money basics, saving habits, and
                                                    financial responsibility.</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="according-item style-arrow style-small">
                                        <h6>
                                            <a href="#according3" data-bs-toggle="collapse"
                                                class="title-according collapsed">
                                                Financial Literacy for Colleges <i class="icon-chevron-down"></i>
                                            </a>
                                        </h6>
                                        <div id="according3" class="collapse" data-bs-parent="#According1">
                                            <div class="according-content">
                                                <p>Practical modules on personal finance, investing, and financial
                                                    readiness.</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="according-item style-arrow style-small">
                                        <h6><a href="#according4" data-bs-toggle="collapse"
                                                class="title-according collapsed">University Curriculum for BFSI<i
                                                    class="icon-chevron-down"></i></a></h6>
                                        <div id="according4" class="collapse" data-bs-parent="#According1">
                                            <div class="according-content">
                                                <p>Undergraduate and postgraduate curriculum covering behavioural
                                                    finance, wealth management, risk, and compliance.</p>
                                            </div>
                                        </div>
                                    </div>









                                </div>
                            </div>

                        -->

                            <div class="detalis-content mb-60" id="menu-sidebar-4">
                                <h4 class="title-content mb-20">Education Offerings</h4>
                            
                                <div class="wg-according">
                            
                                    <div class="according-item style-arrow style-small">
                                        <h6 class="title-according">
                                            Behavioural Finance Lab
                                        </h6>
                                        <div class="according-content">
                                            <p>
                                                Applied learning environment focused on decision psychology and
                                                financial behaviour.
                                            </p>
                                        </div>
                                    </div>
                            
                                    <div class="according-item style-arrow style-small">
                                        <h6 class="title-according">
                                            Financial Literacy for Schools
                                        </h6>
                                        <div class="according-content">
                                            <p>
                                                Age-appropriate programs introducing money basics, saving habits,
                                                and financial responsibility.
                                            </p>
                                        </div>
                                    </div>
                            
                                    <div class="according-item style-arrow style-small">
                                        <h6 class="title-according">
                                            Financial Literacy for Colleges
                                        </h6>
                                        <div class="according-content">
                                            <p>
                                                Practical modules on personal finance, investing, and financial
                                                readiness.
                                            </p>
                                        </div>
                                    </div>
                            
                                    <div class="according-item style-arrow style-small">
                                        <h6 class="title-according">
                                            University Curriculum for BFSI
                                        </h6>
                                        <div class="according-content">
                                            <p>
                                                Undergraduate and postgraduate curriculum covering behavioural
                                                finance, wealth management, risk, and compliance.
                                            </p>
                                        </div>
                                    </div>
                            
                                </div>
                            </div>

                            <div class="detalis-content mb-30" id="menu-sidebar-3">
                                <div class="desc mb-32 body-2 color-on-suface-variant-1"></div>
                                <div class="process-list style-column">

                                    <div class="process-item style-3 style-3-2 open-popup-trigger"
                                        style="cursor: pointer;">
                                        <div class="icon"><i class="icon-Envelope"></i></div>
                                        <div class="circle"></div>
                                        <div class="process-content">
                                            <h5><a href="javascript:void(0);" class="name-process">Connect</a></h5>

                                        </div>
                                    </div>

                                </div>
                            </div>

                        </div>
                    </div>

                </div>
            </div>

        </div>
    </div>
</div>







<?php
include 'common/footer.php';
include 'common/footerfiles.php';
?>