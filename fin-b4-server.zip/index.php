<?php
include 'common/config.php';

$pageTitle = "Finatoniq - Structured Financial Intelligence. Behavior-Led Outcomes";
$pageMetaDesc = "We design financial ecosystems that think better, behave better, and perform better by integrating Behavioral finance & risk intelligence, market & business Knowledge, technology-led customer insights & expert-led engagement";
$pageUrl = $base_url;
$pageImage = $base_url . "image/meta.png";
$activeMenu = 'home';

include 'common/header.php';
include 'common/menu.php';
?>



<div class="page-title-home img-1 style-absolute">
  <div class="page-title-inner" style="background-image: url('image/banner1.svg');">
    <div class="tf-container">
      <div class="row">
        <div class="col-12">
          <div class="page-title-content">
            <h1 class="">Structured Financial Intelligence. Behavior-Led
              Outcomes</h1>
            <div class="sub-title body-2"> We design financial ecosystems that <b><i>
                  think better, behave better, and perform better </i> </b> by integrating Behavioral
              finance & risk intelligence, market & business Knowledge, technology-led customer insights & expert-led
              engagement.
            </div>

            <div class="btn-row">
              <a class="tf-btn style-1 bg-white" href="#services">
                <span> Explore Our Solutions</span>
              </a>
              <a class="tf-btn style-1 bg-white open-popup-trigger" href="javascript:void(0);"
                data-popup-title="Connect With Us">
                <span> Speak to Our Experts</span>
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="main-content">
  <section class="section-about h-1 tf-spacing-2 section-one-page aboutspacing" id="about">
    <div class="tf-container">
      <div class="row">
        <div class="col-lg-12">
          <div class="heading-section">
            <!--
                  <div class="text-anime-wave">
                    <a href="#" class="tag label text-btn-uppercase">WE ARE FinWice</a>
                  </div>

                  <a class="tf-btn style-1 bg-on-suface-container" href="about-us.html">
                    <span> About Us </span>
                  </a>
                -->

            <h3 class="text-color-change mb-40">The Problem We Solve
            </h3>
            <p class="font2">
              Rapid Growth in Customers onboarding products of wealth creation, calls for review of existing practice
              and provide enhanced solutions
            </p>
          </div>
        </div>

      </div>
    </div>
  </section>
  <section class="section-benefit h-1 tf-spacing-3 section-one-page benefitspage" id="benefit">
    <div class="tf-container">
      <div class="row">
        <div class="col-12">
          <div class="box-icon-list">
            <div class="box-icon">
              <div class="icon wow fadeInUp">
                <i class="icon-tailored">
                </i>
              </div>
              <div class="box-content">
                <h5 class="wow fadeInUp">
                  <a class="title-box">
                    <!-- --> Behavior Insight powered advice <!-- -->
                  </a>
                </h5>
                <div class="sub-title wow fadeInUp">
                </div>
              </div>
            </div>
            <div class="box-icon">
              <div class="icon wow fadeInUp" data-wow-delay=".1s">
                <i class="icon-investment">
                </i>
              </div>
              <div class="box-content">
                <h5 class="wow fadeInUp" data-wow-delay=".1s">
                  <a href="#" class="title-box">
                    <!-- --> Holistic Personal Finance Centric approach<!-- -->
                  </a>
                </h5>
                <div class="sub-title wow fadeInUp" data-wow-delay=".1s">
                </div>
              </div>
            </div>
            <div class="box-icon">
              <div class="icon wow fadeInUp" data-wow-delay=".2s">
                <i class="icon-financial">
                </i>
              </div>
              <div class="box-content">
                <h5 class="wow fadeInUp" data-wow-delay=".2s">
                  <a href="#" class="title-box">
                    <!-- -->Enhanced Client & Team Engagement<!-- -->
                  </a>
                </h5>
                <div class="sub-title wow fadeInUp" data-wow-delay=".2s">
                </div>
              </div>
            </div>
            <div class="box-icon">
              <div class="icon wow fadeInUp" data-wow-delay=".3s">
                <i class="icon-tax">
                </i>
              </div>
              <div class="box-content">
                <h5 class="wow fadeInUp" data-wow-delay=".3s">
                  <a href="#" class="title-box">
                    <!-- --> Improve Investor stickiness <!-- -->
                  </a>
                </h5>
                <div class="sub-title wow fadeInUp" data-wow-delay=".3s">
                </div>
              </div>
            </div>


            <div class="box-icon">
              <div class="icon wow fadeInUp" data-wow-delay=".2s">
                <i class="icon-operational-efficiency"></i>
              </div>
              <div class="box-content">
                <h5 class="wow fadeInUp" data-wow-delay=".2s">
                  <a href="#" class="title-box">
                    <!-- --> Improved reach and connect<!-- -->
                  </a>
                </h5>
                <div class="sub-title wow fadeInUp" data-wow-delay=".2s">
                </div>
              </div>
            </div>
            <div class="box-icon">
              <div class="icon wow fadeInUp" data-wow-delay=".3s">
                <i class="icon-regulatory"></i>
              </div>
              <div class="box-content">
                <h5 class="wow fadeInUp" data-wow-delay=".3s">
                  <a href="#" class="title-box">
                    <!-- --> Rising compliance and suitability risks<!-- -->
                  </a>
                </h5>
                <div class="sub-title wow fadeInUp" data-wow-delay=".3s">
                </div>
              </div>
            </div>

          </div>
        </div>

        <div class="col-12 addcontents">
          <p>
            <b> Finatoniq exists to provide — </b> Behavioral, Market and Industry Knowledge based Practice Management
            Solutions
            to all stakeholders of the Wealth Management Ecosystem
          </p>
        </div>
      </div>
    </div>
  </section>




  <section class="section-process h-1 tf-spacing-2 hover-active-step section-one-page processpage" id="process">
    <div class="tf-container">
      <div class="row">
        <div class="col-12">
          <div class="heading-section style-2 mb-40 remvband">
            <div class="left">
              <div class="text-anime-wave">
                <span class="tag label text-btn-uppercase">At Finatoniq, we do not treat Behavior as an
                  afterthought</span>
              </div>
              <h3 class="title-section text-anime-wave">Our Approach</h3>
              <p>Our solutions are built on four foundational pillars: </p>
            </div>

          </div>
        </div>
      </div>
      <div class="row rg-30">
        <div class="col-lg-3 col-sm-6">
          <div class="process-item step-hover">
            <div class="process-top wow fadeInUp">
              <div class="icon wow fadeInUp">
                <svg width="48" height="48" viewbox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <g clip-path="url(#clip0_9360_10043)">
                    <path
                      d="M6.30025 27.2812C5.51922 23.0656 6.26859 18.7096 8.41349 14.9972C10.5584 11.2849 13.9579 8.46011 18.0002 7.03125V20.5312L6.30025 27.2812Z"
                      stroke="#24283E" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
                    </path>
                    <path
                      d="M24 24.0787V6C27.1537 6.00047 30.2519 6.82949 32.9843 8.40405C35.7168 9.9786 37.9876 12.2434 39.5694 14.9717C41.1512 17.7 41.9884 20.796 41.9972 23.9496C42.0061 27.1033 41.1862 30.2039 39.6197 32.941C38.0532 35.6781 35.7951 37.9556 33.0715 39.5454C30.3479 41.1352 27.2544 41.9816 24.1008 41.9997C20.9472 42.0178 17.8442 41.2071 15.1025 39.6487C12.3608 38.0903 10.0766 35.8389 8.47876 33.12L24 24.0787Z"
                      stroke="#24283E" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
                    </path>
                  </g>
                  <defs>
                    <clippath id="clip0_9360_10043">
                      <rect width="48" height="48" fill="white">
                      </rect>
                    </clippath>
                  </defs>
                </svg>
              </div>
              <span class="label text-btn-uppercase wow fadeInUp"> Behavioral Finance & Risk Intelligence </span>
            </div>
            <div class="process-content">
              <h5 class="wow fadeInUp">
                <span class="name-process"> Understanding </span>
              </h5>
              <div class="desc wow fadeInUp">how people actually make decisions basis capacity, tolerance, and
                suitability </div>
            </div>
          </div>
        </div>
        <div class="col-lg-3 col-sm-6">
          <div class="process-item step-hover">
            <div class="process-top wow fadeInUp" data-wow-delay=".1s">
              <div class="icon wow fadeInUp" data-wow-delay=".1s">
                <svg width="48" height="48" viewbox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <g clip-path="url(#clip0_9360_10053)">
                    <path d="M24 43.5V37.5" stroke="#24283E" stroke-width="1.5" stroke-linecap="round"
                      stroke-linejoin="round">
                    </path>
                    <path
                      d="M24 40.5C33.1127 40.5 40.5 33.1127 40.5 24C40.5 14.8873 33.1127 7.5 24 7.5C14.8873 7.5 7.5 14.8873 7.5 24C7.5 33.1127 14.8873 40.5 24 40.5Z"
                      stroke="#24283E" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
                    </path>
                    <path d="M24 4.5V10.5" stroke="#24283E" stroke-width="1.5" stroke-linecap="round"
                      stroke-linejoin="round">
                    </path>
                    <path d="M4.5 24H10.5" stroke="#24283E" stroke-width="1.5" stroke-linecap="round"
                      stroke-linejoin="round">
                    </path>
                    <path d="M43.5 24H37.5" stroke="#24283E" stroke-width="1.5" stroke-linecap="round"
                      stroke-linejoin="round">
                    </path>
                    <path
                      d="M24 30C27.3137 30 30 27.3137 30 24C30 20.6863 27.3137 18 24 18C20.6863 18 18 20.6863 18 24C18 27.3137 20.6863 30 24 30Z"
                      stroke="#24283E" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
                    </path>
                  </g>
                  <defs>
                    <clippath id="clip0_9360_10053">
                      <rect width="48" height="48" fill="white">
                      </rect>
                    </clippath>
                  </defs>
                </svg>
              </div>
              <span class="label text-btn-uppercase wow fadeInUp" data-wow-delay=".1s"> Market & Business Knowledge
              </span>
            </div>
            <div class="process-content">
              <h5 class="wow fadeInUp" data-wow-delay=".1s">
                <span class="name-process">Aligning </span>
              </h5>
              <div class="desc wow fadeInUp" data-wow-delay=".1s"> business & market trends to create positive impact
                for all stake holders
              </div>
            </div>
          </div>
        </div>
        <div class="col-lg-3 col-sm-6">
          <div class="process-item step-hover">
            <div class="process-top wow fadeInUp" data-wow-delay=".2s">
              <div class="icon wow fadeInUp" data-wow-delay=".2s">
                <svg width="48" height="48" viewbox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <g clip-path="url(#clip0_9360_10067)">
                    <path d="M42 39H6V9" stroke="#24283E" stroke-width="1.5" stroke-linecap="round"
                      stroke-linejoin="round">
                    </path>
                    <path d="M37.5 13.5L24 27L18 21L6 33" stroke="#24283E" stroke-width="1.5" stroke-linecap="round"
                      stroke-linejoin="round">
                    </path>
                    <path d="M37.5 21V13.5H30" stroke="#24283E" stroke-width="1.5" stroke-linecap="round"
                      stroke-linejoin="round">
                    </path>
                  </g>
                  <defs>
                    <clippath id="clip0_9360_10067">
                      <rect width="48" height="48" fill="white">
                      </rect>
                    </clippath>
                  </defs>
                </svg>
              </div>
              <span class="label text-btn-uppercase wow fadeInUp" data-wow-delay=".2s"> Technology-led Customer Insights
              </span>
            </div>
            <div class="process-content">
              <h5 class="wow fadeInUp" data-wow-delay=".2s">
                <span class="name-process">We provide </span>
              </h5>
              <div class="desc wow fadeInUp" data-wow-delay=".2s">business growth oriented CRM with a holistic approach
                and one-stop solution
              </div>
            </div>
          </div>
        </div>
        <div class="col-lg-3 col-sm-6">
          <div class="process-item step-hover">
            <div class="process-top wow fadeInUp" data-wow-delay=".3s">
              <div class="icon wow fadeInUp" data-wow-delay=".3s">
                <svg width="48" height="48" viewbox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <g clip-path="url(#clip0_9360_10078)">
                    <path
                      d="M40.5 21V10.5C40.5 10.1022 40.342 9.72064 40.0607 9.43934C39.7794 9.15804 39.3978 9 39 9H9C8.60218 9 8.22064 9.15804 7.93934 9.43934C7.65804 9.72064 7.5 10.1022 7.5 10.5V21C7.5 39 24 43.5 24 43.5C24 43.5 40.5 39 40.5 21Z"
                      stroke="#24283E" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
                    </path>
                    <path d="M16.5 25.5L21 30L31.5 19.5" stroke="#24283E" stroke-width="1.5" stroke-linecap="round"
                      stroke-linejoin="round">
                    </path>
                  </g>
                  <defs>
                    <clippath id="clip0_9360_10078">
                      <rect width="48" height="48" fill="white">
                      </rect>
                    </clippath>
                  </defs>
                </svg>
              </div>
              <span class="label text-btn-uppercase wow fadeInUp" data-wow-delay=".3s"> Expert-Led Engagement
              </span>
            </div>
            <div class="process-content">
              <h5 class="wow fadeInUp" data-wow-delay=".3s">
                <span class="name-process">Human intervention</span>
              </h5>
              <div class="desc wow fadeInUp" data-wow-delay=".3s"> training by industry experts on all relevant aspects
                of wealth creation & management
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="row rg-30 addeddetails">
        <p>
          This allows us to deliver durable financial outcomes, not just short-term performance narratives.
        </p>
      </div>
    </div>
  </section>



  <section class="section-services h-1 tf-spacing-31 bg-surface section-one-page servicespage" id="services">
    <div class="tf-container">
      <div class="row">
        <div class="col-12">
          <div class="heading-section style-2">
            <div class="left">
              <!--
                <div class="text-anime-wave">
                  <a href="#" class="tag label text-btn-uppercase bg-white">Our Services</a>
                </div>
              -->
              <h3 class="title-section text-anime-wave">Our Verticals </h3>
            </div>
            <div class="text-anime-wave-2">
              <a class="tf-btn style-1 bg-on-suface-container" href="#">
                <span> View All </span>
              </a>
            </div>
          </div>
          
          <!--
            <div class="section-services-content">
            <div class="flat-animate-tab">
              <div class="wg-tab">
                <ul class="tab-product min-w-757" role="tablist">
                  <li class="nav-tab-item" role="presentation">
                    <h5>
                      <a href="#investment-solution" data-bs-toggle="tab" role="tab" class="active"> Manufacturers of
                        Investment Solutions</a>
                    </h5>
                  </li>
                  <li class="nav-tab-item" role="presentation">
                    <h5>
                      <a href="#operating-stack" data-bs-toggle="tab" role="tab" class="">Distribution & RIA Stack</a>
                    </h5>
                  </li>
                  <li class="nav-tab-item" role="presentation">
                    <h5>
                      <a href="#financial-wellness" data-bs-toggle="tab" role="tab" class="">Corporate Employee
                        Financial Wellness</a>
                    </h5>
                  </li>
                  <li class="nav-tab-item" role="presentation">
                    <h5>
                      <a href="#education" data-bs-toggle="tab" role="tab" class="">Education & Institutional
                        Partnerships</a>
                    </h5>
                  </li>
                </ul>
              </div>
              <div class="tab-content">
                <div class="tab-pane active show" id="investment-solution" role="tabpanel">
                  <div class="section-services-item">
                    <div class="image">
                      <a class="link" href="#">
                      </a>
                      <img alt="Retirement Planning" loading="lazy" width="585" height="439" decoding="async"
                        data-nimg="1" class="lazyload" style="color:transparent" src="image/page1.webp">
                    </div>
                    <div class="services-content">
                      <div class="heading">
                        <h3>
                          <a class="name-services wow fadeInUp" href="#"> Manufacturers of Investment Solutions</a>
                        </h3>
                        
                      </div>
                      <div class="benefit-lists">
                        <div class="benefit-items">
                          <div class="icon wow fadeInUp">
                            <i class="icon-checkbox">
                            </i>
                          </div>
                          <div class="title wow fadeInUp" data-wow-delay=".1s">For AMCs, PMS providers, and AIF
                            manufacturers seeking deeper investor trust and stronger intermediary engagement.
                          </div>
                        </div>

                      </div>
                      <a class="tf-btn style-1 bg-on-suface-container wow fadeInUp"
                        href="<?php echo $base_url; ?>investment-solutions.php">
                        <span>Explore Manufacturers of Investment Solutions</span>
                      </a>
                    </div>
                  </div>
                </div>
                <div class="tab-pane" id="operating-stack" role="tabpanel">
                  <div class="section-services-item">
                    <div class="image">
                      <a class="link" href="#">
                      </a>
                      <img alt="Investment Advisory" loading="lazy" width="878" height="659" decoding="async"
                        data-nimg="1" class="lazyload" style="color:transparent" src="image/page2.webp">
                    </div>
                    <div class="services-content">
                      <div class="heading">
                        <h3>
                          <a class="name-services wow fadeInUp" href="#">Distribution & RIA Stack</a>
                        </h3>
                        
                      </div>
                      <div class="benefit-lists">
                        <div class="benefit-items">
                          <div class="icon wow fadeInUp">
                            <i class="icon-checkbox">
                            </i>
                          </div>
                          <div class="title wow fadeInUp" data-wow-delay=".1s">For fintechs, wealth firms, banks,
                            MFDs, RIAs, and national distributors aiming to professionalise and scale.
                          </div>
                        </div>

                      </div>
                      <a class="tf-btn style-1 bg-on-suface-container wow fadeInUp"
                        href="<?php echo $base_url; ?>intermediation-operating-stack.php">
                        <span>Explore Distribution & RIA Stack</span>
                      </a>
                    </div>
                  </div>
                </div>
                <div class="tab-pane" id="financial-wellness" role="tabpanel">
                  <div class="section-services-item">
                    <div class="image">
                      <a class="link" href="#">
                      </a>
                      <img alt="Estate Planning" loading="lazy" width="878" height="659" decoding="async" data-nimg="1"
                        class="lazyload" style="color:transparent" src="image/page3.webp">
                    </div>
                    <div class="services-content">
                      <div class="heading">
                        <h3>
                          <a class="name-services wow fadeInUp" href="#">Corporate Employee Financial Wellness</a>
                        </h3>
                        
                      </div>
                      <div class="benefit-lists">
                        <div class="benefit-items">
                          <div class="icon wow fadeInUp">
                            <i class="icon-checkbox">
                            </i>
                          </div>
                          <div class="title wow fadeInUp" data-wow-delay=".1s">Holistic financial wellbeing programs
                            designed to reduce stress and improve decision-making at the workplace.
                          </div>
                        </div>

                      </div>
                      <a class="tf-btn style-1 bg-on-suface-container wow fadeInUp"
                        href="<?php echo $base_url; ?>corporate-employee-financial-wellness.php">
                        <span>Explore Financial Wellness</span>
                      </a>
                    </div>
                  </div>
                </div>
                <div class="tab-pane" id="education" role="tabpanel">
                  <div class="section-services-item">
                    <div class="image">
                      <a class="link" href="#">
                      </a>
                      <img alt="Tax Optimization" loading="lazy" width="878" height="659" decoding="async" data-nimg="1"
                        class="lazyload" style="color:transparent" src="image/page4.webp">
                    </div>
                    <div class="services-content">
                      <div class="heading">
                        <h3>
                          <a class="name-services wow fadeInUp" href="#">Education & Institutional Partnerships</a>
                        </h3>
                        
                      </div>
                      <div class="benefit-lists">
                        <div class="benefit-items">
                          <div class="icon wow fadeInUp">
                            <i class="icon-checkbox">
                            </i>
                          </div>
                          <div class="title wow fadeInUp" data-wow-delay=".1s">Building long-term financial and
                            Behavioral intelligence across schools, colleges, and universities.
                          </div>
                        </div>

                      </div>
                      <a class="tf-btn style-1 bg-on-suface-container wow fadeInUp"
                        href="<?php echo $base_url; ?>education-institutional-partnerships.php">
                        <span>Explore Education</span>
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          -->
          
          
          <!-- new starts --> 
          <section class="services-grid-section">
              <div class="container">
                <div class="row g-4">
            
                  <!-- Card 1 -->
                  <div class="col-xl-3 col-lg-6 col-md-6 col-sm-12">
                    <div class="service-card">
                      <div class="service-image">
                        <img src="image/page1.webp" alt="Manufacturers of Investment Solutions">
                      </div>
                      <div class="service-content">
                        <h4>Manufacturers of Investment Solutions</h4>
                        <p>
                          For AMCs, PMS providers, and AIF manufacturers seeking deeper investor trust and stronger intermediary engagement.
                        </p>
                        <a href="<?php echo $base_url; ?>investment-solutions.php" class="btn-service">
                          Know More
                        </a>
                      </div>
                    </div>
                  </div>
            
                  <!-- Card 2 -->
                  <div class="col-xl-3 col-lg-6 col-md-6 col-sm-12">
                    <div class="service-card">
                      <div class="service-image">
                        <img src="image/page2.webp" alt="Distribution & RIA Stack">
                      </div>
                      <div class="service-content">
                        <h4>Distribution & RIA Stack</h4>
                        <p>
                          For fintechs, wealth firms, banks, MFDs, RIAs, and national distributors aiming to professionalise and scale.
                        </p>
                        <a href="<?php echo $base_url; ?>intermediation-operating-stack.php" class="btn-service">
                          Know More
                        </a>
                      </div>
                    </div>
                  </div>
            
                  <!-- Card 3 -->
                  <div class="col-xl-3 col-lg-6 col-md-6 col-sm-12">
                    <div class="service-card">
                      <div class="service-image">
                        <img src="image/page3.webp" alt="Corporate Employee Financial Wellness">
                      </div>
                      <div class="service-content">
                        <h4>Corporate Employee Financial Wellness</h4>
                        <p>
                          Holistic financial wellbeing programs designed to reduce stress and improve decision-making at the workplace.
                        </p>
                        <a href="<?php echo $base_url; ?>corporate-employee-financial-wellness.php" class="btn-service">
                          Know More
                        </a>
                      </div>
                    </div>
                  </div>
            
                  <!-- Card 4 -->
                  <div class="col-xl-3 col-lg-6 col-md-6 col-sm-12">
                    <div class="service-card">
                      <div class="service-image">
                        <img src="image/page4.webp" alt="Education & Institutional Partnerships">
                      </div>
                      <div class="service-content">
                        <h4>Education & Institutional Partnerships</h4>
                        <p>
                          Building long-term financial and Behavioral intelligence across schools, colleges, and universities.
                        </p>
                        <a href="<?php echo $base_url; ?>education-institutional-partnerships.php" class="btn-service">
                          Know More
                        </a>
                      </div>
                    </div>
                  </div>
            
                </div>
              </div>
            </section>

          <!-- new ends --> 
          
          
          
        </div>
      </div>
    </div>
  </section>



  <section class="section-faqs h-1 tf-spacing-2 section-one-page faqpage" id="faqs">
    <div class="tf-container">
      <div class="row">
        <div class="col-12">
          <div class="section-faqs-inner">

            <div class="">


              <div class="heading-section">
                <!--
                      <div class="text-anime-wave">
                        <a href="#" class="tag label text-btn-uppercase bg-white">FAQs</a>
                      </div>
                    -->
                <h3 class="title-section mb-12 text-anime-wave">Why Finatoniq</h3>
                <div class="sub-title body-2 text-anime-wave mb-40">
                </div>

              </div>


              <!-- 
                      <div class="wg-according" id="According">
                        <div class="according-item">
                          <h5>
                            <a href="#according-1" data-bs-toggle="collapse" class="title-according "> Built by
                              practitioners, not theorists <span>
                              </span>
                            </a>
                          </h5>
                          <div id="according-1" class="collapse show" data-bs-parent="#According">
                            <div class="according-content">
                              <p>
                              </p>
                            </div>
                          </div>
                        </div>
                        <div class="according-item">
                          <h5>
                            <a href="#according-2" data-bs-toggle="collapse" class="title-according collapsed"> Behavioral
                              finance embedded at the core<span>
                              </span>
                            </a>
                          </h5>
                          <div id="according-2" class="collapse " data-bs-parent="#According">
                            <div class="according-content">
                              <p>
                              </p>
                            </div>
                          </div>
                        </div>
                        <div class="according-item">
                          <h5>
                            <a href="#according-3" data-bs-toggle="collapse" class="title-according collapsed"> Technology +
                              people + content under one framework<span>
                              </span>
                            </a>
                          </h5>
                          <div id="according-3" class="collapse" data-bs-parent="#According">
                            <div class="according-content">
                              <p>
                              </p>
                            </div>
                          </div>
                        </div>
                        <div class="according-item">
                          <h5>
                            <a href="#according-4" data-bs-toggle="collapse" class="title-according collapsed">
                              Regulatory-aware design<span>
                              </span>
                            </a>
                          </h5>
                          <div id="according-4" class="collapse" data-bs-parent="#According">
                            <div class="according-content">
                              <p>
                              </p>
                            </div>
                          </div>
                        </div>


                        <div class="according-item">
                          <h5>
                            <a href="#according-5" data-bs-toggle="collapse" class="title-according collapsed"> Modular,
                              scalable, enterprise-ready offerings<span>
                              </span>
                            </a>
                          </h5>
                          <div id="according-5" class="collapse" data-bs-parent="#According">
                            <div class="according-content">
                              <p>
                              </p>
                            </div>
                          </div>
                        </div>

                      </div>

                  -->

              <div class="wg-according no-accordion">
                <div class="according-item">
                  <h5 class="title-according"><i class="icon-CheckCircle"></i>Built by practitioners, not theorists
                  </h5>
                </div>

                <div class="according-item">
                  <h5 class="title-according"><i class="icon-CheckCircle"></i>Behavioral finance embedded at the
                    core</h5>
                </div>

                <div class="according-item">
                  <h5 class="title-according"><i class="icon-CheckCircle"></i>Technology + people + content under
                    one framework</h5>
                </div>

                <div class="according-item">
                  <h5 class="title-according"><i class="icon-CheckCircle"></i>Regulatory-aware design</h5>
                </div>

                <div class="according-item">
                  <h5 class="title-according"><i class="icon-CheckCircle"></i>Modular, scalable, enterprise-ready
                    offerings</h5>
                </div>
              </div>

            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

</div>

<style>
        .services-grid-section {
          padding: 10px 0;
        }
        .services-grid-section .container 
        {
            max-width: 100%;
        }
        .service-card {
          background: #ffffff;
          border-radius: 14px;
          overflow: hidden;
          height: 100%;
          box-shadow: 0 10px 25px rgba(0,0,0,0.08);
          transition: transform 0.3s ease, box-shadow 0.3s ease;
          display: flex;
          flex-direction: column;
        }
        
        .service-card:hover {
          transform: translateY(-8px);
          box-shadow: 0 18px 35px rgba(0,0,0,0.12);
        }
        
        .service-image img {
          width: 100%;
          height: 220px;
          object-fit: cover;
        }
        
        .service-content {
          padding: 20px;
          display: flex;
          flex-direction: column;
          flex-grow: 1;
        }
        
        .btn-service {
          margin-top: auto;
          align-self: flex-start;
          padding: 10px 18px;
          border-radius: 30px;
          background: #1f2a44;
          color: #fff;
          font-size: 14px;
          text-decoration: none;
          transition: background 0.3s ease;
        }
        
        .btn-service:hover {
          background: #0e1730;
          color: #fff;
        }
        
        
        .service-content h4 {
          font-size: 18px;
          font-weight: 600;
          margin-bottom: 6px;   /* ↓ reduced gap */
          line-height: 1.25;    /* tighter heading line spacing */
           
        }
        
        .service-content p {
          font-size: 14px;
          color: #000;          /* paragraph text black */
          line-height: 1.45;    /* slightly tighter for clean look */
          margin-bottom: 16px;  /* reduced spacing below paragraph */
        }

        @media (min-width: 900px) 
        {
          .service-content h4 {
            height: 50px;
            display: flex;
            align-items: center;
            line-height: 1.25;
            margin-bottom: 6px;
          }
        }
        
        @media (max-width: 860px) 
        {
          .service-content h4 { 
              font-size: 24px !important;
              margin-bottom: 15px;
          }
        }
    </style>
<?php

include 'common/footer.php';
include 'common/footerfiles.php';
?>