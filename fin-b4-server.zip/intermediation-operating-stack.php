<?php
include 'common/config.php';

$pageTitle = "Distribution & RIA Stack - Finatoniq";
$pageMetaDesc = "For fintechs, wealth firms, banks, MFDs, RIAs, and national distributors aiming to professionalise and scale.";
$pageUrl = $base_url . "intermediation-operating-stack.php";
$pageImage = $base_url . "assets/images/logo/logo.png";
$activeMenu = 'verticals';

// Layout Configuration
$showTopBar = true; // Sample has top bar
$headerClass = 'style-absolute'; // Sample has absolute header

include 'common/header.php';
include 'common/menu.php';
?>


<link rel="stylesheet" href="assets/css/pages.css">
<link rel="stylesheet" href="assets/css/innerpage.css">

<!-- Page Title / Banner -->
<div class="page-title style-1 bg-img-6">
    <div class="tf-container">
        <div class="page-title-content">
            <div class="breadkcum">
                <a class="caption-1 home" href="<?php echo $base_url; ?>">Homepage</a>

                <span class="arrow-svg">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                        <g clip-path="url(#clip0_9360_28061)">
                            <path d="M3.125 10H16.875" stroke="#A2A3AB" stroke-linecap="round" stroke-linejoin="round">
                            </path>
                            <path d="M11.25 4.375L16.875 10L11.25 15.625" stroke="#A2A3AB" stroke-linecap="round"
                                stroke-linejoin="round"></path>
                        </g>
                    </svg>
                </span>

            </div>
            <h2 class="title-page-title">Distribution & RIA Stack</h2>
            <div class="sub-title body-2">

                Powering the Intermediation Industry
            </div>
        </div>
    </div>
</div>






<div class="main-content inner">
    <div class="tf-container tf-spacing-2">
        <div class="row rg-60">
            <div class="col-lg-12">
                <div class="tab-content">
                    <div class="tab-pane active show" id="tab-1" role="tabpanel">
                        <div class="service-details-content">

                            <div class="detalis-content mb-60" id="menu-sidebar-1">
                                <h4 class="title-content mb-16">Whom Is This For ?</h4>

                                <ul class="menu-sidebar-tab no-tabs">
                                    <li class="nav-tab-item list-menu-item title"> Fintech Platforms</li>
                                    <li class="nav-tab-item list-menu-item title"> Wealth Management Firms</li>
                                    <li class="nav-tab-item list-menu-item title"> Banks</li>
                                </ul>
                                <ul class="menu-sidebar-tab no-tabs additinoal">

                                    <li class="nav-tab-item list-menu-item title"> National Distributors</li>
                                    <li class="nav-tab-item list-menu-item title"> MFDs & RIAs</li>
                                </ul>

                            </div>

                            <div class="detalis-content mb-30" id="menu-sidebar-1">
                                <h4 class="title-content mb-16">What it Enables</h4>
                                <div class="desc mb-16 body-2 color-on-suface-variant-1"><b>We</b> work along with
                                    intermediaries to professionalise operations, deepen client relationships, and scale
                                    responsibly by combining </div>
                                <div class="cols g-10 newinner">
                                    <div class="benefit-lists">
                                        <div class="benefit-items style-small mb-16">
                                            <div class="icon"><i class="icon-checkbox"></i></div>
                                            <div class="title"> Technology</div>
                                        </div>

                                    </div>
                                    <div class="benefit-lists">
                                        <div class="benefit-items style-small mb-16">
                                            <div class="icon"><i class="icon-checkbox"></i></div>
                                            <div class="title"> Consulting </div>
                                        </div>

                                    </div>
                                    <div class="benefit-lists">
                                        <div class="benefit-items style-small mb-16">
                                            <div class="icon"><i class="icon-checkbox"></i></div>
                                            <div class="title"> Training</div>
                                        </div>

                                    </div>
                                </div>
                            </div>


                        <!--
                            <div class="detalis-content mb-60" id="menu-sidebar-4">
                                <h4 class="title-content mb-20"> Offerings Explained</h4>
                                <div class="wg-according" id="According1">
                                    <div class="according-item style-arrow style-small">
                                        <h6><a href="#according1" data-bs-toggle="collapse"
                                                class="title-according collapsed">Business CRM<i
                                                    class="icon-chevron-down"></i></a></h6>
                                        <div id="according1" class="collapse" data-bs-parent="#According1">
                                            <div class="according-content">
                                                <p>Centralised system to manage clients, teams, workflows, and
                                                    engagement history</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="according-item style-arrow style-small">
                                        <h6><a href="#according2" data-bs-toggle="collapse"
                                                class="title-according collapsed">Sales & Service CRM<i
                                                    class="icon-chevron-down"></i></a></h6>
                                        <div id="according2" class="collapse" data-bs-parent="#According1">
                                            <div class="according-content">
                                                <p>Tracks sales activity, meetings, and calls while managing service
                                                    queries through a ticket-based system.</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="according-item style-arrow style-small">
                                        <h6>
                                            <a href="#according3" data-bs-toggle="collapse"
                                                class="title-according collapsed">
                                                Business Growth Consulting <i class="icon-chevron-down"></i>
                                            </a>
                                        </h6>
                                        <div id="according3" class="collapse" data-bs-parent="#According1">
                                            <div class="according-content">
                                                <p>Advisory on business review, practice structuring, client
                                                    segmentation, revenue diversification, business modelling, growth
                                                    enablement and scalability</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="according-item style-arrow style-small">
                                        <h6><a href="#according4" data-bs-toggle="collapse"
                                                class="title-according collapsed">Team Training<i
                                                    class="icon-chevron-down"></i></a></h6>
                                        <div id="according4" class="collapse" data-bs-parent="#According1">
                                            <div class="according-content">
                                                <p>Capability building for sales, relationship, and service teams on all
                                                    aspects of business to empower understanding and enhance client
                                                    engagement</p>
                                            </div>
                                        </div>
                                    </div>



                                    <div class="according-item style-arrow style-small">
                                        <h6><a href="#according5" data-bs-toggle="collapse"
                                                class="title-according collapsed">Investor Engagement Programs<i
                                                    class="icon-chevron-down"></i></a></h6>
                                        <div id="according5" class="collapse" data-bs-parent="#According1">
                                            <div class="according-content">
                                                <p>Client education sessions, market updates, and long-term engagement
                                                    initiatives.</p>
                                            </div>
                                        </div>
                                    </div>



                                    <div class="according-item style-arrow style-small">
                                        <h6><a href="#according6" data-bs-toggle="collapse"
                                                class="title-according collapsed">Content & Communication Design<i
                                                    class="icon-chevron-down"></i></a></h6>
                                        <div id="according6" class="collapse" data-bs-parent="#According1">
                                            <div class="according-content">
                                                <p>Newsletters, blogs, website content, and investor communication
                                                    material.</p>
                                            </div>
                                        </div>
                                    </div>


                                    <div class="according-item style-arrow style-small">
                                        <h6><a href="#according7" data-bs-toggle="collapse"
                                                class="title-according collapsed">Profiling & Assessment Tools<i
                                                    class="icon-chevron-down"></i></a></h6>
                                        <div id="according7" class="collapse" data-bs-parent="#According1">
                                            <div class="according-content">
                                                <p>Personal finance profiling, behavioural assessment, and risk
                                                    profiling for better advice outcomes.</p>
                                            </div>
                                        </div>
                                    </div>







                                </div>
                            </div>
                        -->
                        
                        
                        <div class="detalis-content mb-60" id="menu-sidebar-4">
                            <h4 class="title-content mb-20">Offerings Explained</h4>
                        
                            <div class="wg-according">
                        
                                <div class="according-item style-arrow style-small">
                                    <h6 class="title-according">
                                        Business CRM
                                    </h6>
                                    <div class="according-content">
                                        <p>
                                            Centralised system to manage clients, teams, workflows, and
                                            engagement history.
                                        </p>
                                    </div>
                                </div>
                        
                                <div class="according-item style-arrow style-small">
                                    <h6 class="title-according">
                                        Sales & Service CRM
                                    </h6>
                                    <div class="according-content">
                                        <p>
                                            Tracks sales activity, meetings, and calls while managing service
                                            queries through a ticket-based system.
                                        </p>
                                    </div>
                                </div>
                        
                                <div class="according-item style-arrow style-small">
                                    <h6 class="title-according">
                                        Business Growth Consulting
                                    </h6>
                                    <div class="according-content">
                                        <p>
                                            Advisory on business review, practice structuring, client
                                            segmentation, revenue diversification, business modelling, growth
                                            enablement, and scalability.
                                        </p>
                                    </div>
                                </div>
                        
                                <div class="according-item style-arrow style-small">
                                    <h6 class="title-according">
                                        Team Training
                                    </h6>
                                    <div class="according-content">
                                        <p>
                                            Capability building for sales, relationship, and service teams on all
                                            aspects of business to empower understanding and enhance client
                                            engagement.
                                        </p>
                                    </div>
                                </div>
                        
                                <div class="according-item style-arrow style-small">
                                    <h6 class="title-according">
                                        Investor Engagement Programs
                                    </h6>
                                    <div class="according-content">
                                        <p>
                                            Client education sessions, market updates, and long-term engagement
                                            initiatives.
                                        </p>
                                    </div>
                                </div>
                        
                                <div class="according-item style-arrow style-small">
                                    <h6 class="title-according">
                                        Content & Communication Design
                                    </h6>
                                    <div class="according-content">
                                        <p>
                                            Newsletters, blogs, website content, and investor communication
                                            material.
                                        </p>
                                    </div>
                                </div>
                        
                                <div class="according-item style-arrow style-small">
                                    <h6 class="title-according">
                                        Profiling & Assessment Tools
                                    </h6>
                                    <div class="according-content">
                                        <p>
                                            Personal finance profiling, behavioural assessment, and risk
                                            profiling for better advice outcomes.
                                        </p>
                                    </div>
                                </div>
                        
                            </div>
                        </div>




                            <div class="detalis-content mb-30" id="menu-sidebar-3">
                                <div class="desc mb-32 body-2 color-on-suface-variant-1"></div>
                                <div class="process-list style-column">

                                    <div class="process-item style-3 style-3-2 open-popup-trigger"
                                        style="cursor: pointer;">
                                        <div class="icon"><i class="icon-Envelope"></i></div>
                                        <div class="circle"></div>
                                        <div class="process-content">
                                            <h5><a href="javascript:void(0);" class="name-process">Connect</a></h5>
                                        </div>
                                    </div>

                                </div>
                            </div>

                        </div>
                    </div>

                </div>
            </div>

        </div>
    </div>
</div>







<?php
include 'common/footer.php';
include 'common/footerfiles.php';
?>