<?php
include 'common/config.php';

$pageTitle = "Investment Solutions Manufacturers - Finatoniq";
$pageMetaDesc = "For AMCs, PMS providers, and AIF manufacturers seeking deeper investor trust and stronger intermediary engagement.";
$pageUrl = $base_url . "investment-solutions.php";
$pageImage = $base_url . "assets/images/logo/logo.png";
$activeMenu = 'verticals';

// Layout Configuration
$showTopBar = true; // Sample has top bar
$headerClass = 'style-absolute'; // Sample has absolute header

include 'common/header.php';
include 'common/menu.php';
?>


<link rel="stylesheet" href="assets/css/pages.css">
<link rel="stylesheet" href="assets/css/innerpage.css">

<!-- Page Title / Banner -->
<div class="page-title style-1 bg-img-6">
    <div class="tf-container">
        <div class="page-title-content">
            <div class="breadkcum">
                <a class="caption-1 home" href="<?php echo $base_url; ?>">Homepage</a>

                <span class="arrow-svg">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                        <g clip-path="url(#clip0_9360_28061)">
                            <path d="M3.125 10H16.875" stroke="#A2A3AB" stroke-linecap="round" stroke-linejoin="round">
                            </path>
                            <path d="M11.25 4.375L16.875 10L11.25 15.625" stroke="#A2A3AB" stroke-linecap="round"
                                stroke-linejoin="round"></path>
                        </g>
                    </svg>
                </span>
                <span class="caption-1 page-breadkcum">Investment Solutions Manufacturers</span>
            </div>
            <h2 class="title-page-title">Investment Solutions Manufacturers</h2>
            <div class="sub-title body-2">

                From product distribution to investor conviction
            </div>
        </div>
    </div>
</div>






<div class="main-content">
    <div class="tf-container tf-spacing-2">
        <div class="row rg-60">
            <div class="col-lg-8">
                <div class="tab-content">
                    <div class="tab-pane active show" id="tab-1" role="tabpanel">
                        <div class="service-details-content">
                            <div class="image-details image mb-60"><img alt="" loading="lazy" width="850" height="512"
                                    decoding="async" data-nimg="1" class="lazyload" style="color:transparent"
                                    src="/image/section/img-details-service-1.jpg"></div>
                            <div class="detalis-content mb-60" id="menu-sidebar-1">
                                <h4 class="title-content mb-16">Retirement Planning Solutions</h4>
                                <div class="desc mb-16 body-2 color-on-suface-variant-1">Secure your retirement with our
                                    personalized planning service. We create strategies for steady income, inflation
                                    protection, and optimized growth. Enjoy financial confidence and be prepared for
                                    future needs.</div>
                                <div class="cols g-10">
                                    <div class="benefit-lists">
                                        <div class="benefit-items style-small mb-16">
                                            <div class="icon"><i class="icon-checkbox"></i></div>
                                            <div class="title">Reliable Retirement Income</div>
                                        </div>
                                        <div class="benefit-items style-small mb-16">
                                            <div class="icon"><i class="icon-checkbox"></i></div>
                                            <div class="title">Future Security and Peace of Mind</div>
                                        </div>
                                        <div class="benefit-items style-small">
                                            <div class="icon"><i class="icon-checkbox"></i></div>
                                            <div class="title">Asset Protection for Long-Term Stability</div>
                                        </div>
                                    </div>
                                    <div class="benefit-lists">
                                        <div class="benefit-items style-small mb-16">
                                            <div class="icon"><i class="icon-checkbox"></i></div>
                                            <div class="title">Reliable Income for Retirement</div>
                                        </div>
                                        <div class="benefit-items style-small mb-16">
                                            <div class="icon"><i class="icon-checkbox"></i></div>
                                            <div class="title">Personalized Approach to Retirement Goals</div>
                                        </div>
                                        <div class="benefit-items style-small">
                                            <div class="icon"><i class="icon-checkbox"></i></div>
                                            <div class="title">Inflation Protection for Lasting Savings</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="detalis-content mb-60" id="menu-sidebar-2">
                                <h4 class="title-content mb-16">Retirement Planning Performance Chart</h4>
                                <div class="desc mb-32 body-2 color-on-suface-variant-1">Visualize your retirement
                                    journey with our performance charts. Our service provides detailed charts tracking
                                    key indicators—savings growth, investment returns, and projected expenses—so you can
                                    see how your retirement plan aligns with your goals. Monitor your progress in
                                    real-time, make data-driven adjustments, and gain confidence in your financial
                                    future with clear, visual insights that keep your retirement plan on track.</div>
                                <div class="wg-box-chart">
                                    <div class="top-wg-box-char">
                                        <div class="left">
                                            <h5 class="color-on-suface-container">Revenue Generated</h5>
                                            <h5 class="number"><i class="icon-TrendUp"></i>18%</h5>
                                            <p class="color-on-suface-container">Compared to last year</p>
                                        </div>
                                        <div class="right">
                                            <div class="flat-animate-tab">
                                                <div class="wg-tab">
                                                    <ul class="tab-product mb-0" role="tablist">
                                                        <li class="nav-tab-item" role="presentation"><a href="#weekly"
                                                                data-bs-toggle="tab" role="tab" class="active text-btn"
                                                                aria-selected="true">Weekly</a></li>
                                                        <li class="nav-tab-item" role="presentation"><a href="#monthly"
                                                                data-bs-toggle="tab" role="tab" class="text-btn"
                                                                aria-selected="false" tabindex="-1">Monthly</a></li>
                                                    </ul>
                                                </div>
                                                <div class="tab-content">
                                                    <div class="tab-pane active show" id="weekly" role="tabpanel"></div>
                                                    <div class="tab-pane" id="monthly" role="tabpanel"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div id="line-chart-6" style="min-height: 308px;">
                                        <div id="apexcharts412o8p7s"
                                            class="apexcharts-canvas apexcharts412o8p7s apexcharts-theme-light"
                                            style="width: 848px; height: 293px;">
                                            <svg xmlns="http://www.w3.org/2000/svg" version="1.1"
                                                xmlns:xlink="http://www.w3.org/1999/xlink" class="apexcharts-svg"
                                                xmlns:data="ApexChartsNS" transform="translate(0, 0)" width="848"
                                                height="293">
                                                <foreignObject x="0" y="0" width="848" height="293">
                                                    <style type="text/css">
                                                        .apexcharts-flip-y {
                                                            transform: scaleY(-1) translateY(-100%);
                                                            transform-origin: top;
                                                            transform-box: fill-box;
                                                        }

                                                        .apexcharts-flip-x {
                                                            transform: scaleX(-1);
                                                            transform-origin: center;
                                                            transform-box: fill-box;
                                                        }

                                                        .apexcharts-legend {
                                                            display: flex;
                                                            overflow: auto;
                                                            padding: 0 10px;
                                                        }

                                                        .apexcharts-legend.apexcharts-legend-group-horizontal {
                                                            flex-direction: column;
                                                        }

                                                        .apexcharts-legend-group {
                                                            display: flex;
                                                        }

                                                        .apexcharts-legend-group-vertical {
                                                            flex-direction: column-reverse;
                                                        }

                                                        .apexcharts-legend.apx-legend-position-bottom,
                                                        .apexcharts-legend.apx-legend-position-top {
                                                            flex-wrap: wrap
                                                        }

                                                        .apexcharts-legend.apx-legend-position-right,
                                                        .apexcharts-legend.apx-legend-position-left {
                                                            flex-direction: column;
                                                            bottom: 0;
                                                        }

                                                        .apexcharts-legend.apx-legend-position-bottom.apexcharts-align-left,
                                                        .apexcharts-legend.apx-legend-position-top.apexcharts-align-left,
                                                        .apexcharts-legend.apx-legend-position-right,
                                                        .apexcharts-legend.apx-legend-position-left {
                                                            justify-content: flex-start;
                                                            align-items: flex-start;
                                                        }

                                                        .apexcharts-legend.apx-legend-position-bottom.apexcharts-align-center,
                                                        .apexcharts-legend.apx-legend-position-top.apexcharts-align-center {
                                                            justify-content: center;
                                                            align-items: center;
                                                        }

                                                        .apexcharts-legend.apx-legend-position-bottom.apexcharts-align-right,
                                                        .apexcharts-legend.apx-legend-position-top.apexcharts-align-right {
                                                            justify-content: flex-end;
                                                            align-items: flex-end;
                                                        }

                                                        .apexcharts-legend-series {
                                                            cursor: pointer;
                                                            line-height: normal;
                                                            display: flex;
                                                            align-items: center;
                                                        }

                                                        .apexcharts-legend-text {
                                                            position: relative;
                                                            font-size: 14px;
                                                        }

                                                        .apexcharts-legend-text *,
                                                        .apexcharts-legend-marker * {
                                                            pointer-events: none;
                                                        }

                                                        .apexcharts-legend-marker {
                                                            position: relative;
                                                            display: flex;
                                                            align-items: center;
                                                            justify-content: center;
                                                            cursor: pointer;
                                                            margin-right: 1px;
                                                        }

                                                        .apexcharts-legend-series.apexcharts-no-click {
                                                            cursor: auto;
                                                        }

                                                        .apexcharts-legend .apexcharts-hidden-zero-series,
                                                        .apexcharts-legend .apexcharts-hidden-null-series {
                                                            display: none !important;
                                                        }

                                                        .apexcharts-inactive-legend {
                                                            opacity: 0.45;
                                                        }
                                                    </style>
                                                </foreignObject>
                                                <rect width="0" height="0" x="0" y="0" rx="0" ry="0" opacity="1"
                                                    stroke-width="0" stroke="none" stroke-dasharray="0" fill="#fefefe">
                                                </rect>
                                                <g class="apexcharts-datalabels-group"
                                                    transform="translate(0, 0) scale(1)"></g>
                                                <g class="apexcharts-datalabels-group"
                                                    transform="translate(0, 0) scale(1)"></g>
                                                <g class="apexcharts-yaxis" rel="0"
                                                    transform="translate(24.021484375, 0)">
                                                    <g class="apexcharts-yaxis-texts-g">
                                                        <text x="20" y="34" text-anchor="end" dominant-baseline="auto"
                                                            font-size="12px" font-family="Helvetica, Arial, sans-serif"
                                                            font-weight="500" fill="#6d7074"
                                                            class="apexcharts-text apexcharts-yaxis-label "
                                                            style="font-family: Helvetica, Arial, sans-serif;">
                                                            <tspan>$52k</tspan>
                                                            <title>$52k</title>
                                                        </text>
                                                        <text x="20" y="109.116" text-anchor="end"
                                                            dominant-baseline="auto" font-size="12px"
                                                            font-family="Helvetica, Arial, sans-serif" font-weight="500"
                                                            fill="#6d7074"
                                                            class="apexcharts-text apexcharts-yaxis-label "
                                                            style="font-family: Helvetica, Arial, sans-serif;">
                                                            <tspan>$38k</tspan>
                                                            <title>$38k</title>
                                                        </text>
                                                        <text x="20" y="184.232" text-anchor="end"
                                                            dominant-baseline="auto" font-size="12px"
                                                            font-family="Helvetica, Arial, sans-serif" font-weight="500"
                                                            fill="#6d7074"
                                                            class="apexcharts-text apexcharts-yaxis-label "
                                                            style="font-family: Helvetica, Arial, sans-serif;">
                                                            <tspan>$24k</tspan>
                                                            <title>$24k</title>
                                                        </text>
                                                        <text x="20" y="259.348" text-anchor="end"
                                                            dominant-baseline="auto" font-size="12px"
                                                            font-family="Helvetica, Arial, sans-serif" font-weight="500"
                                                            fill="#6d7074"
                                                            class="apexcharts-text apexcharts-yaxis-label "
                                                            style="font-family: Helvetica, Arial, sans-serif;">
                                                            <tspan>$10k</tspan>
                                                            <title>$10k</title>
                                                        </text>
                                                    </g>
                                                </g>
                                                <g class="apexcharts-inner apexcharts-graphical"
                                                    transform="translate(54.021484375, 30)">
                                                    <defs>
                                                        <clipPath id="gridRectMask412o8p7s">
                                                            <rect width="791.978515625" height="233.348" x="-4" y="-4"
                                                                rx="0" ry="0" opacity="1" stroke-width="0" stroke="none"
                                                                stroke-dasharray="0" fill="#fff"></rect>
                                                        </clipPath>
                                                        <clipPath id="gridRectBarMask412o8p7s">
                                                            <rect width="791.978515625" height="233.348" x="-4" y="-4"
                                                                rx="0" ry="0" opacity="1" stroke-width="0" stroke="none"
                                                                stroke-dasharray="0" fill="#fff"></rect>
                                                        </clipPath>
                                                        <clipPath id="gridRectMarkerMask412o8p7s">
                                                            <rect width="783.978515625" height="225.348" x="0" y="0"
                                                                rx="0" ry="0" opacity="1" stroke-width="0" stroke="none"
                                                                stroke-dasharray="0" fill="#fff"></rect>
                                                        </clipPath>
                                                        <clipPath id="forecastMask412o8p7s"></clipPath>
                                                        <clipPath id="nonForecastMask412o8p7s"></clipPath>
                                                    </defs>
                                                    <line x1="0" y1="0" x2="0" y2="225.348" stroke="#b6b6b6"
                                                        stroke-dasharray="3" stroke-linecap="butt"
                                                        class="apexcharts-xcrosshairs" x="0" y="0" width="1"
                                                        height="225.348" fill="#b1b9c4" filter="none" fill-opacity="0.9"
                                                        stroke-width="1"></line>
                                                    <line x1="0" y1="225.348" x2="0" y2="231.348" stroke="#e0e0e0"
                                                        stroke-dasharray="0" stroke-linecap="butt"
                                                        class="apexcharts-xaxis-tick"></line>
                                                    <line x1="97.997314453125" y1="225.348" x2="97.997314453125"
                                                        y2="231.348" stroke="#e0e0e0" stroke-dasharray="0"
                                                        stroke-linecap="butt" class="apexcharts-xaxis-tick"></line>
                                                    <line x1="195.99462890625" y1="225.348" x2="195.99462890625"
                                                        y2="231.348" stroke="#e0e0e0" stroke-dasharray="0"
                                                        stroke-linecap="butt" class="apexcharts-xaxis-tick"></line>
                                                    <line x1="293.991943359375" y1="225.348" x2="293.991943359375"
                                                        y2="231.348" stroke="#e0e0e0" stroke-dasharray="0"
                                                        stroke-linecap="butt" class="apexcharts-xaxis-tick"></line>
                                                    <line x1="391.9892578125" y1="225.348" x2="391.9892578125"
                                                        y2="231.348" stroke="#e0e0e0" stroke-dasharray="0"
                                                        stroke-linecap="butt" class="apexcharts-xaxis-tick"></line>
                                                    <line x1="489.986572265625" y1="225.348" x2="489.986572265625"
                                                        y2="231.348" stroke="#e0e0e0" stroke-dasharray="0"
                                                        stroke-linecap="butt" class="apexcharts-xaxis-tick"></line>
                                                    <line x1="587.98388671875" y1="225.348" x2="587.98388671875"
                                                        y2="231.348" stroke="#e0e0e0" stroke-dasharray="0"
                                                        stroke-linecap="butt" class="apexcharts-xaxis-tick"></line>
                                                    <line x1="685.981201171875" y1="225.348" x2="685.981201171875"
                                                        y2="231.348" stroke="#e0e0e0" stroke-dasharray="0"
                                                        stroke-linecap="butt" class="apexcharts-xaxis-tick"></line>
                                                    <line x1="783.978515625" y1="225.348" x2="783.978515625"
                                                        y2="231.348" stroke="#e0e0e0" stroke-dasharray="0"
                                                        stroke-linecap="butt" class="apexcharts-xaxis-tick"></line>
                                                    <g class="apexcharts-grid">
                                                        <g class="apexcharts-gridlines-horizontal">
                                                            <line x1="0" y1="75.116" x2="783.978515625" y2="75.116"
                                                                stroke="#e0e0e0" stroke-dasharray="0"
                                                                stroke-linecap="butt" class="apexcharts-gridline">
                                                            </line>
                                                            <line x1="0" y1="150.232" x2="783.978515625" y2="150.232"
                                                                stroke="#e0e0e0" stroke-dasharray="0"
                                                                stroke-linecap="butt" class="apexcharts-gridline">
                                                            </line>
                                                        </g>
                                                        <g class="apexcharts-gridlines-vertical"></g>
                                                        <line x1="0" y1="225.348" x2="783.978515625" y2="225.348"
                                                            stroke="transparent" stroke-dasharray="0"
                                                            stroke-linecap="butt"></line>
                                                        <line x1="0" y1="1" x2="0" y2="225.348" stroke="transparent"
                                                            stroke-dasharray="0" stroke-linecap="butt"></line>
                                                    </g>
                                                    <g class="apexcharts-grid-borders">
                                                        <line x1="0" y1="0" x2="783.978515625" y2="0" stroke="#e0e0e0"
                                                            stroke-dasharray="0" stroke-linecap="butt"
                                                            class="apexcharts-gridline"></line>
                                                        <line x1="0" y1="225.348" x2="783.978515625" y2="225.348"
                                                            stroke="#e0e0e0" stroke-dasharray="0" stroke-linecap="butt"
                                                            class="apexcharts-gridline"></line>
                                                        <line x1="0" y1="225.348" x2="783.978515625" y2="225.348"
                                                            stroke="#e0e0e0" stroke-dasharray="0" stroke-width="1"
                                                            stroke-linecap="butt"></line>
                                                    </g>
                                                    <g class="apexcharts-area-series apexcharts-plot-series">
                                                        <g class="apexcharts-series" zIndex="0" seriesName="x"
                                                            data:longestSeries="true" rel="1" data:realIndex="0">
                                                            <path
                                                                d="M 0 48.288857142857154C 34.299060058593746 48.288857142857154 63.69825439453124 150.23200000000003 97.99731445312499 150.23200000000003C 132.29637451171874 150.23200000000003 161.69556884765623 128.77028571428573 195.99462890624997 128.77028571428573C 230.29368896484374 128.77028571428573 259.69288330078126 182.42457142857143 293.991943359375 182.42457142857143C 328.29100341796874 182.42457142857143 357.6901977539062 26.82714285714286 391.98925781249994 26.82714285714286C 426.2883178710937 26.82714285714286 455.6875122070312 177.0591428571429 489.98657226562494 177.0591428571429C 524.2856323242187 177.0591428571429 553.6848266601562 123.40485714285717 587.98388671875 123.40485714285717C 622.2829467773438 123.40485714285717 651.6821411132812 118.03942857142857 685.981201171875 118.03942857142857C 720.2802612304687 118.03942857142857 749.6794555664062 16.096285714285727 783.9785156249999 16.096285714285727C 783.9785156249999 16.096285714285727 783.9785156249999 16.096285714285727 783.9785156249999 225.348 L 0 225.348z"
                                                                fill="rgba(49,124,111,0.1)" fill-opacity="1"
                                                                stroke="none" stroke-opacity="1" stroke-linecap="butt"
                                                                stroke-width="0" stroke-dasharray="0"
                                                                class="apexcharts-area" index="0"
                                                                clip-path="url(#gridRectMask412o8p7s)"
                                                                pathTo="M 0 48.288857142857154C 34.299060058593746 48.288857142857154 63.69825439453124 150.23200000000003 97.99731445312499 150.23200000000003C 132.29637451171874 150.23200000000003 161.69556884765623 128.77028571428573 195.99462890624997 128.77028571428573C 230.29368896484374 128.77028571428573 259.69288330078126 182.42457142857143 293.991943359375 182.42457142857143C 328.29100341796874 182.42457142857143 357.6901977539062 26.82714285714286 391.98925781249994 26.82714285714286C 426.2883178710937 26.82714285714286 455.6875122070312 177.0591428571429 489.98657226562494 177.0591428571429C 524.2856323242187 177.0591428571429 553.6848266601562 123.40485714285717 587.98388671875 123.40485714285717C 622.2829467773438 123.40485714285717 651.6821411132812 118.03942857142857 685.981201171875 118.03942857142857C 720.2802612304687 118.03942857142857 749.6794555664062 16.096285714285727 783.9785156249999 16.096285714285727C 783.9785156249999 16.096285714285727 783.9785156249999 16.096285714285727 783.9785156249999 225.348 L 0 225.348z"
                                                                pathFrom="M 0 225.348 L 0 225.348 L 97.99731445312499 225.348 L 195.99462890624997 225.348 L 293.991943359375 225.348 L 391.98925781249994 225.348 L 489.98657226562494 225.348 L 587.98388671875 225.348 L 685.981201171875 225.348 L 783.9785156249999 225.348z">
                                                            </path>
                                                            <path
                                                                d="M 0 48.288857142857154C 34.299060058593746 48.288857142857154 63.69825439453124 150.23200000000003 97.99731445312499 150.23200000000003C 132.29637451171874 150.23200000000003 161.69556884765623 128.77028571428573 195.99462890624997 128.77028571428573C 230.29368896484374 128.77028571428573 259.69288330078126 182.42457142857143 293.991943359375 182.42457142857143C 328.29100341796874 182.42457142857143 357.6901977539062 26.82714285714286 391.98925781249994 26.82714285714286C 426.2883178710937 26.82714285714286 455.6875122070312 177.0591428571429 489.98657226562494 177.0591428571429C 524.2856323242187 177.0591428571429 553.6848266601562 123.40485714285717 587.98388671875 123.40485714285717C 622.2829467773438 123.40485714285717 651.6821411132812 118.03942857142857 685.981201171875 118.03942857142857C 720.2802612304687 118.03942857142857 749.6794555664062 16.096285714285727 783.9785156249999 16.096285714285727"
                                                                fill="none" fill-opacity="1" stroke="#317c6f"
                                                                stroke-opacity="1" stroke-linecap="butt"
                                                                stroke-width="4" stroke-dasharray="0"
                                                                class="apexcharts-area" index="0"
                                                                clip-path="url(#gridRectMask412o8p7s)"
                                                                pathTo="M 0 48.288857142857154C 34.299060058593746 48.288857142857154 63.69825439453124 150.23200000000003 97.99731445312499 150.23200000000003C 132.29637451171874 150.23200000000003 161.69556884765623 128.77028571428573 195.99462890624997 128.77028571428573C 230.29368896484374 128.77028571428573 259.69288330078126 182.42457142857143 293.991943359375 182.42457142857143C 328.29100341796874 182.42457142857143 357.6901977539062 26.82714285714286 391.98925781249994 26.82714285714286C 426.2883178710937 26.82714285714286 455.6875122070312 177.0591428571429 489.98657226562494 177.0591428571429C 524.2856323242187 177.0591428571429 553.6848266601562 123.40485714285717 587.98388671875 123.40485714285717C 622.2829467773438 123.40485714285717 651.6821411132812 118.03942857142857 685.981201171875 118.03942857142857C 720.2802612304687 118.03942857142857 749.6794555664062 16.096285714285727 783.9785156249999 16.096285714285727"
                                                                pathFrom="M 0 225.348 L 0 225.348 L 97.99731445312499 225.348 L 195.99462890624997 225.348 L 293.991943359375 225.348 L 391.98925781249994 225.348 L 489.98657226562494 225.348 L 587.98388671875 225.348 L 685.981201171875 225.348 L 783.9785156249999 225.348"
                                                                fill-rule="evenodd"></path>
                                                            <g class="apexcharts-series-markers-wrap apexcharts-hidden-element-shown"
                                                                data:realIndex="0">
                                                                <g class="apexcharts-series-markers">
                                                                    <path d="M 0, 0 
                                                      m -0, 0 
                                                      a 0,0 0 1,0 0,0 
                                                      a 0,0 0 1,0 -0,0" fill="#317c6f" fill-opacity="1"
                                                                        stroke="#ffffff" stroke-opacity="0.9"
                                                                        stroke-linecap="butt" stroke-width="2"
                                                                        stroke-dasharray="0" cx="0" cy="0"
                                                                        shape="circle"
                                                                        class="apexcharts-marker wdb64bkna no-pointer-events"
                                                                        default-marker-size="0"></path>
                                                                </g>
                                                            </g>
                                                        </g>
                                                        <g class="apexcharts-datalabels" data:realIndex="0"></g>
                                                    </g>
                                                    <line x1="0" y1="0" x2="783.978515625" y2="0" stroke="#b6b6b6"
                                                        stroke-dasharray="0" stroke-width="1" stroke-linecap="butt"
                                                        class="apexcharts-ycrosshairs"></line>
                                                    <line x1="0" y1="0" x2="783.978515625" y2="0" stroke="#b6b6b6"
                                                        stroke-dasharray="0" stroke-width="0" stroke-linecap="butt"
                                                        class="apexcharts-ycrosshairs-hidden"></line>
                                                    <g class="apexcharts-xaxis" transform="translate(0, 0)">
                                                        <g class="apexcharts-xaxis-texts-g"
                                                            transform="translate(0, -4)">
                                                            <text x="0" y="253.348" text-anchor="middle"
                                                                dominant-baseline="auto" font-size="12px"
                                                                font-family="Helvetica, Arial, sans-serif"
                                                                font-weight="400" fill="#6d7074"
                                                                class="apexcharts-text apexcharts-xaxis-label "
                                                                style="font-family: Helvetica, Arial, sans-serif;">
                                                                <tspan>2/1</tspan>
                                                                <title>2/1</title>
                                                            </text>
                                                            <text x="97.997314453125" y="253.348" text-anchor="middle"
                                                                dominant-baseline="auto" font-size="12px"
                                                                font-family="Helvetica, Arial, sans-serif"
                                                                font-weight="400" fill="#6d7074"
                                                                class="apexcharts-text apexcharts-xaxis-label "
                                                                style="font-family: Helvetica, Arial, sans-serif;">
                                                                <tspan>2/2</tspan>
                                                                <title>2/2</title>
                                                            </text>
                                                            <text x="195.99462890625" y="253.348" text-anchor="middle"
                                                                dominant-baseline="auto" font-size="12px"
                                                                font-family="Helvetica, Arial, sans-serif"
                                                                font-weight="400" fill="#6d7074"
                                                                class="apexcharts-text apexcharts-xaxis-label "
                                                                style="font-family: Helvetica, Arial, sans-serif;">
                                                                <tspan>2/3</tspan>
                                                                <title>2/3</title>
                                                            </text>
                                                            <text x="293.991943359375" y="253.348" text-anchor="middle"
                                                                dominant-baseline="auto" font-size="12px"
                                                                font-family="Helvetica, Arial, sans-serif"
                                                                font-weight="400" fill="#6d7074"
                                                                class="apexcharts-text apexcharts-xaxis-label "
                                                                style="font-family: Helvetica, Arial, sans-serif;">
                                                                <tspan>2/4</tspan>
                                                                <title>2/4</title>
                                                            </text>
                                                            <text x="391.9892578125" y="253.348" text-anchor="middle"
                                                                dominant-baseline="auto" font-size="12px"
                                                                font-family="Helvetica, Arial, sans-serif"
                                                                font-weight="400" fill="#6d7074"
                                                                class="apexcharts-text apexcharts-xaxis-label "
                                                                style="font-family: Helvetica, Arial, sans-serif;">
                                                                <tspan>2/5</tspan>
                                                                <title>2/5</title>
                                                            </text>
                                                            <text x="489.986572265625" y="253.348" text-anchor="middle"
                                                                dominant-baseline="auto" font-size="12px"
                                                                font-family="Helvetica, Arial, sans-serif"
                                                                font-weight="400" fill="#6d7074"
                                                                class="apexcharts-text apexcharts-xaxis-label "
                                                                style="font-family: Helvetica, Arial, sans-serif;">
                                                                <tspan>2/6</tspan>
                                                                <title>2/6</title>
                                                            </text>
                                                            <text x="587.98388671875" y="253.348" text-anchor="middle"
                                                                dominant-baseline="auto" font-size="12px"
                                                                font-family="Helvetica, Arial, sans-serif"
                                                                font-weight="400" fill="#6d7074"
                                                                class="apexcharts-text apexcharts-xaxis-label "
                                                                style="font-family: Helvetica, Arial, sans-serif;">
                                                                <tspan>2/7</tspan>
                                                                <title>2/7</title>
                                                            </text>
                                                            <text x="685.981201171875" y="253.348" text-anchor="middle"
                                                                dominant-baseline="auto" font-size="12px"
                                                                font-family="Helvetica, Arial, sans-serif"
                                                                font-weight="400" fill="#6d7074"
                                                                class="apexcharts-text apexcharts-xaxis-label "
                                                                style="font-family: Helvetica, Arial, sans-serif;">
                                                                <tspan>2/8</tspan>
                                                                <title>2/8</title>
                                                            </text>
                                                            <text x="783.978515625" y="253.348" text-anchor="middle"
                                                                dominant-baseline="auto" font-size="12px"
                                                                font-family="Helvetica, Arial, sans-serif"
                                                                font-weight="400" fill="#6d7074"
                                                                class="apexcharts-text apexcharts-xaxis-label "
                                                                style="font-family: Helvetica, Arial, sans-serif;">
                                                                <tspan>2/9</tspan>
                                                                <title>2/9</title>
                                                            </text>
                                                        </g>
                                                    </g>
                                                    <g class="apexcharts-yaxis-annotations"></g>
                                                    <g class="apexcharts-xaxis-annotations"></g>
                                                    <g class="apexcharts-point-annotations"></g>
                                                </g>
                                            </svg>
                                            <div class="apexcharts-legend" style="max-height: 146.5px;"></div>
                                            <div class="apexcharts-tooltip apexcharts-theme-light">
                                                <div class="apexcharts-tooltip-title"
                                                    style="font-family: Helvetica, Arial, sans-serif; font-size: 12px;">
                                                </div>
                                                <div class="apexcharts-tooltip-series-group apexcharts-tooltip-series-group-0"
                                                    style="order: 1;">
                                                    <span class="apexcharts-tooltip-marker" shape="circle"
                                                        style="color: rgb(49, 124, 111);"></span>
                                                    <div class="apexcharts-tooltip-text"
                                                        style="font-family: Helvetica, Arial, sans-serif; font-size: 12px;">
                                                        <div class="apexcharts-tooltip-y-group"><span
                                                                class="apexcharts-tooltip-text-y-label"></span><span
                                                                class="apexcharts-tooltip-text-y-value"></span></div>
                                                        <div class="apexcharts-tooltip-goals-group"><span
                                                                class="apexcharts-tooltip-text-goals-label"></span><span
                                                                class="apexcharts-tooltip-text-goals-value"></span>
                                                        </div>
                                                        <div class="apexcharts-tooltip-z-group"><span
                                                                class="apexcharts-tooltip-text-z-label"></span><span
                                                                class="apexcharts-tooltip-text-z-value"></span></div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div
                                                class="apexcharts-xaxistooltip apexcharts-xaxistooltip-bottom apexcharts-theme-light">
                                                <div class="apexcharts-xaxistooltip-text"
                                                    style="font-family: Helvetica, Arial, sans-serif; font-size: 12px;">
                                                </div>
                                            </div>
                                            <div
                                                class="apexcharts-yaxistooltip apexcharts-yaxistooltip-0 apexcharts-yaxistooltip-left apexcharts-theme-light">
                                                <div class="apexcharts-yaxistooltip-text"></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="detalis-content mb-60" id="menu-sidebar-3">
                                <h4 class="title-content mb-16">Steps To Financial Excellence</h4>
                                <div class="desc mb-32 body-2 color-on-suface-variant-1">Our approach combines
                                    personalized strategies, data-driven insights, and dedicated support to help you
                                    reach your financial goals. Each step is crafted to maximize growth, reduce risk,
                                    and build lasting financial confidence.</div>
                                <div class="process-list style-column">
                                    <div class="process-item style-3 style-3-2">
                                        <div class="icon"><i class="icon-ChartPieSlice"></i></div>
                                        <div class="circle"></div>
                                        <div class="process-content">
                                            <h5><a href="#" class="name-process">Assessment &amp; Goal Setting</a></h5>
                                            <div class="desc body-2 color-on-suface-variant-1">We start by assessing
                                                your financial situation and setting realistic goals, creating a
                                                solid<br>foundation for a customized plan.</div>
                                        </div>
                                    </div>
                                    <div class="process-item style-3 style-3-2">
                                        <div class="icon"><i class="icon-Crosshair1"></i></div>
                                        <div class="circle"></div>
                                        <div class="process-content">
                                            <h5><a href="#" class="name-process">Plan Development</a></h5>
                                            <div class="desc body-2 color-on-suface-variant-1">Using insights from our
                                                assessment, we develop a unique strategy focused on asset growth, risk
                                                management, and long-term success.</div>
                                        </div>
                                    </div>
                                    <div class="process-item style-3 style-3-2">
                                        <div class="icon"><i class="icon-ChartLineUp"></i></div>
                                        <div class="process-content">
                                            <h5><a href="#" class="name-process">Ongoing Review</a></h5>
                                            <div class="desc body-2 color-on-suface-variant-1">We regularly review and
                                                adapt your plan to stay aligned with your evolving goals, ensuring you
                                                stay on track to lasting success.</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="detalis-content" id="menu-sidebar-4">
                                <h4 class="title-content mb-20">FAQs</h4>
                                <div class="wg-according" id="According1">
                                    <div class="according-item style-arrow style-small">
                                        <h6><a href="#according1" data-bs-toggle="collapse"
                                                class="title-according collapsed">What consulting services do you
                                                offer?<i class="icon-chevron-down"></i></a></h6>
                                        <div id="according1" class="collapse" data-bs-parent="#According1">
                                            <div class="according-content">
                                                <p>We conduct in-depth assessments of your business needs, industry
                                                    landscape, and competitive environment to develop customized
                                                    strategies that align with your specific goals.</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="according-item style-arrow style-small">
                                        <h6><a href="#according2" data-bs-toggle="collapse"
                                                class="title-according collapsed">How do your services integrate with
                                                existing business structures?<i class="icon-chevron-down"></i></a></h6>
                                        <div id="according2" class="collapse" data-bs-parent="#According1">
                                            <div class="according-content">
                                                <p>We conduct in-depth assessments of your business needs, industry
                                                    landscape, and competitive environment to develop customized
                                                    strategies that align with your specific goals.</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="according-item style-arrow style-small">
                                        <h6>
                                            <a href="#according3" data-bs-toggle="collapse"
                                                class="title-according collapsed">
                                                Can I tailor your consulting services to suit my business?<!-- --> <i
                                                    class="icon-chevron-down"></i>
                                            </a>
                                        </h6>
                                        <div id="according3" class="collapse" data-bs-parent="#According1">
                                            <div class="according-content">
                                                <p>We conduct in-depth assessments of your business needs, industry
                                                    landscape, and competitive environment to develop customized
                                                    strategies that align with your specific goals.</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="according-item style-arrow style-small">
                                        <h6><a href="#according4" data-bs-toggle="collapse"
                                                class="title-according collapsed">What kind of ongoing consultation do
                                                you offer after the initial service?<i
                                                    class="icon-chevron-down"></i></a></h6>
                                        <div id="according4" class="collapse" data-bs-parent="#According1">
                                            <div class="according-content">
                                                <p>We conduct in-depth assessments of your business needs, industry
                                                    landscape, and competitive environment to develop customized
                                                    strategies that align with your specific goals.</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane" id="tab-2" role="tabpanel">
                        <div class="service-details-content">
                            <div class="image-details image mb-60"><img alt="" loading="lazy" width="850" height="512"
                                    decoding="async" data-nimg="1" class="lazyload" style="color:transparent"
                                    src="/image/section/img-details-service-2.jpg"></div>
                            <div class="detalis-content mb-60" id="menu-sidebar-1">
                                <h4 class="title-content mb-16">Retirement Planning Solutions</h4>
                                <div class="desc mb-16 body-2 color-on-suface-variant-1">Secure your retirement with our
                                    personalized planning service. We create strategies for steady income, inflation
                                    protection, and optimized growth. Enjoy financial confidence and be prepared for
                                    future needs.</div>
                                <div class="cols g-10">
                                    <div class="benefit-lists">
                                        <div class="benefit-items style-small mb-16">
                                            <div class="icon"><i class="icon-checkbox"></i></div>
                                            <div class="title">Reliable Retirement Income</div>
                                        </div>
                                        <div class="benefit-items style-small mb-16">
                                            <div class="icon"><i class="icon-checkbox"></i></div>
                                            <div class="title">Future Security and Peace of Mind</div>
                                        </div>
                                        <div class="benefit-items style-small">
                                            <div class="icon"><i class="icon-checkbox"></i></div>
                                            <div class="title">Asset Protection for Long-Term Stability</div>
                                        </div>
                                    </div>
                                    <div class="benefit-lists">
                                        <div class="benefit-items style-small mb-16">
                                            <div class="icon"><i class="icon-checkbox"></i></div>
                                            <div class="title">Reliable Income for Retirement</div>
                                        </div>
                                        <div class="benefit-items style-small mb-16">
                                            <div class="icon"><i class="icon-checkbox"></i></div>
                                            <div class="title">Personalized Approach to Retirement Goals</div>
                                        </div>
                                        <div class="benefit-items style-small">
                                            <div class="icon"><i class="icon-checkbox"></i></div>
                                            <div class="title">Inflation Protection for Lasting Savings</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="detalis-content mb-60" id="menu-sidebar-2">
                                <h4 class="title-content mb-16">Retirement Planning Performance Chart</h4>
                                <div class="desc mb-32 body-2 color-on-suface-variant-1">Visualize your retirement
                                    journey with our performance charts. Our service provides detailed charts tracking
                                    key indicators—savings growth, investment returns, and projected expenses—so you can
                                    see how your retirement plan aligns with your goals. Monitor your progress in
                                    real-time, make data-driven adjustments, and gain confidence in your financial
                                    future with clear, visual insights that keep your retirement plan on track.</div>
                                <div class="wg-box-chart">
                                    <div class="top-wg-box-char">
                                        <div class="left">
                                            <h5 class="color-on-suface-container">Revenue Generated</h5>
                                            <h5 class="number"><i class="icon-TrendUp"></i>18%</h5>
                                            <p class="color-on-suface-container">Compared to last year</p>
                                        </div>
                                        <div class="right">
                                            <div class="flat-animate-tab">
                                                <div class="wg-tab">
                                                    <ul class="tab-product mb-0" role="tablist">
                                                        <li class="nav-tab-item" role="presentation"><a href="#weekly"
                                                                data-bs-toggle="tab" role="tab" class="active text-btn"
                                                                aria-selected="true">Weekly</a></li>
                                                        <li class="nav-tab-item" role="presentation"><a href="#monthly"
                                                                data-bs-toggle="tab" role="tab" class="text-btn"
                                                                aria-selected="false" tabindex="-1">Monthly</a></li>
                                                    </ul>
                                                </div>
                                                <div class="tab-content">
                                                    <div class="tab-pane active show" id="weekly" role="tabpanel"></div>
                                                    <div class="tab-pane" id="monthly" role="tabpanel"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div id="line-chart-6" style="min-height: 308px;">
                                        <div id="apexcharts9gnylr29"
                                            class="apexcharts-canvas apexcharts9gnylr29 apexcharts-theme-light"
                                            style="width: 848px; height: 293px;">
                                            <svg xmlns="http://www.w3.org/2000/svg" version="1.1"
                                                xmlns:xlink="http://www.w3.org/1999/xlink" class="apexcharts-svg"
                                                xmlns:data="ApexChartsNS" transform="translate(0, 0)" width="848"
                                                height="293">
                                                <foreignObject x="0" y="0" width="848" height="293">
                                                    <style type="text/css">
                                                        .apexcharts-flip-y {
                                                            transform: scaleY(-1) translateY(-100%);
                                                            transform-origin: top;
                                                            transform-box: fill-box;
                                                        }

                                                        .apexcharts-flip-x {
                                                            transform: scaleX(-1);
                                                            transform-origin: center;
                                                            transform-box: fill-box;
                                                        }

                                                        .apexcharts-legend {
                                                            display: flex;
                                                            overflow: auto;
                                                            padding: 0 10px;
                                                        }

                                                        .apexcharts-legend.apexcharts-legend-group-horizontal {
                                                            flex-direction: column;
                                                        }

                                                        .apexcharts-legend-group {
                                                            display: flex;
                                                        }

                                                        .apexcharts-legend-group-vertical {
                                                            flex-direction: column-reverse;
                                                        }

                                                        .apexcharts-legend.apx-legend-position-bottom,
                                                        .apexcharts-legend.apx-legend-position-top {
                                                            flex-wrap: wrap
                                                        }

                                                        .apexcharts-legend.apx-legend-position-right,
                                                        .apexcharts-legend.apx-legend-position-left {
                                                            flex-direction: column;
                                                            bottom: 0;
                                                        }

                                                        .apexcharts-legend.apx-legend-position-bottom.apexcharts-align-left,
                                                        .apexcharts-legend.apx-legend-position-top.apexcharts-align-left,
                                                        .apexcharts-legend.apx-legend-position-right,
                                                        .apexcharts-legend.apx-legend-position-left {
                                                            justify-content: flex-start;
                                                            align-items: flex-start;
                                                        }

                                                        .apexcharts-legend.apx-legend-position-bottom.apexcharts-align-center,
                                                        .apexcharts-legend.apx-legend-position-top.apexcharts-align-center {
                                                            justify-content: center;
                                                            align-items: center;
                                                        }

                                                        .apexcharts-legend.apx-legend-position-bottom.apexcharts-align-right,
                                                        .apexcharts-legend.apx-legend-position-top.apexcharts-align-right {
                                                            justify-content: flex-end;
                                                            align-items: flex-end;
                                                        }

                                                        .apexcharts-legend-series {
                                                            cursor: pointer;
                                                            line-height: normal;
                                                            display: flex;
                                                            align-items: center;
                                                        }

                                                        .apexcharts-legend-text {
                                                            position: relative;
                                                            font-size: 14px;
                                                        }

                                                        .apexcharts-legend-text *,
                                                        .apexcharts-legend-marker * {
                                                            pointer-events: none;
                                                        }

                                                        .apexcharts-legend-marker {
                                                            position: relative;
                                                            display: flex;
                                                            align-items: center;
                                                            justify-content: center;
                                                            cursor: pointer;
                                                            margin-right: 1px;
                                                        }

                                                        .apexcharts-legend-series.apexcharts-no-click {
                                                            cursor: auto;
                                                        }

                                                        .apexcharts-legend .apexcharts-hidden-zero-series,
                                                        .apexcharts-legend .apexcharts-hidden-null-series {
                                                            display: none !important;
                                                        }

                                                        .apexcharts-inactive-legend {
                                                            opacity: 0.45;
                                                        }
                                                    </style>
                                                </foreignObject>
                                                <rect width="0" height="0" x="0" y="0" rx="0" ry="0" opacity="1"
                                                    stroke-width="0" stroke="none" stroke-dasharray="0" fill="#fefefe">
                                                </rect>
                                                <g class="apexcharts-datalabels-group"
                                                    transform="translate(0, 0) scale(1)"></g>
                                                <g class="apexcharts-datalabels-group"
                                                    transform="translate(0, 0) scale(1)"></g>
                                                <g class="apexcharts-yaxis" rel="0"
                                                    transform="translate(24.021484375, 0)">
                                                    <g class="apexcharts-yaxis-texts-g">
                                                        <text x="20" y="34" text-anchor="end" dominant-baseline="auto"
                                                            font-size="12px" font-family="Helvetica, Arial, sans-serif"
                                                            font-weight="500" fill="#6d7074"
                                                            class="apexcharts-text apexcharts-yaxis-label "
                                                            style="font-family: Helvetica, Arial, sans-serif;">
                                                            <tspan>$52k</tspan>
                                                            <title>$52k</title>
                                                        </text>
                                                        <text x="20" y="109.116" text-anchor="end"
                                                            dominant-baseline="auto" font-size="12px"
                                                            font-family="Helvetica, Arial, sans-serif" font-weight="500"
                                                            fill="#6d7074"
                                                            class="apexcharts-text apexcharts-yaxis-label "
                                                            style="font-family: Helvetica, Arial, sans-serif;">
                                                            <tspan>$38k</tspan>
                                                            <title>$38k</title>
                                                        </text>
                                                        <text x="20" y="184.232" text-anchor="end"
                                                            dominant-baseline="auto" font-size="12px"
                                                            font-family="Helvetica, Arial, sans-serif" font-weight="500"
                                                            fill="#6d7074"
                                                            class="apexcharts-text apexcharts-yaxis-label "
                                                            style="font-family: Helvetica, Arial, sans-serif;">
                                                            <tspan>$24k</tspan>
                                                            <title>$24k</title>
                                                        </text>
                                                        <text x="20" y="259.348" text-anchor="end"
                                                            dominant-baseline="auto" font-size="12px"
                                                            font-family="Helvetica, Arial, sans-serif" font-weight="500"
                                                            fill="#6d7074"
                                                            class="apexcharts-text apexcharts-yaxis-label "
                                                            style="font-family: Helvetica, Arial, sans-serif;">
                                                            <tspan>$10k</tspan>
                                                            <title>$10k</title>
                                                        </text>
                                                    </g>
                                                </g>
                                                <g class="apexcharts-inner apexcharts-graphical"
                                                    transform="translate(54.021484375, 30)">
                                                    <defs>
                                                        <clipPath id="gridRectMask9gnylr29">
                                                            <rect width="791.978515625" height="233.348" x="-4" y="-4"
                                                                rx="0" ry="0" opacity="1" stroke-width="0" stroke="none"
                                                                stroke-dasharray="0" fill="#fff"></rect>
                                                        </clipPath>
                                                        <clipPath id="gridRectBarMask9gnylr29">
                                                            <rect width="791.978515625" height="233.348" x="-4" y="-4"
                                                                rx="0" ry="0" opacity="1" stroke-width="0" stroke="none"
                                                                stroke-dasharray="0" fill="#fff"></rect>
                                                        </clipPath>
                                                        <clipPath id="gridRectMarkerMask9gnylr29">
                                                            <rect width="783.978515625" height="225.348" x="0" y="0"
                                                                rx="0" ry="0" opacity="1" stroke-width="0" stroke="none"
                                                                stroke-dasharray="0" fill="#fff"></rect>
                                                        </clipPath>
                                                        <clipPath id="forecastMask9gnylr29"></clipPath>
                                                        <clipPath id="nonForecastMask9gnylr29"></clipPath>
                                                    </defs>
                                                    <line x1="0" y1="0" x2="0" y2="225.348" stroke="#b6b6b6"
                                                        stroke-dasharray="3" stroke-linecap="butt"
                                                        class="apexcharts-xcrosshairs" x="0" y="0" width="1"
                                                        height="225.348" fill="#b1b9c4" filter="none" fill-opacity="0.9"
                                                        stroke-width="1"></line>
                                                    <line x1="0" y1="225.348" x2="0" y2="231.348" stroke="#e0e0e0"
                                                        stroke-dasharray="0" stroke-linecap="butt"
                                                        class="apexcharts-xaxis-tick"></line>
                                                    <line x1="97.997314453125" y1="225.348" x2="97.997314453125"
                                                        y2="231.348" stroke="#e0e0e0" stroke-dasharray="0"
                                                        stroke-linecap="butt" class="apexcharts-xaxis-tick"></line>
                                                    <line x1="195.99462890625" y1="225.348" x2="195.99462890625"
                                                        y2="231.348" stroke="#e0e0e0" stroke-dasharray="0"
                                                        stroke-linecap="butt" class="apexcharts-xaxis-tick"></line>
                                                    <line x1="293.991943359375" y1="225.348" x2="293.991943359375"
                                                        y2="231.348" stroke="#e0e0e0" stroke-dasharray="0"
                                                        stroke-linecap="butt" class="apexcharts-xaxis-tick"></line>
                                                    <line x1="391.9892578125" y1="225.348" x2="391.9892578125"
                                                        y2="231.348" stroke="#e0e0e0" stroke-dasharray="0"
                                                        stroke-linecap="butt" class="apexcharts-xaxis-tick"></line>
                                                    <line x1="489.986572265625" y1="225.348" x2="489.986572265625"
                                                        y2="231.348" stroke="#e0e0e0" stroke-dasharray="0"
                                                        stroke-linecap="butt" class="apexcharts-xaxis-tick"></line>
                                                    <line x1="587.98388671875" y1="225.348" x2="587.98388671875"
                                                        y2="231.348" stroke="#e0e0e0" stroke-dasharray="0"
                                                        stroke-linecap="butt" class="apexcharts-xaxis-tick"></line>
                                                    <line x1="685.981201171875" y1="225.348" x2="685.981201171875"
                                                        y2="231.348" stroke="#e0e0e0" stroke-dasharray="0"
                                                        stroke-linecap="butt" class="apexcharts-xaxis-tick"></line>
                                                    <line x1="783.978515625" y1="225.348" x2="783.978515625"
                                                        y2="231.348" stroke="#e0e0e0" stroke-dasharray="0"
                                                        stroke-linecap="butt" class="apexcharts-xaxis-tick"></line>
                                                    <g class="apexcharts-grid">
                                                        <g class="apexcharts-gridlines-horizontal">
                                                            <line x1="0" y1="75.116" x2="783.978515625" y2="75.116"
                                                                stroke="#e0e0e0" stroke-dasharray="0"
                                                                stroke-linecap="butt" class="apexcharts-gridline">
                                                            </line>
                                                            <line x1="0" y1="150.232" x2="783.978515625" y2="150.232"
                                                                stroke="#e0e0e0" stroke-dasharray="0"
                                                                stroke-linecap="butt" class="apexcharts-gridline">
                                                            </line>
                                                        </g>
                                                        <g class="apexcharts-gridlines-vertical"></g>
                                                        <line x1="0" y1="225.348" x2="783.978515625" y2="225.348"
                                                            stroke="transparent" stroke-dasharray="0"
                                                            stroke-linecap="butt"></line>
                                                        <line x1="0" y1="1" x2="0" y2="225.348" stroke="transparent"
                                                            stroke-dasharray="0" stroke-linecap="butt"></line>
                                                    </g>
                                                    <g class="apexcharts-grid-borders">
                                                        <line x1="0" y1="0" x2="783.978515625" y2="0" stroke="#e0e0e0"
                                                            stroke-dasharray="0" stroke-linecap="butt"
                                                            class="apexcharts-gridline"></line>
                                                        <line x1="0" y1="225.348" x2="783.978515625" y2="225.348"
                                                            stroke="#e0e0e0" stroke-dasharray="0" stroke-linecap="butt"
                                                            class="apexcharts-gridline"></line>
                                                        <line x1="0" y1="225.348" x2="783.978515625" y2="225.348"
                                                            stroke="#e0e0e0" stroke-dasharray="0" stroke-width="1"
                                                            stroke-linecap="butt"></line>
                                                    </g>
                                                    <g class="apexcharts-area-series apexcharts-plot-series">
                                                        <g class="apexcharts-series" zIndex="0" seriesName="x"
                                                            data:longestSeries="true" rel="1" data:realIndex="0">
                                                            <path
                                                                d="M 0 48.288857142857154C 34.299060058593746 48.288857142857154 63.69825439453124 150.23200000000003 97.99731445312499 150.23200000000003C 132.29637451171874 150.23200000000003 161.69556884765623 128.77028571428573 195.99462890624997 128.77028571428573C 230.29368896484374 128.77028571428573 259.69288330078126 182.42457142857143 293.991943359375 182.42457142857143C 328.29100341796874 182.42457142857143 357.6901977539062 26.82714285714286 391.98925781249994 26.82714285714286C 426.2883178710937 26.82714285714286 455.6875122070312 177.0591428571429 489.98657226562494 177.0591428571429C 524.2856323242187 177.0591428571429 553.6848266601562 123.40485714285717 587.98388671875 123.40485714285717C 622.2829467773438 123.40485714285717 651.6821411132812 118.03942857142857 685.981201171875 118.03942857142857C 720.2802612304687 118.03942857142857 749.6794555664062 16.096285714285727 783.9785156249999 16.096285714285727C 783.9785156249999 16.096285714285727 783.9785156249999 16.096285714285727 783.9785156249999 225.348 L 0 225.348z"
                                                                fill="rgba(49,124,111,0.1)" fill-opacity="1"
                                                                stroke="none" stroke-opacity="1" stroke-linecap="butt"
                                                                stroke-width="0" stroke-dasharray="0"
                                                                class="apexcharts-area" index="0"
                                                                clip-path="url(#gridRectMask9gnylr29)"
                                                                pathTo="M 0 48.288857142857154C 34.299060058593746 48.288857142857154 63.69825439453124 150.23200000000003 97.99731445312499 150.23200000000003C 132.29637451171874 150.23200000000003 161.69556884765623 128.77028571428573 195.99462890624997 128.77028571428573C 230.29368896484374 128.77028571428573 259.69288330078126 182.42457142857143 293.991943359375 182.42457142857143C 328.29100341796874 182.42457142857143 357.6901977539062 26.82714285714286 391.98925781249994 26.82714285714286C 426.2883178710937 26.82714285714286 455.6875122070312 177.0591428571429 489.98657226562494 177.0591428571429C 524.2856323242187 177.0591428571429 553.6848266601562 123.40485714285717 587.98388671875 123.40485714285717C 622.2829467773438 123.40485714285717 651.6821411132812 118.03942857142857 685.981201171875 118.03942857142857C 720.2802612304687 118.03942857142857 749.6794555664062 16.096285714285727 783.9785156249999 16.096285714285727C 783.9785156249999 16.096285714285727 783.9785156249999 16.096285714285727 783.9785156249999 225.348 L 0 225.348z"
                                                                pathFrom="M 0 225.348 L 0 225.348 L 97.99731445312499 225.348 L 195.99462890624997 225.348 L 293.991943359375 225.348 L 391.98925781249994 225.348 L 489.98657226562494 225.348 L 587.98388671875 225.348 L 685.981201171875 225.348 L 783.9785156249999 225.348z">
                                                            </path>
                                                            <path
                                                                d="M 0 48.288857142857154C 34.299060058593746 48.288857142857154 63.69825439453124 150.23200000000003 97.99731445312499 150.23200000000003C 132.29637451171874 150.23200000000003 161.69556884765623 128.77028571428573 195.99462890624997 128.77028571428573C 230.29368896484374 128.77028571428573 259.69288330078126 182.42457142857143 293.991943359375 182.42457142857143C 328.29100341796874 182.42457142857143 357.6901977539062 26.82714285714286 391.98925781249994 26.82714285714286C 426.2883178710937 26.82714285714286 455.6875122070312 177.0591428571429 489.98657226562494 177.0591428571429C 524.2856323242187 177.0591428571429 553.6848266601562 123.40485714285717 587.98388671875 123.40485714285717C 622.2829467773438 123.40485714285717 651.6821411132812 118.03942857142857 685.981201171875 118.03942857142857C 720.2802612304687 118.03942857142857 749.6794555664062 16.096285714285727 783.9785156249999 16.096285714285727"
                                                                fill="none" fill-opacity="1" stroke="#317c6f"
                                                                stroke-opacity="1" stroke-linecap="butt"
                                                                stroke-width="4" stroke-dasharray="0"
                                                                class="apexcharts-area" index="0"
                                                                clip-path="url(#gridRectMask9gnylr29)"
                                                                pathTo="M 0 48.288857142857154C 34.299060058593746 48.288857142857154 63.69825439453124 150.23200000000003 97.99731445312499 150.23200000000003C 132.29637451171874 150.23200000000003 161.69556884765623 128.77028571428573 195.99462890624997 128.77028571428573C 230.29368896484374 128.77028571428573 259.69288330078126 182.42457142857143 293.991943359375 182.42457142857143C 328.29100341796874 182.42457142857143 357.6901977539062 26.82714285714286 391.98925781249994 26.82714285714286C 426.2883178710937 26.82714285714286 455.6875122070312 177.0591428571429 489.98657226562494 177.0591428571429C 524.2856323242187 177.0591428571429 553.6848266601562 123.40485714285717 587.98388671875 123.40485714285717C 622.2829467773438 123.40485714285717 651.6821411132812 118.03942857142857 685.981201171875 118.03942857142857C 720.2802612304687 118.03942857142857 749.6794555664062 16.096285714285727 783.9785156249999 16.096285714285727"
                                                                pathFrom="M 0 225.348 L 0 225.348 L 97.99731445312499 225.348 L 195.99462890624997 225.348 L 293.991943359375 225.348 L 391.98925781249994 225.348 L 489.98657226562494 225.348 L 587.98388671875 225.348 L 685.981201171875 225.348 L 783.9785156249999 225.348"
                                                                fill-rule="evenodd"></path>
                                                            <g class="apexcharts-series-markers-wrap apexcharts-hidden-element-shown"
                                                                data:realIndex="0">
                                                                <g class="apexcharts-series-markers">
                                                                    <path d="M 0, 0 
                                                      m -0, 0 
                                                      a 0,0 0 1,0 0,0 
                                                      a 0,0 0 1,0 -0,0" fill="#317c6f" fill-opacity="1"
                                                                        stroke="#ffffff" stroke-opacity="0.9"
                                                                        stroke-linecap="butt" stroke-width="2"
                                                                        stroke-dasharray="0" cx="0" cy="0"
                                                                        shape="circle"
                                                                        class="apexcharts-marker w8nqycnjz no-pointer-events"
                                                                        default-marker-size="0"></path>
                                                                </g>
                                                            </g>
                                                        </g>
                                                        <g class="apexcharts-datalabels" data:realIndex="0"></g>
                                                    </g>
                                                    <line x1="0" y1="0" x2="783.978515625" y2="0" stroke="#b6b6b6"
                                                        stroke-dasharray="0" stroke-width="1" stroke-linecap="butt"
                                                        class="apexcharts-ycrosshairs"></line>
                                                    <line x1="0" y1="0" x2="783.978515625" y2="0" stroke="#b6b6b6"
                                                        stroke-dasharray="0" stroke-width="0" stroke-linecap="butt"
                                                        class="apexcharts-ycrosshairs-hidden"></line>
                                                    <g class="apexcharts-xaxis" transform="translate(0, 0)">
                                                        <g class="apexcharts-xaxis-texts-g"
                                                            transform="translate(0, -4)">
                                                            <text x="0" y="253.348" text-anchor="middle"
                                                                dominant-baseline="auto" font-size="12px"
                                                                font-family="Helvetica, Arial, sans-serif"
                                                                font-weight="400" fill="#6d7074"
                                                                class="apexcharts-text apexcharts-xaxis-label "
                                                                style="font-family: Helvetica, Arial, sans-serif;">
                                                                <tspan>2/1</tspan>
                                                                <title>2/1</title>
                                                            </text>
                                                            <text x="97.997314453125" y="253.348" text-anchor="middle"
                                                                dominant-baseline="auto" font-size="12px"
                                                                font-family="Helvetica, Arial, sans-serif"
                                                                font-weight="400" fill="#6d7074"
                                                                class="apexcharts-text apexcharts-xaxis-label "
                                                                style="font-family: Helvetica, Arial, sans-serif;">
                                                                <tspan>2/2</tspan>
                                                                <title>2/2</title>
                                                            </text>
                                                            <text x="195.99462890625" y="253.348" text-anchor="middle"
                                                                dominant-baseline="auto" font-size="12px"
                                                                font-family="Helvetica, Arial, sans-serif"
                                                                font-weight="400" fill="#6d7074"
                                                                class="apexcharts-text apexcharts-xaxis-label "
                                                                style="font-family: Helvetica, Arial, sans-serif;">
                                                                <tspan>2/3</tspan>
                                                                <title>2/3</title>
                                                            </text>
                                                            <text x="293.991943359375" y="253.348" text-anchor="middle"
                                                                dominant-baseline="auto" font-size="12px"
                                                                font-family="Helvetica, Arial, sans-serif"
                                                                font-weight="400" fill="#6d7074"
                                                                class="apexcharts-text apexcharts-xaxis-label "
                                                                style="font-family: Helvetica, Arial, sans-serif;">
                                                                <tspan>2/4</tspan>
                                                                <title>2/4</title>
                                                            </text>
                                                            <text x="391.9892578125" y="253.348" text-anchor="middle"
                                                                dominant-baseline="auto" font-size="12px"
                                                                font-family="Helvetica, Arial, sans-serif"
                                                                font-weight="400" fill="#6d7074"
                                                                class="apexcharts-text apexcharts-xaxis-label "
                                                                style="font-family: Helvetica, Arial, sans-serif;">
                                                                <tspan>2/5</tspan>
                                                                <title>2/5</title>
                                                            </text>
                                                            <text x="489.986572265625" y="253.348" text-anchor="middle"
                                                                dominant-baseline="auto" font-size="12px"
                                                                font-family="Helvetica, Arial, sans-serif"
                                                                font-weight="400" fill="#6d7074"
                                                                class="apexcharts-text apexcharts-xaxis-label "
                                                                style="font-family: Helvetica, Arial, sans-serif;">
                                                                <tspan>2/6</tspan>
                                                                <title>2/6</title>
                                                            </text>
                                                            <text x="587.98388671875" y="253.348" text-anchor="middle"
                                                                dominant-baseline="auto" font-size="12px"
                                                                font-family="Helvetica, Arial, sans-serif"
                                                                font-weight="400" fill="#6d7074"
                                                                class="apexcharts-text apexcharts-xaxis-label "
                                                                style="font-family: Helvetica, Arial, sans-serif;">
                                                                <tspan>2/7</tspan>
                                                                <title>2/7</title>
                                                            </text>
                                                            <text x="685.981201171875" y="253.348" text-anchor="middle"
                                                                dominant-baseline="auto" font-size="12px"
                                                                font-family="Helvetica, Arial, sans-serif"
                                                                font-weight="400" fill="#6d7074"
                                                                class="apexcharts-text apexcharts-xaxis-label "
                                                                style="font-family: Helvetica, Arial, sans-serif;">
                                                                <tspan>2/8</tspan>
                                                                <title>2/8</title>
                                                            </text>
                                                            <text x="783.978515625" y="253.348" text-anchor="middle"
                                                                dominant-baseline="auto" font-size="12px"
                                                                font-family="Helvetica, Arial, sans-serif"
                                                                font-weight="400" fill="#6d7074"
                                                                class="apexcharts-text apexcharts-xaxis-label "
                                                                style="font-family: Helvetica, Arial, sans-serif;">
                                                                <tspan>2/9</tspan>
                                                                <title>2/9</title>
                                                            </text>
                                                        </g>
                                                    </g>
                                                    <g class="apexcharts-yaxis-annotations"></g>
                                                    <g class="apexcharts-xaxis-annotations"></g>
                                                    <g class="apexcharts-point-annotations"></g>
                                                </g>
                                            </svg>
                                            <div class="apexcharts-legend" style="max-height: 146.5px;"></div>
                                            <div class="apexcharts-tooltip apexcharts-theme-light">
                                                <div class="apexcharts-tooltip-title"
                                                    style="font-family: Helvetica, Arial, sans-serif; font-size: 12px;">
                                                </div>
                                                <div class="apexcharts-tooltip-series-group apexcharts-tooltip-series-group-0"
                                                    style="order: 1;">
                                                    <span class="apexcharts-tooltip-marker" shape="circle"
                                                        style="color: rgb(49, 124, 111);"></span>
                                                    <div class="apexcharts-tooltip-text"
                                                        style="font-family: Helvetica, Arial, sans-serif; font-size: 12px;">
                                                        <div class="apexcharts-tooltip-y-group"><span
                                                                class="apexcharts-tooltip-text-y-label"></span><span
                                                                class="apexcharts-tooltip-text-y-value"></span></div>
                                                        <div class="apexcharts-tooltip-goals-group"><span
                                                                class="apexcharts-tooltip-text-goals-label"></span><span
                                                                class="apexcharts-tooltip-text-goals-value"></span>
                                                        </div>
                                                        <div class="apexcharts-tooltip-z-group"><span
                                                                class="apexcharts-tooltip-text-z-label"></span><span
                                                                class="apexcharts-tooltip-text-z-value"></span></div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div
                                                class="apexcharts-xaxistooltip apexcharts-xaxistooltip-bottom apexcharts-theme-light">
                                                <div class="apexcharts-xaxistooltip-text"
                                                    style="font-family: Helvetica, Arial, sans-serif; font-size: 12px;">
                                                </div>
                                            </div>
                                            <div
                                                class="apexcharts-yaxistooltip apexcharts-yaxistooltip-0 apexcharts-yaxistooltip-left apexcharts-theme-light">
                                                <div class="apexcharts-yaxistooltip-text"></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="detalis-content mb-60" id="menu-sidebar-3">
                                <h4 class="title-content mb-16">Steps To Financial Excellence</h4>
                                <div class="desc mb-32 body-2 color-on-suface-variant-1">Our approach combines
                                    personalized strategies, data-driven insights, and dedicated support to help you
                                    reach your financial goals. Each step is crafted to maximize growth, reduce risk,
                                    and build lasting financial confidence.</div>
                                <div class="process-list style-column">
                                    <div class="process-item style-3 style-3-2">
                                        <div class="icon"><i class="icon-ChartPieSlice"></i></div>
                                        <div class="circle"></div>
                                        <div class="process-content">
                                            <h5><a href="#" class="name-process">Assessment &amp; Goal Setting</a></h5>
                                            <div class="desc body-2 color-on-suface-variant-1">We start by assessing
                                                your financial situation and setting realistic goals, creating a
                                                solid<br>foundation for a customized plan.</div>
                                        </div>
                                    </div>
                                    <div class="process-item style-3 style-3-2">
                                        <div class="icon"><i class="icon-Crosshair1"></i></div>
                                        <div class="circle"></div>
                                        <div class="process-content">
                                            <h5><a href="#" class="name-process">Plan Development</a></h5>
                                            <div class="desc body-2 color-on-suface-variant-1">Using insights from our
                                                assessment, we develop a unique strategy focused on asset growth, risk
                                                management, and long-term success.</div>
                                        </div>
                                    </div>
                                    <div class="process-item style-3 style-3-2">
                                        <div class="icon"><i class="icon-ChartLineUp"></i></div>
                                        <div class="process-content">
                                            <h5><a href="#" class="name-process">Ongoing Review</a></h5>
                                            <div class="desc body-2 color-on-suface-variant-1">We regularly review and
                                                adapt your plan to stay aligned with your evolving goals, ensuring you
                                                stay on track to lasting success.</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="detalis-content" id="menu-sidebar-4">
                                <h4 class="title-content mb-20">FAQs</h4>
                                <div class="wg-according" id="According1">
                                    <div class="according-item style-arrow style-small">
                                        <h6><a href="#according1" data-bs-toggle="collapse"
                                                class="title-according collapsed">What consulting services do you
                                                offer?<i class="icon-chevron-down"></i></a></h6>
                                        <div id="according1" class="collapse" data-bs-parent="#According1">
                                            <div class="according-content">
                                                <p>We conduct in-depth assessments of your business needs, industry
                                                    landscape, and competitive environment to develop customized
                                                    strategies that align with your specific goals.</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="according-item style-arrow style-small">
                                        <h6><a href="#according2" data-bs-toggle="collapse"
                                                class="title-according collapsed">How do your services integrate with
                                                existing business structures?<i class="icon-chevron-down"></i></a></h6>
                                        <div id="according2" class="collapse" data-bs-parent="#According1">
                                            <div class="according-content">
                                                <p>We conduct in-depth assessments of your business needs, industry
                                                    landscape, and competitive environment to develop customized
                                                    strategies that align with your specific goals.</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="according-item style-arrow style-small">
                                        <h6>
                                            <a href="#according3" data-bs-toggle="collapse"
                                                class="title-according collapsed">
                                                Can I tailor your consulting services to suit my business?<!-- --> <i
                                                    class="icon-chevron-down"></i>
                                            </a>
                                        </h6>
                                        <div id="according3" class="collapse" data-bs-parent="#According1">
                                            <div class="according-content">
                                                <p>We conduct in-depth assessments of your business needs, industry
                                                    landscape, and competitive environment to develop customized
                                                    strategies that align with your specific goals.</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="according-item style-arrow style-small">
                                        <h6><a href="#according4" data-bs-toggle="collapse"
                                                class="title-according collapsed">What kind of ongoing consultation do
                                                you offer after the initial service?<i
                                                    class="icon-chevron-down"></i></a></h6>
                                        <div id="according4" class="collapse" data-bs-parent="#According1">
                                            <div class="according-content">
                                                <p>We conduct in-depth assessments of your business needs, industry
                                                    landscape, and competitive environment to develop customized
                                                    strategies that align with your specific goals.</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane" id="tab-3" role="tabpanel">
                        <div class="service-details-content">
                            <div class="image-details image mb-60"><img alt="" loading="lazy" width="1070" height="602"
                                    decoding="async" data-nimg="1" class="lazyload" style="color:transparent"
                                    src="/image/section/img-details-service-3.jpg"></div>
                            <div class="detalis-content mb-60" id="menu-sidebar-1">
                                <h4 class="title-content mb-16">Retirement Planning Solutions</h4>
                                <div class="desc mb-16 body-2 color-on-suface-variant-1">Secure your retirement with our
                                    personalized planning service. We create strategies for steady income, inflation
                                    protection, and optimized growth. Enjoy financial confidence and be prepared for
                                    future needs.</div>
                                <div class="cols g-10">
                                    <div class="benefit-lists">
                                        <div class="benefit-items style-small mb-16">
                                            <div class="icon"><i class="icon-checkbox"></i></div>
                                            <div class="title">Reliable Retirement Income</div>
                                        </div>
                                        <div class="benefit-items style-small mb-16">
                                            <div class="icon"><i class="icon-checkbox"></i></div>
                                            <div class="title">Future Security and Peace of Mind</div>
                                        </div>
                                        <div class="benefit-items style-small">
                                            <div class="icon"><i class="icon-checkbox"></i></div>
                                            <div class="title">Asset Protection for Long-Term Stability</div>
                                        </div>
                                    </div>
                                    <div class="benefit-lists">
                                        <div class="benefit-items style-small mb-16">
                                            <div class="icon"><i class="icon-checkbox"></i></div>
                                            <div class="title">Reliable Income for Retirement</div>
                                        </div>
                                        <div class="benefit-items style-small mb-16">
                                            <div class="icon"><i class="icon-checkbox"></i></div>
                                            <div class="title">Personalized Approach to Retirement Goals</div>
                                        </div>
                                        <div class="benefit-items style-small">
                                            <div class="icon"><i class="icon-checkbox"></i></div>
                                            <div class="title">Inflation Protection for Lasting Savings</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="detalis-content mb-60" id="menu-sidebar-2">
                                <h4 class="title-content mb-16">Retirement Planning Performance Chart</h4>
                                <div class="desc mb-32 body-2 color-on-suface-variant-1">Visualize your retirement
                                    journey with our performance charts. Our service provides detailed charts tracking
                                    key indicators—savings growth, investment returns, and projected expenses—so you can
                                    see how your retirement plan aligns with your goals. Monitor your progress in
                                    real-time, make data-driven adjustments, and gain confidence in your financial
                                    future with clear, visual insights that keep your retirement plan on track.</div>
                                <div class="wg-box-chart">
                                    <div class="top-wg-box-char">
                                        <div class="left">
                                            <h5 class="color-on-suface-container">Revenue Generated</h5>
                                            <h5 class="number"><i class="icon-TrendUp"></i>18%</h5>
                                            <p class="color-on-suface-container">Compared to last year</p>
                                        </div>
                                        <div class="right">
                                            <div class="flat-animate-tab">
                                                <div class="wg-tab">
                                                    <ul class="tab-product mb-0" role="tablist">
                                                        <li class="nav-tab-item" role="presentation"><a href="#weekly"
                                                                data-bs-toggle="tab" role="tab" class="active text-btn"
                                                                aria-selected="true">Weekly</a></li>
                                                        <li class="nav-tab-item" role="presentation"><a href="#monthly"
                                                                data-bs-toggle="tab" role="tab" class="text-btn"
                                                                aria-selected="false" tabindex="-1">Monthly</a></li>
                                                    </ul>
                                                </div>
                                                <div class="tab-content">
                                                    <div class="tab-pane active show" id="weekly" role="tabpanel"></div>
                                                    <div class="tab-pane" id="monthly" role="tabpanel"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div id="line-chart-6" style="min-height: 308px;">
                                        <div id="apexchartscel3uxel"
                                            class="apexcharts-canvas apexchartscel3uxel apexcharts-theme-light"
                                            style="width: 848px; height: 293px;">
                                            <svg xmlns="http://www.w3.org/2000/svg" version="1.1"
                                                xmlns:xlink="http://www.w3.org/1999/xlink" class="apexcharts-svg"
                                                xmlns:data="ApexChartsNS" transform="translate(0, 0)" width="848"
                                                height="293">
                                                <foreignObject x="0" y="0" width="848" height="293">
                                                    <style type="text/css">
                                                        .apexcharts-flip-y {
                                                            transform: scaleY(-1) translateY(-100%);
                                                            transform-origin: top;
                                                            transform-box: fill-box;
                                                        }

                                                        .apexcharts-flip-x {
                                                            transform: scaleX(-1);
                                                            transform-origin: center;
                                                            transform-box: fill-box;
                                                        }

                                                        .apexcharts-legend {
                                                            display: flex;
                                                            overflow: auto;
                                                            padding: 0 10px;
                                                        }

                                                        .apexcharts-legend.apexcharts-legend-group-horizontal {
                                                            flex-direction: column;
                                                        }

                                                        .apexcharts-legend-group {
                                                            display: flex;
                                                        }

                                                        .apexcharts-legend-group-vertical {
                                                            flex-direction: column-reverse;
                                                        }

                                                        .apexcharts-legend.apx-legend-position-bottom,
                                                        .apexcharts-legend.apx-legend-position-top {
                                                            flex-wrap: wrap
                                                        }

                                                        .apexcharts-legend.apx-legend-position-right,
                                                        .apexcharts-legend.apx-legend-position-left {
                                                            flex-direction: column;
                                                            bottom: 0;
                                                        }

                                                        .apexcharts-legend.apx-legend-position-bottom.apexcharts-align-left,
                                                        .apexcharts-legend.apx-legend-position-top.apexcharts-align-left,
                                                        .apexcharts-legend.apx-legend-position-right,
                                                        .apexcharts-legend.apx-legend-position-left {
                                                            justify-content: flex-start;
                                                            align-items: flex-start;
                                                        }

                                                        .apexcharts-legend.apx-legend-position-bottom.apexcharts-align-center,
                                                        .apexcharts-legend.apx-legend-position-top.apexcharts-align-center {
                                                            justify-content: center;
                                                            align-items: center;
                                                        }

                                                        .apexcharts-legend.apx-legend-position-bottom.apexcharts-align-right,
                                                        .apexcharts-legend.apx-legend-position-top.apexcharts-align-right {
                                                            justify-content: flex-end;
                                                            align-items: flex-end;
                                                        }

                                                        .apexcharts-legend-series {
                                                            cursor: pointer;
                                                            line-height: normal;
                                                            display: flex;
                                                            align-items: center;
                                                        }

                                                        .apexcharts-legend-text {
                                                            position: relative;
                                                            font-size: 14px;
                                                        }

                                                        .apexcharts-legend-text *,
                                                        .apexcharts-legend-marker * {
                                                            pointer-events: none;
                                                        }

                                                        .apexcharts-legend-marker {
                                                            position: relative;
                                                            display: flex;
                                                            align-items: center;
                                                            justify-content: center;
                                                            cursor: pointer;
                                                            margin-right: 1px;
                                                        }

                                                        .apexcharts-legend-series.apexcharts-no-click {
                                                            cursor: auto;
                                                        }

                                                        .apexcharts-legend .apexcharts-hidden-zero-series,
                                                        .apexcharts-legend .apexcharts-hidden-null-series {
                                                            display: none !important;
                                                        }

                                                        .apexcharts-inactive-legend {
                                                            opacity: 0.45;
                                                        }
                                                    </style>
                                                </foreignObject>
                                                <rect width="0" height="0" x="0" y="0" rx="0" ry="0" opacity="1"
                                                    stroke-width="0" stroke="none" stroke-dasharray="0" fill="#fefefe">
                                                </rect>
                                                <g class="apexcharts-datalabels-group"
                                                    transform="translate(0, 0) scale(1)"></g>
                                                <g class="apexcharts-datalabels-group"
                                                    transform="translate(0, 0) scale(1)"></g>
                                                <g class="apexcharts-yaxis" rel="0"
                                                    transform="translate(24.021484375, 0)">
                                                    <g class="apexcharts-yaxis-texts-g">
                                                        <text x="20" y="34" text-anchor="end" dominant-baseline="auto"
                                                            font-size="12px" font-family="Helvetica, Arial, sans-serif"
                                                            font-weight="500" fill="#6d7074"
                                                            class="apexcharts-text apexcharts-yaxis-label "
                                                            style="font-family: Helvetica, Arial, sans-serif;">
                                                            <tspan>$52k</tspan>
                                                            <title>$52k</title>
                                                        </text>
                                                        <text x="20" y="109.116" text-anchor="end"
                                                            dominant-baseline="auto" font-size="12px"
                                                            font-family="Helvetica, Arial, sans-serif" font-weight="500"
                                                            fill="#6d7074"
                                                            class="apexcharts-text apexcharts-yaxis-label "
                                                            style="font-family: Helvetica, Arial, sans-serif;">
                                                            <tspan>$38k</tspan>
                                                            <title>$38k</title>
                                                        </text>
                                                        <text x="20" y="184.232" text-anchor="end"
                                                            dominant-baseline="auto" font-size="12px"
                                                            font-family="Helvetica, Arial, sans-serif" font-weight="500"
                                                            fill="#6d7074"
                                                            class="apexcharts-text apexcharts-yaxis-label "
                                                            style="font-family: Helvetica, Arial, sans-serif;">
                                                            <tspan>$24k</tspan>
                                                            <title>$24k</title>
                                                        </text>
                                                        <text x="20" y="259.348" text-anchor="end"
                                                            dominant-baseline="auto" font-size="12px"
                                                            font-family="Helvetica, Arial, sans-serif" font-weight="500"
                                                            fill="#6d7074"
                                                            class="apexcharts-text apexcharts-yaxis-label "
                                                            style="font-family: Helvetica, Arial, sans-serif;">
                                                            <tspan>$10k</tspan>
                                                            <title>$10k</title>
                                                        </text>
                                                    </g>
                                                </g>
                                                <g class="apexcharts-inner apexcharts-graphical"
                                                    transform="translate(54.021484375, 30)">
                                                    <defs>
                                                        <clipPath id="gridRectMaskcel3uxel">
                                                            <rect width="791.978515625" height="233.348" x="-4" y="-4"
                                                                rx="0" ry="0" opacity="1" stroke-width="0" stroke="none"
                                                                stroke-dasharray="0" fill="#fff"></rect>
                                                        </clipPath>
                                                        <clipPath id="gridRectBarMaskcel3uxel">
                                                            <rect width="791.978515625" height="233.348" x="-4" y="-4"
                                                                rx="0" ry="0" opacity="1" stroke-width="0" stroke="none"
                                                                stroke-dasharray="0" fill="#fff"></rect>
                                                        </clipPath>
                                                        <clipPath id="gridRectMarkerMaskcel3uxel">
                                                            <rect width="783.978515625" height="225.348" x="0" y="0"
                                                                rx="0" ry="0" opacity="1" stroke-width="0" stroke="none"
                                                                stroke-dasharray="0" fill="#fff"></rect>
                                                        </clipPath>
                                                        <clipPath id="forecastMaskcel3uxel"></clipPath>
                                                        <clipPath id="nonForecastMaskcel3uxel"></clipPath>
                                                    </defs>
                                                    <line x1="0" y1="0" x2="0" y2="225.348" stroke="#b6b6b6"
                                                        stroke-dasharray="3" stroke-linecap="butt"
                                                        class="apexcharts-xcrosshairs" x="0" y="0" width="1"
                                                        height="225.348" fill="#b1b9c4" filter="none" fill-opacity="0.9"
                                                        stroke-width="1"></line>
                                                    <line x1="0" y1="225.348" x2="0" y2="231.348" stroke="#e0e0e0"
                                                        stroke-dasharray="0" stroke-linecap="butt"
                                                        class="apexcharts-xaxis-tick"></line>
                                                    <line x1="97.997314453125" y1="225.348" x2="97.997314453125"
                                                        y2="231.348" stroke="#e0e0e0" stroke-dasharray="0"
                                                        stroke-linecap="butt" class="apexcharts-xaxis-tick"></line>
                                                    <line x1="195.99462890625" y1="225.348" x2="195.99462890625"
                                                        y2="231.348" stroke="#e0e0e0" stroke-dasharray="0"
                                                        stroke-linecap="butt" class="apexcharts-xaxis-tick"></line>
                                                    <line x1="293.991943359375" y1="225.348" x2="293.991943359375"
                                                        y2="231.348" stroke="#e0e0e0" stroke-dasharray="0"
                                                        stroke-linecap="butt" class="apexcharts-xaxis-tick"></line>
                                                    <line x1="391.9892578125" y1="225.348" x2="391.9892578125"
                                                        y2="231.348" stroke="#e0e0e0" stroke-dasharray="0"
                                                        stroke-linecap="butt" class="apexcharts-xaxis-tick"></line>
                                                    <line x1="489.986572265625" y1="225.348" x2="489.986572265625"
                                                        y2="231.348" stroke="#e0e0e0" stroke-dasharray="0"
                                                        stroke-linecap="butt" class="apexcharts-xaxis-tick"></line>
                                                    <line x1="587.98388671875" y1="225.348" x2="587.98388671875"
                                                        y2="231.348" stroke="#e0e0e0" stroke-dasharray="0"
                                                        stroke-linecap="butt" class="apexcharts-xaxis-tick"></line>
                                                    <line x1="685.981201171875" y1="225.348" x2="685.981201171875"
                                                        y2="231.348" stroke="#e0e0e0" stroke-dasharray="0"
                                                        stroke-linecap="butt" class="apexcharts-xaxis-tick"></line>
                                                    <line x1="783.978515625" y1="225.348" x2="783.978515625"
                                                        y2="231.348" stroke="#e0e0e0" stroke-dasharray="0"
                                                        stroke-linecap="butt" class="apexcharts-xaxis-tick"></line>
                                                    <g class="apexcharts-grid">
                                                        <g class="apexcharts-gridlines-horizontal">
                                                            <line x1="0" y1="75.116" x2="783.978515625" y2="75.116"
                                                                stroke="#e0e0e0" stroke-dasharray="0"
                                                                stroke-linecap="butt" class="apexcharts-gridline">
                                                            </line>
                                                            <line x1="0" y1="150.232" x2="783.978515625" y2="150.232"
                                                                stroke="#e0e0e0" stroke-dasharray="0"
                                                                stroke-linecap="butt" class="apexcharts-gridline">
                                                            </line>
                                                        </g>
                                                        <g class="apexcharts-gridlines-vertical"></g>
                                                        <line x1="0" y1="225.348" x2="783.978515625" y2="225.348"
                                                            stroke="transparent" stroke-dasharray="0"
                                                            stroke-linecap="butt"></line>
                                                        <line x1="0" y1="1" x2="0" y2="225.348" stroke="transparent"
                                                            stroke-dasharray="0" stroke-linecap="butt"></line>
                                                    </g>
                                                    <g class="apexcharts-grid-borders">
                                                        <line x1="0" y1="0" x2="783.978515625" y2="0" stroke="#e0e0e0"
                                                            stroke-dasharray="0" stroke-linecap="butt"
                                                            class="apexcharts-gridline"></line>
                                                        <line x1="0" y1="225.348" x2="783.978515625" y2="225.348"
                                                            stroke="#e0e0e0" stroke-dasharray="0" stroke-linecap="butt"
                                                            class="apexcharts-gridline"></line>
                                                        <line x1="0" y1="225.348" x2="783.978515625" y2="225.348"
                                                            stroke="#e0e0e0" stroke-dasharray="0" stroke-width="1"
                                                            stroke-linecap="butt"></line>
                                                    </g>
                                                    <g class="apexcharts-area-series apexcharts-plot-series">
                                                        <g class="apexcharts-series" zIndex="0" seriesName="x"
                                                            data:longestSeries="true" rel="1" data:realIndex="0">
                                                            <path
                                                                d="M 0 48.288857142857154C 34.299060058593746 48.288857142857154 63.69825439453124 150.23200000000003 97.99731445312499 150.23200000000003C 132.29637451171874 150.23200000000003 161.69556884765623 128.77028571428573 195.99462890624997 128.77028571428573C 230.29368896484374 128.77028571428573 259.69288330078126 182.42457142857143 293.991943359375 182.42457142857143C 328.29100341796874 182.42457142857143 357.6901977539062 26.82714285714286 391.98925781249994 26.82714285714286C 426.2883178710937 26.82714285714286 455.6875122070312 177.0591428571429 489.98657226562494 177.0591428571429C 524.2856323242187 177.0591428571429 553.6848266601562 123.40485714285717 587.98388671875 123.40485714285717C 622.2829467773438 123.40485714285717 651.6821411132812 118.03942857142857 685.981201171875 118.03942857142857C 720.2802612304687 118.03942857142857 749.6794555664062 16.096285714285727 783.9785156249999 16.096285714285727C 783.9785156249999 16.096285714285727 783.9785156249999 16.096285714285727 783.9785156249999 225.348 L 0 225.348z"
                                                                fill="rgba(49,124,111,0.1)" fill-opacity="1"
                                                                stroke="none" stroke-opacity="1" stroke-linecap="butt"
                                                                stroke-width="0" stroke-dasharray="0"
                                                                class="apexcharts-area" index="0"
                                                                clip-path="url(#gridRectMaskcel3uxel)"
                                                                pathTo="M 0 48.288857142857154C 34.299060058593746 48.288857142857154 63.69825439453124 150.23200000000003 97.99731445312499 150.23200000000003C 132.29637451171874 150.23200000000003 161.69556884765623 128.77028571428573 195.99462890624997 128.77028571428573C 230.29368896484374 128.77028571428573 259.69288330078126 182.42457142857143 293.991943359375 182.42457142857143C 328.29100341796874 182.42457142857143 357.6901977539062 26.82714285714286 391.98925781249994 26.82714285714286C 426.2883178710937 26.82714285714286 455.6875122070312 177.0591428571429 489.98657226562494 177.0591428571429C 524.2856323242187 177.0591428571429 553.6848266601562 123.40485714285717 587.98388671875 123.40485714285717C 622.2829467773438 123.40485714285717 651.6821411132812 118.03942857142857 685.981201171875 118.03942857142857C 720.2802612304687 118.03942857142857 749.6794555664062 16.096285714285727 783.9785156249999 16.096285714285727C 783.9785156249999 16.096285714285727 783.9785156249999 16.096285714285727 783.9785156249999 225.348 L 0 225.348z"
                                                                pathFrom="M 0 225.348 L 0 225.348 L 97.99731445312499 225.348 L 195.99462890624997 225.348 L 293.991943359375 225.348 L 391.98925781249994 225.348 L 489.98657226562494 225.348 L 587.98388671875 225.348 L 685.981201171875 225.348 L 783.9785156249999 225.348z">
                                                            </path>
                                                            <path
                                                                d="M 0 48.288857142857154C 34.299060058593746 48.288857142857154 63.69825439453124 150.23200000000003 97.99731445312499 150.23200000000003C 132.29637451171874 150.23200000000003 161.69556884765623 128.77028571428573 195.99462890624997 128.77028571428573C 230.29368896484374 128.77028571428573 259.69288330078126 182.42457142857143 293.991943359375 182.42457142857143C 328.29100341796874 182.42457142857143 357.6901977539062 26.82714285714286 391.98925781249994 26.82714285714286C 426.2883178710937 26.82714285714286 455.6875122070312 177.0591428571429 489.98657226562494 177.0591428571429C 524.2856323242187 177.0591428571429 553.6848266601562 123.40485714285717 587.98388671875 123.40485714285717C 622.2829467773438 123.40485714285717 651.6821411132812 118.03942857142857 685.981201171875 118.03942857142857C 720.2802612304687 118.03942857142857 749.6794555664062 16.096285714285727 783.9785156249999 16.096285714285727"
                                                                fill="none" fill-opacity="1" stroke="#317c6f"
                                                                stroke-opacity="1" stroke-linecap="butt"
                                                                stroke-width="4" stroke-dasharray="0"
                                                                class="apexcharts-area" index="0"
                                                                clip-path="url(#gridRectMaskcel3uxel)"
                                                                pathTo="M 0 48.288857142857154C 34.299060058593746 48.288857142857154 63.69825439453124 150.23200000000003 97.99731445312499 150.23200000000003C 132.29637451171874 150.23200000000003 161.69556884765623 128.77028571428573 195.99462890624997 128.77028571428573C 230.29368896484374 128.77028571428573 259.69288330078126 182.42457142857143 293.991943359375 182.42457142857143C 328.29100341796874 182.42457142857143 357.6901977539062 26.82714285714286 391.98925781249994 26.82714285714286C 426.2883178710937 26.82714285714286 455.6875122070312 177.0591428571429 489.98657226562494 177.0591428571429C 524.2856323242187 177.0591428571429 553.6848266601562 123.40485714285717 587.98388671875 123.40485714285717C 622.2829467773438 123.40485714285717 651.6821411132812 118.03942857142857 685.981201171875 118.03942857142857C 720.2802612304687 118.03942857142857 749.6794555664062 16.096285714285727 783.9785156249999 16.096285714285727"
                                                                pathFrom="M 0 225.348 L 0 225.348 L 97.99731445312499 225.348 L 195.99462890624997 225.348 L 293.991943359375 225.348 L 391.98925781249994 225.348 L 489.98657226562494 225.348 L 587.98388671875 225.348 L 685.981201171875 225.348 L 783.9785156249999 225.348"
                                                                fill-rule="evenodd"></path>
                                                            <g class="apexcharts-series-markers-wrap apexcharts-hidden-element-shown"
                                                                data:realIndex="0">
                                                                <g class="apexcharts-series-markers">
                                                                    <path d="M 0, 0 
                                                      m -0, 0 
                                                      a 0,0 0 1,0 0,0 
                                                      a 0,0 0 1,0 -0,0" fill="#317c6f" fill-opacity="1"
                                                                        stroke="#ffffff" stroke-opacity="0.9"
                                                                        stroke-linecap="butt" stroke-width="2"
                                                                        stroke-dasharray="0" cx="0" cy="0"
                                                                        shape="circle"
                                                                        class="apexcharts-marker w3j1fioqc no-pointer-events"
                                                                        default-marker-size="0"></path>
                                                                </g>
                                                            </g>
                                                        </g>
                                                        <g class="apexcharts-datalabels" data:realIndex="0"></g>
                                                    </g>
                                                    <line x1="0" y1="0" x2="783.978515625" y2="0" stroke="#b6b6b6"
                                                        stroke-dasharray="0" stroke-width="1" stroke-linecap="butt"
                                                        class="apexcharts-ycrosshairs"></line>
                                                    <line x1="0" y1="0" x2="783.978515625" y2="0" stroke="#b6b6b6"
                                                        stroke-dasharray="0" stroke-width="0" stroke-linecap="butt"
                                                        class="apexcharts-ycrosshairs-hidden"></line>
                                                    <g class="apexcharts-xaxis" transform="translate(0, 0)">
                                                        <g class="apexcharts-xaxis-texts-g"
                                                            transform="translate(0, -4)">
                                                            <text x="0" y="253.348" text-anchor="middle"
                                                                dominant-baseline="auto" font-size="12px"
                                                                font-family="Helvetica, Arial, sans-serif"
                                                                font-weight="400" fill="#6d7074"
                                                                class="apexcharts-text apexcharts-xaxis-label "
                                                                style="font-family: Helvetica, Arial, sans-serif;">
                                                                <tspan>2/1</tspan>
                                                                <title>2/1</title>
                                                            </text>
                                                            <text x="97.997314453125" y="253.348" text-anchor="middle"
                                                                dominant-baseline="auto" font-size="12px"
                                                                font-family="Helvetica, Arial, sans-serif"
                                                                font-weight="400" fill="#6d7074"
                                                                class="apexcharts-text apexcharts-xaxis-label "
                                                                style="font-family: Helvetica, Arial, sans-serif;">
                                                                <tspan>2/2</tspan>
                                                                <title>2/2</title>
                                                            </text>
                                                            <text x="195.99462890625" y="253.348" text-anchor="middle"
                                                                dominant-baseline="auto" font-size="12px"
                                                                font-family="Helvetica, Arial, sans-serif"
                                                                font-weight="400" fill="#6d7074"
                                                                class="apexcharts-text apexcharts-xaxis-label "
                                                                style="font-family: Helvetica, Arial, sans-serif;">
                                                                <tspan>2/3</tspan>
                                                                <title>2/3</title>
                                                            </text>
                                                            <text x="293.991943359375" y="253.348" text-anchor="middle"
                                                                dominant-baseline="auto" font-size="12px"
                                                                font-family="Helvetica, Arial, sans-serif"
                                                                font-weight="400" fill="#6d7074"
                                                                class="apexcharts-text apexcharts-xaxis-label "
                                                                style="font-family: Helvetica, Arial, sans-serif;">
                                                                <tspan>2/4</tspan>
                                                                <title>2/4</title>
                                                            </text>
                                                            <text x="391.9892578125" y="253.348" text-anchor="middle"
                                                                dominant-baseline="auto" font-size="12px"
                                                                font-family="Helvetica, Arial, sans-serif"
                                                                font-weight="400" fill="#6d7074"
                                                                class="apexcharts-text apexcharts-xaxis-label "
                                                                style="font-family: Helvetica, Arial, sans-serif;">
                                                                <tspan>2/5</tspan>
                                                                <title>2/5</title>
                                                            </text>
                                                            <text x="489.986572265625" y="253.348" text-anchor="middle"
                                                                dominant-baseline="auto" font-size="12px"
                                                                font-family="Helvetica, Arial, sans-serif"
                                                                font-weight="400" fill="#6d7074"
                                                                class="apexcharts-text apexcharts-xaxis-label "
                                                                style="font-family: Helvetica, Arial, sans-serif;">
                                                                <tspan>2/6</tspan>
                                                                <title>2/6</title>
                                                            </text>
                                                            <text x="587.98388671875" y="253.348" text-anchor="middle"
                                                                dominant-baseline="auto" font-size="12px"
                                                                font-family="Helvetica, Arial, sans-serif"
                                                                font-weight="400" fill="#6d7074"
                                                                class="apexcharts-text apexcharts-xaxis-label "
                                                                style="font-family: Helvetica, Arial, sans-serif;">
                                                                <tspan>2/7</tspan>
                                                                <title>2/7</title>
                                                            </text>
                                                            <text x="685.981201171875" y="253.348" text-anchor="middle"
                                                                dominant-baseline="auto" font-size="12px"
                                                                font-family="Helvetica, Arial, sans-serif"
                                                                font-weight="400" fill="#6d7074"
                                                                class="apexcharts-text apexcharts-xaxis-label "
                                                                style="font-family: Helvetica, Arial, sans-serif;">
                                                                <tspan>2/8</tspan>
                                                                <title>2/8</title>
                                                            </text>
                                                            <text x="783.978515625" y="253.348" text-anchor="middle"
                                                                dominant-baseline="auto" font-size="12px"
                                                                font-family="Helvetica, Arial, sans-serif"
                                                                font-weight="400" fill="#6d7074"
                                                                class="apexcharts-text apexcharts-xaxis-label "
                                                                style="font-family: Helvetica, Arial, sans-serif;">
                                                                <tspan>2/9</tspan>
                                                                <title>2/9</title>
                                                            </text>
                                                        </g>
                                                    </g>
                                                    <g class="apexcharts-yaxis-annotations"></g>
                                                    <g class="apexcharts-xaxis-annotations"></g>
                                                    <g class="apexcharts-point-annotations"></g>
                                                </g>
                                            </svg>
                                            <div class="apexcharts-legend" style="max-height: 146.5px;"></div>
                                            <div class="apexcharts-tooltip apexcharts-theme-light">
                                                <div class="apexcharts-tooltip-title"
                                                    style="font-family: Helvetica, Arial, sans-serif; font-size: 12px;">
                                                </div>
                                                <div class="apexcharts-tooltip-series-group apexcharts-tooltip-series-group-0"
                                                    style="order: 1;">
                                                    <span class="apexcharts-tooltip-marker" shape="circle"
                                                        style="color: rgb(49, 124, 111);"></span>
                                                    <div class="apexcharts-tooltip-text"
                                                        style="font-family: Helvetica, Arial, sans-serif; font-size: 12px;">
                                                        <div class="apexcharts-tooltip-y-group"><span
                                                                class="apexcharts-tooltip-text-y-label"></span><span
                                                                class="apexcharts-tooltip-text-y-value"></span></div>
                                                        <div class="apexcharts-tooltip-goals-group"><span
                                                                class="apexcharts-tooltip-text-goals-label"></span><span
                                                                class="apexcharts-tooltip-text-goals-value"></span>
                                                        </div>
                                                        <div class="apexcharts-tooltip-z-group"><span
                                                                class="apexcharts-tooltip-text-z-label"></span><span
                                                                class="apexcharts-tooltip-text-z-value"></span></div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div
                                                class="apexcharts-xaxistooltip apexcharts-xaxistooltip-bottom apexcharts-theme-light">
                                                <div class="apexcharts-xaxistooltip-text"
                                                    style="font-family: Helvetica, Arial, sans-serif; font-size: 12px;">
                                                </div>
                                            </div>
                                            <div
                                                class="apexcharts-yaxistooltip apexcharts-yaxistooltip-0 apexcharts-yaxistooltip-left apexcharts-theme-light">
                                                <div class="apexcharts-yaxistooltip-text"></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="detalis-content mb-60" id="menu-sidebar-3">
                                <h4 class="title-content mb-16">Steps To Financial Excellence</h4>
                                <div class="desc mb-32 body-2 color-on-suface-variant-1">Our approach combines
                                    personalized strategies, data-driven insights, and dedicated support to help you
                                    reach your financial goals. Each step is crafted to maximize growth, reduce risk,
                                    and build lasting financial confidence.</div>
                                <div class="process-list style-column">
                                    <div class="process-item style-3 style-3-2">
                                        <div class="icon"><i class="icon-ChartPieSlice"></i></div>
                                        <div class="circle"></div>
                                        <div class="process-content">
                                            <h5><a href="#" class="name-process">Assessment &amp; Goal Setting</a></h5>
                                            <div class="desc body-2 color-on-suface-variant-1">We start by assessing
                                                your financial situation and setting realistic goals, creating a
                                                solid<br>foundation for a customized plan.</div>
                                        </div>
                                    </div>
                                    <div class="process-item style-3 style-3-2">
                                        <div class="icon"><i class="icon-Crosshair1"></i></div>
                                        <div class="circle"></div>
                                        <div class="process-content">
                                            <h5><a href="#" class="name-process">Plan Development</a></h5>
                                            <div class="desc body-2 color-on-suface-variant-1">Using insights from our
                                                assessment, we develop a unique strategy focused on asset growth, risk
                                                management, and long-term success.</div>
                                        </div>
                                    </div>
                                    <div class="process-item style-3 style-3-2">
                                        <div class="icon"><i class="icon-ChartLineUp"></i></div>
                                        <div class="process-content">
                                            <h5><a href="#" class="name-process">Ongoing Review</a></h5>
                                            <div class="desc body-2 color-on-suface-variant-1">We regularly review and
                                                adapt your plan to stay aligned with your evolving goals, ensuring you
                                                stay on track to lasting success.</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="detalis-content" id="menu-sidebar-4">
                                <h4 class="title-content mb-20">FAQs</h4>
                                <div class="wg-according" id="According1">
                                    <div class="according-item style-arrow style-small">
                                        <h6><a href="#according1" data-bs-toggle="collapse"
                                                class="title-according collapsed">What consulting services do you
                                                offer?<i class="icon-chevron-down"></i></a></h6>
                                        <div id="according1" class="collapse" data-bs-parent="#According1">
                                            <div class="according-content">
                                                <p>We conduct in-depth assessments of your business needs, industry
                                                    landscape, and competitive environment to develop customized
                                                    strategies that align with your specific goals.</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="according-item style-arrow style-small">
                                        <h6><a href="#according2" data-bs-toggle="collapse"
                                                class="title-according collapsed">How do your services integrate with
                                                existing business structures?<i class="icon-chevron-down"></i></a></h6>
                                        <div id="according2" class="collapse" data-bs-parent="#According1">
                                            <div class="according-content">
                                                <p>We conduct in-depth assessments of your business needs, industry
                                                    landscape, and competitive environment to develop customized
                                                    strategies that align with your specific goals.</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="according-item style-arrow style-small">
                                        <h6>
                                            <a href="#according3" data-bs-toggle="collapse"
                                                class="title-according collapsed">
                                                Can I tailor your consulting services to suit my business?<!-- --> <i
                                                    class="icon-chevron-down"></i>
                                            </a>
                                        </h6>
                                        <div id="according3" class="collapse" data-bs-parent="#According1">
                                            <div class="according-content">
                                                <p>We conduct in-depth assessments of your business needs, industry
                                                    landscape, and competitive environment to develop customized
                                                    strategies that align with your specific goals.</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="according-item style-arrow style-small">
                                        <h6><a href="#according4" data-bs-toggle="collapse"
                                                class="title-according collapsed">What kind of ongoing consultation do
                                                you offer after the initial service?<i
                                                    class="icon-chevron-down"></i></a></h6>
                                        <div id="according4" class="collapse" data-bs-parent="#According1">
                                            <div class="according-content">
                                                <p>We conduct in-depth assessments of your business needs, industry
                                                    landscape, and competitive environment to develop customized
                                                    strategies that align with your specific goals.</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane" id="tab-4" role="tabpanel">
                        <div class="service-details-content">
                            <div class="image-details image mb-60"><img alt="" loading="lazy" width="1275" height="768"
                                    decoding="async" data-nimg="1" class="lazyload" style="color:transparent"
                                    src="/image/section/img-details-service-4.jpg"></div>
                            <div class="detalis-content mb-60" id="menu-sidebar-1">
                                <h4 class="title-content mb-16">Retirement Planning Solutions</h4>
                                <div class="desc mb-16 body-2 color-on-suface-variant-1">Secure your retirement with our
                                    personalized planning service. We create strategies for steady income, inflation
                                    protection, and optimized growth. Enjoy financial confidence and be prepared for
                                    future needs.</div>
                                <div class="cols g-10">
                                    <div class="benefit-lists">
                                        <div class="benefit-items style-small mb-16">
                                            <div class="icon"><i class="icon-checkbox"></i></div>
                                            <div class="title">Reliable Retirement Income</div>
                                        </div>
                                        <div class="benefit-items style-small mb-16">
                                            <div class="icon"><i class="icon-checkbox"></i></div>
                                            <div class="title">Future Security and Peace of Mind</div>
                                        </div>
                                        <div class="benefit-items style-small">
                                            <div class="icon"><i class="icon-checkbox"></i></div>
                                            <div class="title">Asset Protection for Long-Term Stability</div>
                                        </div>
                                    </div>
                                    <div class="benefit-lists">
                                        <div class="benefit-items style-small mb-16">
                                            <div class="icon"><i class="icon-checkbox"></i></div>
                                            <div class="title">Reliable Income for Retirement</div>
                                        </div>
                                        <div class="benefit-items style-small mb-16">
                                            <div class="icon"><i class="icon-checkbox"></i></div>
                                            <div class="title">Personalized Approach to Retirement Goals</div>
                                        </div>
                                        <div class="benefit-items style-small">
                                            <div class="icon"><i class="icon-checkbox"></i></div>
                                            <div class="title">Inflation Protection for Lasting Savings</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="detalis-content mb-60" id="menu-sidebar-2">
                                <h4 class="title-content mb-16">Retirement Planning Performance Chart</h4>
                                <div class="desc mb-32 body-2 color-on-suface-variant-1">Visualize your retirement
                                    journey with our performance charts. Our service provides detailed charts tracking
                                    key indicators—savings growth, investment returns, and projected expenses—so you can
                                    see how your retirement plan aligns with your goals. Monitor your progress in
                                    real-time, make data-driven adjustments, and gain confidence in your financial
                                    future with clear, visual insights that keep your retirement plan on track.</div>
                                <div class="wg-box-chart">
                                    <div class="top-wg-box-char">
                                        <div class="left">
                                            <h5 class="color-on-suface-container">Revenue Generated</h5>
                                            <h5 class="number"><i class="icon-TrendUp"></i>18%</h5>
                                            <p class="color-on-suface-container">Compared to last year</p>
                                        </div>
                                        <div class="right">
                                            <div class="flat-animate-tab">
                                                <div class="wg-tab">
                                                    <ul class="tab-product mb-0" role="tablist">
                                                        <li class="nav-tab-item" role="presentation"><a href="#weekly"
                                                                data-bs-toggle="tab" role="tab" class="active text-btn"
                                                                aria-selected="true">Weekly</a></li>
                                                        <li class="nav-tab-item" role="presentation"><a href="#monthly"
                                                                data-bs-toggle="tab" role="tab" class="text-btn"
                                                                aria-selected="false" tabindex="-1">Monthly</a></li>
                                                    </ul>
                                                </div>
                                                <div class="tab-content">
                                                    <div class="tab-pane active show" id="weekly" role="tabpanel"></div>
                                                    <div class="tab-pane" id="monthly" role="tabpanel"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div id="line-chart-6" style="min-height: 308px;">
                                        <div id="apexcharts7ob2tt53"
                                            class="apexcharts-canvas apexcharts7ob2tt53 apexcharts-theme-light"
                                            style="width: 848px; height: 293px;">
                                            <svg xmlns="http://www.w3.org/2000/svg" version="1.1"
                                                xmlns:xlink="http://www.w3.org/1999/xlink" class="apexcharts-svg"
                                                xmlns:data="ApexChartsNS" transform="translate(0, 0)" width="848"
                                                height="293">
                                                <foreignObject x="0" y="0" width="848" height="293">
                                                    <style type="text/css">
                                                        .apexcharts-flip-y {
                                                            transform: scaleY(-1) translateY(-100%);
                                                            transform-origin: top;
                                                            transform-box: fill-box;
                                                        }

                                                        .apexcharts-flip-x {
                                                            transform: scaleX(-1);
                                                            transform-origin: center;
                                                            transform-box: fill-box;
                                                        }

                                                        .apexcharts-legend {
                                                            display: flex;
                                                            overflow: auto;
                                                            padding: 0 10px;
                                                        }

                                                        .apexcharts-legend.apexcharts-legend-group-horizontal {
                                                            flex-direction: column;
                                                        }

                                                        .apexcharts-legend-group {
                                                            display: flex;
                                                        }

                                                        .apexcharts-legend-group-vertical {
                                                            flex-direction: column-reverse;
                                                        }

                                                        .apexcharts-legend.apx-legend-position-bottom,
                                                        .apexcharts-legend.apx-legend-position-top {
                                                            flex-wrap: wrap
                                                        }

                                                        .apexcharts-legend.apx-legend-position-right,
                                                        .apexcharts-legend.apx-legend-position-left {
                                                            flex-direction: column;
                                                            bottom: 0;
                                                        }

                                                        .apexcharts-legend.apx-legend-position-bottom.apexcharts-align-left,
                                                        .apexcharts-legend.apx-legend-position-top.apexcharts-align-left,
                                                        .apexcharts-legend.apx-legend-position-right,
                                                        .apexcharts-legend.apx-legend-position-left {
                                                            justify-content: flex-start;
                                                            align-items: flex-start;
                                                        }

                                                        .apexcharts-legend.apx-legend-position-bottom.apexcharts-align-center,
                                                        .apexcharts-legend.apx-legend-position-top.apexcharts-align-center {
                                                            justify-content: center;
                                                            align-items: center;
                                                        }

                                                        .apexcharts-legend.apx-legend-position-bottom.apexcharts-align-right,
                                                        .apexcharts-legend.apx-legend-position-top.apexcharts-align-right {
                                                            justify-content: flex-end;
                                                            align-items: flex-end;
                                                        }

                                                        .apexcharts-legend-series {
                                                            cursor: pointer;
                                                            line-height: normal;
                                                            display: flex;
                                                            align-items: center;
                                                        }

                                                        .apexcharts-legend-text {
                                                            position: relative;
                                                            font-size: 14px;
                                                        }

                                                        .apexcharts-legend-text *,
                                                        .apexcharts-legend-marker * {
                                                            pointer-events: none;
                                                        }

                                                        .apexcharts-legend-marker {
                                                            position: relative;
                                                            display: flex;
                                                            align-items: center;
                                                            justify-content: center;
                                                            cursor: pointer;
                                                            margin-right: 1px;
                                                        }

                                                        .apexcharts-legend-series.apexcharts-no-click {
                                                            cursor: auto;
                                                        }

                                                        .apexcharts-legend .apexcharts-hidden-zero-series,
                                                        .apexcharts-legend .apexcharts-hidden-null-series {
                                                            display: none !important;
                                                        }

                                                        .apexcharts-inactive-legend {
                                                            opacity: 0.45;
                                                        }
                                                    </style>
                                                </foreignObject>
                                                <rect width="0" height="0" x="0" y="0" rx="0" ry="0" opacity="1"
                                                    stroke-width="0" stroke="none" stroke-dasharray="0" fill="#fefefe">
                                                </rect>
                                                <g class="apexcharts-datalabels-group"
                                                    transform="translate(0, 0) scale(1)"></g>
                                                <g class="apexcharts-datalabels-group"
                                                    transform="translate(0, 0) scale(1)"></g>
                                                <g class="apexcharts-yaxis" rel="0"
                                                    transform="translate(24.021484375, 0)">
                                                    <g class="apexcharts-yaxis-texts-g">
                                                        <text x="20" y="34" text-anchor="end" dominant-baseline="auto"
                                                            font-size="12px" font-family="Helvetica, Arial, sans-serif"
                                                            font-weight="500" fill="#6d7074"
                                                            class="apexcharts-text apexcharts-yaxis-label "
                                                            style="font-family: Helvetica, Arial, sans-serif;">
                                                            <tspan>$52k</tspan>
                                                            <title>$52k</title>
                                                        </text>
                                                        <text x="20" y="109.116" text-anchor="end"
                                                            dominant-baseline="auto" font-size="12px"
                                                            font-family="Helvetica, Arial, sans-serif" font-weight="500"
                                                            fill="#6d7074"
                                                            class="apexcharts-text apexcharts-yaxis-label "
                                                            style="font-family: Helvetica, Arial, sans-serif;">
                                                            <tspan>$38k</tspan>
                                                            <title>$38k</title>
                                                        </text>
                                                        <text x="20" y="184.232" text-anchor="end"
                                                            dominant-baseline="auto" font-size="12px"
                                                            font-family="Helvetica, Arial, sans-serif" font-weight="500"
                                                            fill="#6d7074"
                                                            class="apexcharts-text apexcharts-yaxis-label "
                                                            style="font-family: Helvetica, Arial, sans-serif;">
                                                            <tspan>$24k</tspan>
                                                            <title>$24k</title>
                                                        </text>
                                                        <text x="20" y="259.348" text-anchor="end"
                                                            dominant-baseline="auto" font-size="12px"
                                                            font-family="Helvetica, Arial, sans-serif" font-weight="500"
                                                            fill="#6d7074"
                                                            class="apexcharts-text apexcharts-yaxis-label "
                                                            style="font-family: Helvetica, Arial, sans-serif;">
                                                            <tspan>$10k</tspan>
                                                            <title>$10k</title>
                                                        </text>
                                                    </g>
                                                </g>
                                                <g class="apexcharts-inner apexcharts-graphical"
                                                    transform="translate(54.021484375, 30)">
                                                    <defs>
                                                        <clipPath id="gridRectMask7ob2tt53">
                                                            <rect width="791.978515625" height="233.348" x="-4" y="-4"
                                                                rx="0" ry="0" opacity="1" stroke-width="0" stroke="none"
                                                                stroke-dasharray="0" fill="#fff"></rect>
                                                        </clipPath>
                                                        <clipPath id="gridRectBarMask7ob2tt53">
                                                            <rect width="791.978515625" height="233.348" x="-4" y="-4"
                                                                rx="0" ry="0" opacity="1" stroke-width="0" stroke="none"
                                                                stroke-dasharray="0" fill="#fff"></rect>
                                                        </clipPath>
                                                        <clipPath id="gridRectMarkerMask7ob2tt53">
                                                            <rect width="783.978515625" height="225.348" x="0" y="0"
                                                                rx="0" ry="0" opacity="1" stroke-width="0" stroke="none"
                                                                stroke-dasharray="0" fill="#fff"></rect>
                                                        </clipPath>
                                                        <clipPath id="forecastMask7ob2tt53"></clipPath>
                                                        <clipPath id="nonForecastMask7ob2tt53"></clipPath>
                                                    </defs>
                                                    <line x1="0" y1="0" x2="0" y2="225.348" stroke="#b6b6b6"
                                                        stroke-dasharray="3" stroke-linecap="butt"
                                                        class="apexcharts-xcrosshairs" x="0" y="0" width="1"
                                                        height="225.348" fill="#b1b9c4" filter="none" fill-opacity="0.9"
                                                        stroke-width="1"></line>
                                                    <line x1="0" y1="225.348" x2="0" y2="231.348" stroke="#e0e0e0"
                                                        stroke-dasharray="0" stroke-linecap="butt"
                                                        class="apexcharts-xaxis-tick"></line>
                                                    <line x1="97.997314453125" y1="225.348" x2="97.997314453125"
                                                        y2="231.348" stroke="#e0e0e0" stroke-dasharray="0"
                                                        stroke-linecap="butt" class="apexcharts-xaxis-tick"></line>
                                                    <line x1="195.99462890625" y1="225.348" x2="195.99462890625"
                                                        y2="231.348" stroke="#e0e0e0" stroke-dasharray="0"
                                                        stroke-linecap="butt" class="apexcharts-xaxis-tick"></line>
                                                    <line x1="293.991943359375" y1="225.348" x2="293.991943359375"
                                                        y2="231.348" stroke="#e0e0e0" stroke-dasharray="0"
                                                        stroke-linecap="butt" class="apexcharts-xaxis-tick"></line>
                                                    <line x1="391.9892578125" y1="225.348" x2="391.9892578125"
                                                        y2="231.348" stroke="#e0e0e0" stroke-dasharray="0"
                                                        stroke-linecap="butt" class="apexcharts-xaxis-tick"></line>
                                                    <line x1="489.986572265625" y1="225.348" x2="489.986572265625"
                                                        y2="231.348" stroke="#e0e0e0" stroke-dasharray="0"
                                                        stroke-linecap="butt" class="apexcharts-xaxis-tick"></line>
                                                    <line x1="587.98388671875" y1="225.348" x2="587.98388671875"
                                                        y2="231.348" stroke="#e0e0e0" stroke-dasharray="0"
                                                        stroke-linecap="butt" class="apexcharts-xaxis-tick"></line>
                                                    <line x1="685.981201171875" y1="225.348" x2="685.981201171875"
                                                        y2="231.348" stroke="#e0e0e0" stroke-dasharray="0"
                                                        stroke-linecap="butt" class="apexcharts-xaxis-tick"></line>
                                                    <line x1="783.978515625" y1="225.348" x2="783.978515625"
                                                        y2="231.348" stroke="#e0e0e0" stroke-dasharray="0"
                                                        stroke-linecap="butt" class="apexcharts-xaxis-tick"></line>
                                                    <g class="apexcharts-grid">
                                                        <g class="apexcharts-gridlines-horizontal">
                                                            <line x1="0" y1="75.116" x2="783.978515625" y2="75.116"
                                                                stroke="#e0e0e0" stroke-dasharray="0"
                                                                stroke-linecap="butt" class="apexcharts-gridline">
                                                            </line>
                                                            <line x1="0" y1="150.232" x2="783.978515625" y2="150.232"
                                                                stroke="#e0e0e0" stroke-dasharray="0"
                                                                stroke-linecap="butt" class="apexcharts-gridline">
                                                            </line>
                                                        </g>
                                                        <g class="apexcharts-gridlines-vertical"></g>
                                                        <line x1="0" y1="225.348" x2="783.978515625" y2="225.348"
                                                            stroke="transparent" stroke-dasharray="0"
                                                            stroke-linecap="butt"></line>
                                                        <line x1="0" y1="1" x2="0" y2="225.348" stroke="transparent"
                                                            stroke-dasharray="0" stroke-linecap="butt"></line>
                                                    </g>
                                                    <g class="apexcharts-grid-borders">
                                                        <line x1="0" y1="0" x2="783.978515625" y2="0" stroke="#e0e0e0"
                                                            stroke-dasharray="0" stroke-linecap="butt"
                                                            class="apexcharts-gridline"></line>
                                                        <line x1="0" y1="225.348" x2="783.978515625" y2="225.348"
                                                            stroke="#e0e0e0" stroke-dasharray="0" stroke-linecap="butt"
                                                            class="apexcharts-gridline"></line>
                                                        <line x1="0" y1="225.348" x2="783.978515625" y2="225.348"
                                                            stroke="#e0e0e0" stroke-dasharray="0" stroke-width="1"
                                                            stroke-linecap="butt"></line>
                                                    </g>
                                                    <g class="apexcharts-area-series apexcharts-plot-series">
                                                        <g class="apexcharts-series" zIndex="0" seriesName="x"
                                                            data:longestSeries="true" rel="1" data:realIndex="0">
                                                            <path
                                                                d="M 0 48.288857142857154C 34.299060058593746 48.288857142857154 63.69825439453124 150.23200000000003 97.99731445312499 150.23200000000003C 132.29637451171874 150.23200000000003 161.69556884765623 128.77028571428573 195.99462890624997 128.77028571428573C 230.29368896484374 128.77028571428573 259.69288330078126 182.42457142857143 293.991943359375 182.42457142857143C 328.29100341796874 182.42457142857143 357.6901977539062 26.82714285714286 391.98925781249994 26.82714285714286C 426.2883178710937 26.82714285714286 455.6875122070312 177.0591428571429 489.98657226562494 177.0591428571429C 524.2856323242187 177.0591428571429 553.6848266601562 123.40485714285717 587.98388671875 123.40485714285717C 622.2829467773438 123.40485714285717 651.6821411132812 118.03942857142857 685.981201171875 118.03942857142857C 720.2802612304687 118.03942857142857 749.6794555664062 16.096285714285727 783.9785156249999 16.096285714285727C 783.9785156249999 16.096285714285727 783.9785156249999 16.096285714285727 783.9785156249999 225.348 L 0 225.348z"
                                                                fill="rgba(49,124,111,0.1)" fill-opacity="1"
                                                                stroke="none" stroke-opacity="1" stroke-linecap="butt"
                                                                stroke-width="0" stroke-dasharray="0"
                                                                class="apexcharts-area" index="0"
                                                                clip-path="url(#gridRectMask7ob2tt53)"
                                                                pathTo="M 0 48.288857142857154C 34.299060058593746 48.288857142857154 63.69825439453124 150.23200000000003 97.99731445312499 150.23200000000003C 132.29637451171874 150.23200000000003 161.69556884765623 128.77028571428573 195.99462890624997 128.77028571428573C 230.29368896484374 128.77028571428573 259.69288330078126 182.42457142857143 293.991943359375 182.42457142857143C 328.29100341796874 182.42457142857143 357.6901977539062 26.82714285714286 391.98925781249994 26.82714285714286C 426.2883178710937 26.82714285714286 455.6875122070312 177.0591428571429 489.98657226562494 177.0591428571429C 524.2856323242187 177.0591428571429 553.6848266601562 123.40485714285717 587.98388671875 123.40485714285717C 622.2829467773438 123.40485714285717 651.6821411132812 118.03942857142857 685.981201171875 118.03942857142857C 720.2802612304687 118.03942857142857 749.6794555664062 16.096285714285727 783.9785156249999 16.096285714285727C 783.9785156249999 16.096285714285727 783.9785156249999 16.096285714285727 783.9785156249999 225.348 L 0 225.348z"
                                                                pathFrom="M 0 225.348 L 0 225.348 L 97.99731445312499 225.348 L 195.99462890624997 225.348 L 293.991943359375 225.348 L 391.98925781249994 225.348 L 489.98657226562494 225.348 L 587.98388671875 225.348 L 685.981201171875 225.348 L 783.9785156249999 225.348z">
                                                            </path>
                                                            <path
                                                                d="M 0 48.288857142857154C 34.299060058593746 48.288857142857154 63.69825439453124 150.23200000000003 97.99731445312499 150.23200000000003C 132.29637451171874 150.23200000000003 161.69556884765623 128.77028571428573 195.99462890624997 128.77028571428573C 230.29368896484374 128.77028571428573 259.69288330078126 182.42457142857143 293.991943359375 182.42457142857143C 328.29100341796874 182.42457142857143 357.6901977539062 26.82714285714286 391.98925781249994 26.82714285714286C 426.2883178710937 26.82714285714286 455.6875122070312 177.0591428571429 489.98657226562494 177.0591428571429C 524.2856323242187 177.0591428571429 553.6848266601562 123.40485714285717 587.98388671875 123.40485714285717C 622.2829467773438 123.40485714285717 651.6821411132812 118.03942857142857 685.981201171875 118.03942857142857C 720.2802612304687 118.03942857142857 749.6794555664062 16.096285714285727 783.9785156249999 16.096285714285727"
                                                                fill="none" fill-opacity="1" stroke="#317c6f"
                                                                stroke-opacity="1" stroke-linecap="butt"
                                                                stroke-width="4" stroke-dasharray="0"
                                                                class="apexcharts-area" index="0"
                                                                clip-path="url(#gridRectMask7ob2tt53)"
                                                                pathTo="M 0 48.288857142857154C 34.299060058593746 48.288857142857154 63.69825439453124 150.23200000000003 97.99731445312499 150.23200000000003C 132.29637451171874 150.23200000000003 161.69556884765623 128.77028571428573 195.99462890624997 128.77028571428573C 230.29368896484374 128.77028571428573 259.69288330078126 182.42457142857143 293.991943359375 182.42457142857143C 328.29100341796874 182.42457142857143 357.6901977539062 26.82714285714286 391.98925781249994 26.82714285714286C 426.2883178710937 26.82714285714286 455.6875122070312 177.0591428571429 489.98657226562494 177.0591428571429C 524.2856323242187 177.0591428571429 553.6848266601562 123.40485714285717 587.98388671875 123.40485714285717C 622.2829467773438 123.40485714285717 651.6821411132812 118.03942857142857 685.981201171875 118.03942857142857C 720.2802612304687 118.03942857142857 749.6794555664062 16.096285714285727 783.9785156249999 16.096285714285727"
                                                                pathFrom="M 0 225.348 L 0 225.348 L 97.99731445312499 225.348 L 195.99462890624997 225.348 L 293.991943359375 225.348 L 391.98925781249994 225.348 L 489.98657226562494 225.348 L 587.98388671875 225.348 L 685.981201171875 225.348 L 783.9785156249999 225.348"
                                                                fill-rule="evenodd"></path>
                                                            <g class="apexcharts-series-markers-wrap apexcharts-hidden-element-shown"
                                                                data:realIndex="0">
                                                                <g class="apexcharts-series-markers">
                                                                    <path d="M 0, 0 
                                                      m -0, 0 
                                                      a 0,0 0 1,0 0,0 
                                                      a 0,0 0 1,0 -0,0" fill="#317c6f" fill-opacity="1"
                                                                        stroke="#ffffff" stroke-opacity="0.9"
                                                                        stroke-linecap="butt" stroke-width="2"
                                                                        stroke-dasharray="0" cx="0" cy="0"
                                                                        shape="circle"
                                                                        class="apexcharts-marker wa2agk65p no-pointer-events"
                                                                        default-marker-size="0"></path>
                                                                </g>
                                                            </g>
                                                        </g>
                                                        <g class="apexcharts-datalabels" data:realIndex="0"></g>
                                                    </g>
                                                    <line x1="0" y1="0" x2="783.978515625" y2="0" stroke="#b6b6b6"
                                                        stroke-dasharray="0" stroke-width="1" stroke-linecap="butt"
                                                        class="apexcharts-ycrosshairs"></line>
                                                    <line x1="0" y1="0" x2="783.978515625" y2="0" stroke="#b6b6b6"
                                                        stroke-dasharray="0" stroke-width="0" stroke-linecap="butt"
                                                        class="apexcharts-ycrosshairs-hidden"></line>
                                                    <g class="apexcharts-xaxis" transform="translate(0, 0)">
                                                        <g class="apexcharts-xaxis-texts-g"
                                                            transform="translate(0, -4)">
                                                            <text x="0" y="253.348" text-anchor="middle"
                                                                dominant-baseline="auto" font-size="12px"
                                                                font-family="Helvetica, Arial, sans-serif"
                                                                font-weight="400" fill="#6d7074"
                                                                class="apexcharts-text apexcharts-xaxis-label "
                                                                style="font-family: Helvetica, Arial, sans-serif;">
                                                                <tspan>2/1</tspan>
                                                                <title>2/1</title>
                                                            </text>
                                                            <text x="97.997314453125" y="253.348" text-anchor="middle"
                                                                dominant-baseline="auto" font-size="12px"
                                                                font-family="Helvetica, Arial, sans-serif"
                                                                font-weight="400" fill="#6d7074"
                                                                class="apexcharts-text apexcharts-xaxis-label "
                                                                style="font-family: Helvetica, Arial, sans-serif;">
                                                                <tspan>2/2</tspan>
                                                                <title>2/2</title>
                                                            </text>
                                                            <text x="195.99462890625" y="253.348" text-anchor="middle"
                                                                dominant-baseline="auto" font-size="12px"
                                                                font-family="Helvetica, Arial, sans-serif"
                                                                font-weight="400" fill="#6d7074"
                                                                class="apexcharts-text apexcharts-xaxis-label "
                                                                style="font-family: Helvetica, Arial, sans-serif;">
                                                                <tspan>2/3</tspan>
                                                                <title>2/3</title>
                                                            </text>
                                                            <text x="293.991943359375" y="253.348" text-anchor="middle"
                                                                dominant-baseline="auto" font-size="12px"
                                                                font-family="Helvetica, Arial, sans-serif"
                                                                font-weight="400" fill="#6d7074"
                                                                class="apexcharts-text apexcharts-xaxis-label "
                                                                style="font-family: Helvetica, Arial, sans-serif;">
                                                                <tspan>2/4</tspan>
                                                                <title>2/4</title>
                                                            </text>
                                                            <text x="391.9892578125" y="253.348" text-anchor="middle"
                                                                dominant-baseline="auto" font-size="12px"
                                                                font-family="Helvetica, Arial, sans-serif"
                                                                font-weight="400" fill="#6d7074"
                                                                class="apexcharts-text apexcharts-xaxis-label "
                                                                style="font-family: Helvetica, Arial, sans-serif;">
                                                                <tspan>2/5</tspan>
                                                                <title>2/5</title>
                                                            </text>
                                                            <text x="489.986572265625" y="253.348" text-anchor="middle"
                                                                dominant-baseline="auto" font-size="12px"
                                                                font-family="Helvetica, Arial, sans-serif"
                                                                font-weight="400" fill="#6d7074"
                                                                class="apexcharts-text apexcharts-xaxis-label "
                                                                style="font-family: Helvetica, Arial, sans-serif;">
                                                                <tspan>2/6</tspan>
                                                                <title>2/6</title>
                                                            </text>
                                                            <text x="587.98388671875" y="253.348" text-anchor="middle"
                                                                dominant-baseline="auto" font-size="12px"
                                                                font-family="Helvetica, Arial, sans-serif"
                                                                font-weight="400" fill="#6d7074"
                                                                class="apexcharts-text apexcharts-xaxis-label "
                                                                style="font-family: Helvetica, Arial, sans-serif;">
                                                                <tspan>2/7</tspan>
                                                                <title>2/7</title>
                                                            </text>
                                                            <text x="685.981201171875" y="253.348" text-anchor="middle"
                                                                dominant-baseline="auto" font-size="12px"
                                                                font-family="Helvetica, Arial, sans-serif"
                                                                font-weight="400" fill="#6d7074"
                                                                class="apexcharts-text apexcharts-xaxis-label "
                                                                style="font-family: Helvetica, Arial, sans-serif;">
                                                                <tspan>2/8</tspan>
                                                                <title>2/8</title>
                                                            </text>
                                                            <text x="783.978515625" y="253.348" text-anchor="middle"
                                                                dominant-baseline="auto" font-size="12px"
                                                                font-family="Helvetica, Arial, sans-serif"
                                                                font-weight="400" fill="#6d7074"
                                                                class="apexcharts-text apexcharts-xaxis-label "
                                                                style="font-family: Helvetica, Arial, sans-serif;">
                                                                <tspan>2/9</tspan>
                                                                <title>2/9</title>
                                                            </text>
                                                        </g>
                                                    </g>
                                                    <g class="apexcharts-yaxis-annotations"></g>
                                                    <g class="apexcharts-xaxis-annotations"></g>
                                                    <g class="apexcharts-point-annotations"></g>
                                                </g>
                                            </svg>
                                            <div class="apexcharts-legend" style="max-height: 146.5px;"></div>
                                            <div class="apexcharts-tooltip apexcharts-theme-light">
                                                <div class="apexcharts-tooltip-title"
                                                    style="font-family: Helvetica, Arial, sans-serif; font-size: 12px;">
                                                </div>
                                                <div class="apexcharts-tooltip-series-group apexcharts-tooltip-series-group-0"
                                                    style="order: 1;">
                                                    <span class="apexcharts-tooltip-marker" shape="circle"
                                                        style="color: rgb(49, 124, 111);"></span>
                                                    <div class="apexcharts-tooltip-text"
                                                        style="font-family: Helvetica, Arial, sans-serif; font-size: 12px;">
                                                        <div class="apexcharts-tooltip-y-group"><span
                                                                class="apexcharts-tooltip-text-y-label"></span><span
                                                                class="apexcharts-tooltip-text-y-value"></span></div>
                                                        <div class="apexcharts-tooltip-goals-group"><span
                                                                class="apexcharts-tooltip-text-goals-label"></span><span
                                                                class="apexcharts-tooltip-text-goals-value"></span>
                                                        </div>
                                                        <div class="apexcharts-tooltip-z-group"><span
                                                                class="apexcharts-tooltip-text-z-label"></span><span
                                                                class="apexcharts-tooltip-text-z-value"></span></div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div
                                                class="apexcharts-xaxistooltip apexcharts-xaxistooltip-bottom apexcharts-theme-light">
                                                <div class="apexcharts-xaxistooltip-text"
                                                    style="font-family: Helvetica, Arial, sans-serif; font-size: 12px;">
                                                </div>
                                            </div>
                                            <div
                                                class="apexcharts-yaxistooltip apexcharts-yaxistooltip-0 apexcharts-yaxistooltip-left apexcharts-theme-light">
                                                <div class="apexcharts-yaxistooltip-text"></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="detalis-content mb-60" id="menu-sidebar-3">
                                <h4 class="title-content mb-16">Steps To Financial Excellence</h4>
                                <div class="desc mb-32 body-2 color-on-suface-variant-1">Our approach combines
                                    personalized strategies, data-driven insights, and dedicated support to help you
                                    reach your financial goals. Each step is crafted to maximize growth, reduce risk,
                                    and build lasting financial confidence.</div>
                                <div class="process-list style-column">
                                    <div class="process-item style-3 style-3-2">
                                        <div class="icon"><i class="icon-ChartPieSlice"></i></div>
                                        <div class="circle"></div>
                                        <div class="process-content">
                                            <h5><a href="#" class="name-process">Assessment &amp; Goal Setting</a></h5>
                                            <div class="desc body-2 color-on-suface-variant-1">We start by assessing
                                                your financial situation and setting realistic goals, creating a
                                                solid<br>foundation for a customized plan.</div>
                                        </div>
                                    </div>
                                    <div class="process-item style-3 style-3-2">
                                        <div class="icon"><i class="icon-Crosshair1"></i></div>
                                        <div class="circle"></div>
                                        <div class="process-content">
                                            <h5><a href="#" class="name-process">Plan Development</a></h5>
                                            <div class="desc body-2 color-on-suface-variant-1">Using insights from our
                                                assessment, we develop a unique strategy focused on asset growth, risk
                                                management, and long-term success.</div>
                                        </div>
                                    </div>
                                    <div class="process-item style-3 style-3-2">
                                        <div class="icon"><i class="icon-ChartLineUp"></i></div>
                                        <div class="process-content">
                                            <h5><a href="#" class="name-process">Ongoing Review</a></h5>
                                            <div class="desc body-2 color-on-suface-variant-1">We regularly review and
                                                adapt your plan to stay aligned with your evolving goals, ensuring you
                                                stay on track to lasting success.</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="detalis-content" id="menu-sidebar-4">
                                <h4 class="title-content mb-20">FAQs</h4>
                                <div class="wg-according" id="According1">
                                    <div class="according-item style-arrow style-small">
                                        <h6><a href="#according1" data-bs-toggle="collapse"
                                                class="title-according collapsed">What consulting services do you
                                                offer?<i class="icon-chevron-down"></i></a></h6>
                                        <div id="according1" class="collapse" data-bs-parent="#According1">
                                            <div class="according-content">
                                                <p>We conduct in-depth assessments of your business needs, industry
                                                    landscape, and competitive environment to develop customized
                                                    strategies that align with your specific goals.</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="according-item style-arrow style-small">
                                        <h6><a href="#according2" data-bs-toggle="collapse"
                                                class="title-according collapsed">How do your services integrate with
                                                existing business structures?<i class="icon-chevron-down"></i></a></h6>
                                        <div id="according2" class="collapse" data-bs-parent="#According1">
                                            <div class="according-content">
                                                <p>We conduct in-depth assessments of your business needs, industry
                                                    landscape, and competitive environment to develop customized
                                                    strategies that align with your specific goals.</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="according-item style-arrow style-small">
                                        <h6>
                                            <a href="#according3" data-bs-toggle="collapse"
                                                class="title-according collapsed">
                                                Can I tailor your consulting services to suit my business?<!-- --> <i
                                                    class="icon-chevron-down"></i>
                                            </a>
                                        </h6>
                                        <div id="according3" class="collapse" data-bs-parent="#According1">
                                            <div class="according-content">
                                                <p>We conduct in-depth assessments of your business needs, industry
                                                    landscape, and competitive environment to develop customized
                                                    strategies that align with your specific goals.</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="according-item style-arrow style-small">
                                        <h6><a href="#according4" data-bs-toggle="collapse"
                                                class="title-according collapsed">What kind of ongoing consultation do
                                                you offer after the initial service?<i
                                                    class="icon-chevron-down"></i></a></h6>
                                        <div id="according4" class="collapse" data-bs-parent="#According1">
                                            <div class="according-content">
                                                <p>We conduct in-depth assessments of your business needs, industry
                                                    landscape, and competitive environment to develop customized
                                                    strategies that align with your specific goals.</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="tf-sidebar ml-50">
                    <div class="sidebar-details mb-40">
                        <ul class="menu-sidebar-tab" role="tablist">
                            <li class="nav-tab-item" role="presentation"><a href="#tab-1"
                                    class="list-menu-item title active" data-bs-toggle="tab" role="tab"
                                    aria-selected="true">Retirement Planning <i class="icon-arrowRight"></i></a></li>
                            <li class="nav-tab-item" role="presentation"><a href="#tab-2" class="list-menu-item title"
                                    data-bs-toggle="tab" role="tab" aria-selected="false" tabindex="-1">Investment
                                    Advisory <i class="icon-arrowRight"></i></a></li>
                            <li class="nav-tab-item" role="presentation"><a href="#tab-3" class="list-menu-item title"
                                    data-bs-toggle="tab" role="tab" aria-selected="false" tabindex="-1">Estate Planning
                                    <i class="icon-arrowRight"></i></a></li>
                            <li class="nav-tab-item" role="presentation"><a href="#tab-4" class="list-menu-item title"
                                    data-bs-toggle="tab" role="tab" aria-selected="false" tabindex="-1">Tax Optimization
                                    <i class="icon-arrowRight"></i></a></li>
                        </ul>
                    </div>
                    <div class="sidebar-details mb-40">
                        <form class="form-contact-home style-border">
                            <h5 class="title-form text-center">Get A Free Quote</h5>
                            <fieldset><input required="" type="text" placeholder="Full name"></fieldset>
                            <fieldset><input required="" type="number" placeholder="Phone number"></fieldset>
                            <fieldset><input required="" type="email" placeholder="Email address" name="email">
                            </fieldset>
                            <div class="nice-select">
                                <span class="current">How can we help you?</span>
                                <ul class="list">
                                    <li class="option selected  text text-1">How can we help you?</li>
                                    <li class="option   text text-1">Option 1</li>
                                    <li class="option   text text-1">Option 2</li>
                                    <li class="option   text text-1">Option 3</li>
                                </ul>
                            </div>
                            <fieldset><textarea required="" placeholder="Your mesages"></textarea></fieldset>
                            <div class="tfSubscribeMsg  footer-sub-element ">
                                <p style="color:rgb(52, 168, 83)">Form submitted successfully.</p>
                            </div>
                            <button type="submit"
                                class="tf-btn style-2 bg-on-suface-container w-full text-center"><span> Submit Require
                                </span></button>
                        </form>
                    </div>
                    <div class="sidebar-contact sidebar-details">
                        <div class="section-content position-relative">
                            <div class="heading-section style-color-white">
                                <a class="tag label text-btn-uppercase color-white mb-16" href="/contact-us">Contact
                                    US</a>
                                <h4 class="title-section mb-1">Get In Touch</h4>
                                <div class="sub-title caption-1">Reach out today to discuss how we can<br>support your
                                    business goals.</div>
                            </div>
                            <div class="list-box-contact style-column mb-28">
                                <div class="box-contact-item">
                                    <div class="icon"><i class="icon-MapPin"></i></div>
                                    <div class="content">
                                        <div class="caption-1 title-section-contact">Address Business</div>
                                        <a href="#" class="caption-1 text">101 E 129th St, East Chicago, IN 46312,
                                            US</a><a href="#" class="label text-btn-uppercase">Get direction</a>
                                    </div>
                                </div>
                                <div class="box-contact-item">
                                    <div class="icon"><i class="icon-PhoneCall"></i></div>
                                    <div class="content">
                                        <div class="caption-1 title-section-contact">Contact Us</div>
                                        <a href="#" class="caption-1 text">1-555-678-8888<br>1-333-123-6666</a>
                                    </div>
                                </div>
                                <div class="box-contact-item">
                                    <div class="icon">
                                        <svg width="33" height="33" viewBox="0 0 33 33" fill="none"
                                            xmlns="http://www.w3.org/2000/svg">
                                            <g clip-path="url(#clip0_9360_10609)">
                                                <path
                                                    d="M16.3335 28.75C22.4086 28.75 27.3335 23.8251 27.3335 17.75C27.3335 11.6749 22.4086 6.75 16.3335 6.75C10.2584 6.75 5.3335 11.6749 5.3335 17.75C5.3335 23.8251 10.2584 28.75 16.3335 28.75Z"
                                                    stroke="white" stroke-width="1.5" stroke-linecap="round"
                                                    stroke-linejoin="round"></path>
                                                <path d="M7.3335 4.75L3.3335 8.75" stroke="white" stroke-width="1.5"
                                                    stroke-linecap="round" stroke-linejoin="round"></path>
                                                <path d="M25.3335 4.75L29.3335 8.75" stroke="white" stroke-width="1.5"
                                                    stroke-linecap="round" stroke-linejoin="round"></path>
                                                <path d="M16.3335 10.75V17.75H23.3335" stroke="white" stroke-width="1.5"
                                                    stroke-linecap="round" stroke-linejoin="round"></path>
                                            </g>
                                            <defs>
                                                <clipPath>
                                                    <rect width="32" height="32" fill="white"
                                                        transform="translate(0.333496 0.75)"></rect>
                                                </clipPath>
                                            </defs>
                                        </svg>
                                    </div>
                                    <div class="content">
                                        <div class="caption-1 title-section-contact">Working Time</div>
                                        <a href="#" class="caption-1 text">Mon-Sat:8:00am - 18:00pm <br>Sun: Closed</a>
                                    </div>
                                </div>
                            </div>
                            <a class="tf-btn style-1 bg-white bg-white-style-2 w-full text-center"
                                href="/contact-us"><span> Contact Us </span></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>







<?php
include 'common/footer.php';
include 'common/footerfiles.php';
?>