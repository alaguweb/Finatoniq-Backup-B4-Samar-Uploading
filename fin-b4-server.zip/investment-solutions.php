<?php
include 'common/config.php';

$pageTitle = "Manufacturers of Investment Solutions - Finatoniq";
$pageMetaDesc = "For AMCs, PMS providers, and AIF manufacturers seeking deeper investor trust and stronger intermediary engagement.";
$pageUrl = $base_url . "investment-solutions.php";
$pageImage = $base_url . "assets/images/logo/logo.png";
$activeMenu = 'verticals';

// Layout Configuration
$showTopBar = true; // Sample has top bar
$headerClass = 'style-absolute'; // Sample has absolute header

include 'common/header.php';
include 'common/menu.php';
?>


<link rel="stylesheet" href="assets/css/pages.css">
<link rel="stylesheet" href="assets/css/innerpage.css">

<!-- Page Title / Banner -->
<div class="page-title style-1 bg-img-6">
    <div class="tf-container">
        <div class="page-title-content">
            <div class="breadkcum">
                <a class="caption-1 home" href="<?php echo $base_url; ?>">Homepage</a>

                <span class="arrow-svg">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                        <g clip-path="url(#clip0_9360_28061)">
                            <path d="M3.125 10H16.875" stroke="#A2A3AB" stroke-linecap="round" stroke-linejoin="round">
                            </path>
                            <path d="M11.25 4.375L16.875 10L11.25 15.625" stroke="#A2A3AB" stroke-linecap="round"
                                stroke-linejoin="round"></path>
                        </g>
                    </svg>
                </span>

            </div>
            <h2 class="title-page-title">Manufacturers of Investment Solutions</h2>
            <div class="sub-title body-2">

                Powering the reach to distributors, RIAs and investors
            </div>
        </div>
    </div>
</div>






<div class="main-content inner">
    <div class="tf-container tf-spacing-2">
        <div class="row rg-60">
            <div class="col-lg-12">
                <div class="tab-content">
                    <div class="tab-pane active show" id="tab-1" role="tabpanel">
                        <div class="service-details-content">

                            <div class="detalis-content mb-60" id="menu-sidebar-1">
                                <h4 class="title-content mb-16"> Whom Is This For ?</h4>

                                <ul class="menu-sidebar-tab no-tabs">
                                    <li class="nav-tab-item list-menu-item title">Mutual Fund AMCs</li>
                                    <li class="nav-tab-item list-menu-item title">PMS Providers</li>
                                    <li class="nav-tab-item list-menu-item title">AIF Manufacturers</li>
                                </ul>

                            </div>

                            <div class="detalis-content mb-60" id="menu-sidebar-1">
                                <h4 class="title-content mb-16">What it Enables</h4>
                                <div class="desc mb-16 body-2 color-on-suface-variant-1"> We team up with<b>
                                        manufacturers of investment solution products</b> to enhance their engagement
                                    and product reach with the key stake holders encompassing <b> Investors,
                                        Distributors and RIAs </b> </div><br />
                                <div class="cols g-10">
                                    <div class="benefit-lists">
                                        <div class="benefit-items style-small mb-16">
                                            <div class="icon"><i class="icon-checkbox"></i></div>
                                            <div class="title"> Investor understanding</div>
                                        </div>
                                        <div class="benefit-items style-small mb-16">
                                            <div class="icon"><i class="icon-checkbox"></i></div>
                                            <div class="title"> Intermediary capability </div>
                                        </div>

                                    </div>
                                    <div class="benefit-lists">
                                        <div class="benefit-items style-small mb-16">
                                            <div class="icon"><i class="icon-checkbox"></i></div>
                                            <div class="title"> Product suitability</div>
                                        </div>
                                        <div class="benefit-items style-small mb-16">
                                            <div class="icon"><i class="icon-checkbox"></i></div>
                                            <div class="title"> Long-term engagement</div>
                                        </div>
                                    </div>
                                </div>
                            </div>



                            <!--
                                <div class="detalis-content mb-60" id="menu-sidebar-4">
                                    <h4 class="title-content mb-20"> Offerings Explained</h4>
                                    <div class="wg-according" id="According1">
                                        <div class="according-item style-arrow style-small">
                                            <h6><a href="#according1" data-bs-toggle="collapse"
                                                    class="title-according collapsed">Personal Finance Profiler <i
                                                        class="icon-chevron-down"></i></a></h6>
                                            <div id="according1" class="collapse" data-bs-parent="#According1">
                                                <div class="according-content">
                                                    <p>Creates structured investor context by capturing goals, cash flows,
                                                        time horizons, and financial priorities — enabling meaningful
                                                        product alignment.</p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="according-item style-arrow style-small">
                                            <h6><a href="#according2" data-bs-toggle="collapse"
                                                    class="title-according collapsed">Behavioural Finance Assessment<i
                                                        class="icon-chevron-down"></i></a></h6>
                                            <div id="according2" class="collapse" data-bs-parent="#According1">
                                                <div class="according-content">
                                                    <p>Identifies emotional biases and decision patterns that influence
                                                        investor behaviour, improving communication, positioning, and
                                                        retention.</p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="according-item style-arrow style-small">
                                            <h6>
                                                <a href="#according3" data-bs-toggle="collapse"
                                                    class="title-according collapsed">
                                                    Risk Profiler <i class="icon-chevron-down"></i>
                                                </a>
                                            </h6>
                                            <div id="according3" class="collapse" data-bs-parent="#According1">
                                                <div class="according-content">
                                                    <p>Integrates financial capacity with behavioural tolerance to
                                                        strengthen suitability, compliance, and portfolio alignment.</p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="according-item style-arrow style-small">
                                            <h6><a href="#according4" data-bs-toggle="collapse"
                                                    class="title-according collapsed">Intermediary Training & Enablement<i
                                                        class="icon-chevron-down"></i></a></h6>
                                            <div id="according4" class="collapse" data-bs-parent="#According1">
                                                <div class="according-content">
                                                    <p>Comprehensive training of all relevant topics covering products,
                                                        markets, behavioural selling, client communication, and with in
                                                        regulatory boundaries.</p>
                                                </div>
                                            </div>
                                        </div>
    
    
    
                                        <div class="according-item style-arrow style-small">
                                            <h6><a href="#according5" data-bs-toggle="collapse"
                                                    class="title-according collapsed">Investor Meetings & IAPs<i
                                                        class="icon-chevron-down"></i></a></h6>
                                            <div id="according5" class="collapse" data-bs-parent="#According1">
                                                <div class="according-content">
                                                    <p>Design and execution of investor education programs, market outlook
                                                        sessions, and behavioural finance-led engagements.</p>
                                                </div>
                                            </div>
                                        </div>
    
    
    
                                        <div class="according-item style-arrow style-small">
                                            <h6><a href="#according6" data-bs-toggle="collapse"
                                                    class="title-according collapsed">Content & Thought Leadership<i
                                                        class="icon-chevron-down"></i></a></h6>
                                            <div id="according6" class="collapse" data-bs-parent="#According1">
                                                <div class="according-content">
                                                    <p>Creation of market notes, product explainers, and behavioural
                                                        insights that build credibility and trust.</p>
                                                </div>
                                            </div>
                                        </div>
    
    
                                        <div class="according-item style-arrow style-small">
                                            <h6><a href="#according7" data-bs-toggle="collapse"
                                                    class="title-according collapsed">Collateral & Digital Experience
                                                    Design<i class="icon-chevron-down"></i></a></h6>
                                            <div id="according7" class="collapse" data-bs-parent="#According1">
                                                <div class="according-content">
                                                    <p>Design of presentations, brochures, microsites, and distributor
                                                        portals aligned with brand and compliance standards.</p>
                                                </div>
                                            </div>
                                        </div>
    
    
                                        <div class="according-item style-arrow style-small">
                                            <h6><a href="#according8" data-bs-toggle="collapse"
                                                    class="title-according collapsed">Legal & Financial Consulting<i
                                                        class="icon-chevron-down"></i></a></h6>
                                            <div id="according8" class="collapse" data-bs-parent="#According1">
                                                <div class="according-content">
                                                    <p>Advisory on distribution frameworks, engagement structures, and
                                                        regulatory-aware communication.</p>
                                                </div>
                                            </div>
                                        </div>
    
    
                                        <div class="according-item style-arrow style-small">
                                            <h6><a href="#according9" data-bs-toggle="collapse"
                                                    class="title-according collapsed">Distributor Engagement Consulting<i
                                                        class="icon-chevron-down"></i></a></h6>
                                            <div id="according9" class="collapse" data-bs-parent="#According1">
                                                <div class="according-content">
                                                    <p>Design and execution of long-term intermediary engagement ecosystems
                                                        across geographies on all relevant topics of the Investments
                                                        ecosystem</p>
                                                </div>
                                            </div>
                                        </div>
    
    
    
    
    
                                    </div>
                                </div>
                            --> 
                            
                            <div class="detalis-content mb-60" id="menu-sidebar-4">
                                <h4 class="title-content mb-20">Offerings Explained</h4>
                            
                                <div class="wg-according">
                            
                                    <div class="according-item style-arrow style-small">
                                        <h6 class="title-according">
                                            Personal Finance Profiler
                                        </h6>
                                        <div class="according-content">
                                            <p>
                                                Creates structured investor context by capturing goals, cash flows,
                                                time horizons, and financial priorities — enabling meaningful
                                                product alignment.
                                            </p>
                                        </div>
                                    </div>
                            
                                    <div class="according-item style-arrow style-small">
                                        <h6 class="title-according">
                                            Behavioural Finance Assessment
                                        </h6>
                                        <div class="according-content">
                                            <p>
                                                Identifies emotional biases and decision patterns that influence
                                                investor behaviour, improving communication, positioning, and
                                                retention.
                                            </p>
                                        </div>
                                    </div>
                            
                                    <div class="according-item style-arrow style-small">
                                        <h6 class="title-according">
                                            Risk Profiler
                                        </h6>
                                        <div class="according-content">
                                            <p>
                                                Integrates financial capacity with behavioural tolerance to
                                                strengthen suitability, compliance, and portfolio alignment.
                                            </p>
                                        </div>
                                    </div>
                            
                                    <div class="according-item style-arrow style-small">
                                        <h6 class="title-according">
                                            Intermediary Training & Enablement
                                        </h6>
                                        <div class="according-content">
                                            <p>
                                                Comprehensive training of all relevant topics covering products,
                                                markets, behavioural selling, client communication, and within
                                                regulatory boundaries.
                                            </p>
                                        </div>
                                    </div>
                            
                                    <div class="according-item style-arrow style-small">
                                        <h6 class="title-according">
                                            Investor Meetings & IAPs
                                        </h6>
                                        <div class="according-content">
                                            <p>
                                                Design and execution of investor education programs, market outlook
                                                sessions, and behavioural finance-led engagements.
                                            </p>
                                        </div>
                                    </div>
                            
                                    <div class="according-item style-arrow style-small">
                                        <h6 class="title-according">
                                            Content & Thought Leadership
                                        </h6>
                                        <div class="according-content">
                                            <p>
                                                Creation of market notes, product explainers, and behavioural
                                                insights that build credibility and trust.
                                            </p>
                                        </div>
                                    </div>
                            
                                    <div class="according-item style-arrow style-small">
                                        <h6 class="title-according">
                                            Collateral & Digital Experience Design
                                        </h6>
                                        <div class="according-content">
                                            <p>
                                                Design of presentations, brochures, microsites, and distributor
                                                portals aligned with brand and compliance standards.
                                            </p>
                                        </div>
                                    </div>
                            
                                    <div class="according-item style-arrow style-small">
                                        <h6 class="title-according">
                                            Legal & Financial Consulting
                                        </h6>
                                        <div class="according-content">
                                            <p>
                                                Advisory on distribution frameworks, engagement structures, and
                                                regulatory-aware communication.
                                            </p>
                                        </div>
                                    </div>
                            
                                    <div class="according-item style-arrow style-small">
                                        <h6 class="title-according">
                                            Distributor Engagement Consulting
                                        </h6>
                                        <div class="according-content">
                                            <p>
                                                Design and execution of long-term intermediary engagement ecosystems
                                                across geographies on all relevant topics of the investments ecosystem.
                                            </p>
                                        </div>
                                    </div>
                            
                                </div>
                            </div>




                            <div class="detalis-content mb-30" id="menu-sidebar-3">
                                <div class="desc mb-32 body-2 color-on-suface-variant-1"></div>
                                <div class="process-list style-column">

                                    <div class="process-item style-3 style-3-2 open-popup-trigger"
                                        style="cursor: pointer;">
                                        <div class="icon"><i class="icon-Envelope"></i></div>
                                        <div class="circle"></div>
                                        <div class="process-content">
                                            <h5><a href="javascript:void(0);" class="name-process">Connect</a></h5>

                                        </div>
                                    </div>

                                </div>
                            </div>

                        </div>
                    </div>

                </div>
            </div>

        </div>
    </div>
</div>







<?php
include 'common/footer.php';
include 'common/footerfiles.php';
?>