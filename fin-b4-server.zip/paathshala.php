<?php
include 'common/config.php';

$pageTitle = "Paathshala - Finatoniq";
$pageMetaDesc = "Launch Your Dream Career with Finatoniq Paathshala.";
$pageUrl = $base_url . "paathshala.php";
$pageImage = $base_url . "assets/images/logo/logo.png";
$activeMenu = 'paathshala';

// Layout Configuration
$showTopBar = true;
$headerClass = 'style-absolute';

include 'common/header.php';
include 'common/menu.php';
?>

<link rel="stylesheet" href="assets/css/paathshala-tailwind.css">
<style>
    /* Add some overrides to prevent tailwind from messing with header */
    main.site-content {
        text-align: left;
    }

    main.site-content h1,
    main.site-content h2,
    main.site-content h3,
    main.site-content h4,
    main.site-content h5,
    main.site-content h6 {
        line-height: 1.2;
    }

    main.site-content p {
        font-size: 18px;
        margin-bottom: 1rem;
    }

    .premium-input {
        border-radius: 1.25rem !important;
        padding: 1.2rem 1.5rem !important;
        border: 2px solid #f1f5f9 !important;
        background-color: #f8fafc !important;
        font-size: 1.1rem !important;
        transition: all 0.3s ease !important;
        color: #1e293b !important;
        margin-bottom: 0px !important;
        width: 100% !important;
        height: auto !important;
    }
</style>

<link rel="stylesheet" href="assets/css/sm.css">
<main id="main" class="site-content">

    <!-- All Content Comes Here -->

    <div class="templatebased">
        <!-- Launch Your Dream Career in Paathshala -->
        <section class="text-white py-20 topsection" style="background: linear-gradient(135deg, #0e6099, #24283E);">
            <div class="tf-container full mx-auto px-6 text-center">
                <div class="floating">
                    <h1 class="text-5xl md:text-7xl font-bold mb-6 text-white">
                        Learn the stock market
                        <span class="text-yellow-300 bottomline">the right way </span>
                    </h1>
                </div>
                <p class="text-xl md:text-2xl mb-8 w-full top15">
                    Simple, Practical, Insightful and Implementable
                </p>
                <p class="top20">
                    A learning platform where true knowledge turns into measurable results and <br /> leads you to make
                    informed investing decisions
                </p>
                <div class="flex flex-col md:flex-row gap-4 justify-center items-center mb-12" data-bs-toggle="modal"
                    data-bs-target="#enrollModal">
                    <button
                        class="pulse-glow bg-white px-8 py-4 rounded-full text-lg font-semibold hover:bg-gray-100 transition-colors"
                        style="color: #0e6099;">
                        🚀 Start your learning journey - ₹ 2,199 Only!
                    </button>
                    <div class="text-yellow-300 font-semibold">
                        ⚡ Limited seats, efficient learning
                    </div>
                </div>
                <div class="grid grid-cols-1 md:grid-cols-3 gap-8 w-full">
                    <div class="bg-white/20 backdrop-blur-sm rounded-lg p-6">
                        <div class="text-3xl mb-2">⏰</div>
                        <div class="font-semibold">Five modules </div>
                        <div class="text-sm">Six hours per module </div>
                    </div>
                    <div class="bg-white/20 backdrop-blur-sm rounded-lg p-6">
                        <div class="text-3xl mb-2">💻</div>
                        <div class="font-semibold"> Offline / Online</div>
                        <div class="text-sm">Weekdays / Weekends </div>
                    </div>
                    <div class="bg-white/20 backdrop-blur-sm rounded-lg p-6">
                        <div class="text-3xl mb-2">🎓</div>
                        <div class="font-semibold">Certification</div>
                        <div class="text-sm">Industry Recognized</div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Course Curriculum -->
        <section id="curriculum" class="topsection py-18 bg-gradient-to-r from-teal-50 to-gray-50">
            <div class="tf-container full mx-auto px-6">

                <div class="text-center mb-16 addbottom">

                    <h2 class="text-5xl font-bold text-gray-800 mb-6">Course Curriculum</h2>
                    <div class="w-24 h-1 mx-auto mb-8" style="background: linear-gradient(135deg, #0e6099, #24283E);">
                    </div>

                </div>
                <div class="w-full">
                    <div class="curriculum-flex-grid">
                        <!-- Module Cards -->
                        <div class="card-hover bg-white rounded-lg p-6 shadow-lg curriculum-card">
                            <div class="text-3xl mb-4">🏢</div>
                            <h3 class="font-bold text-lg mb-2">Module 1</h3>
                            <p class="text-gray-600">Stock Market Foundation </p>
                        </div>

                        <div class="card-hover bg-white rounded-lg p-6 shadow-lg curriculum-card">
                            <div class="text-3xl mb-4">🚀</div>
                            <h3 class="font-bold text-lg mb-2">Module 2</h3>
                            <p class="text-gray-600">Trading Concepts & Technical Analysis</p>
                        </div>

                        <div class="card-hover bg-white rounded-lg p-6 shadow-lg curriculum-card">
                            <div class="text-3xl mb-4">👑</div>
                            <h3 class="font-bold text-lg mb-2">Module 3</h3>
                            <p class="text-gray-600">Investing concepts & Fundamental Analysis</p>
                        </div>

                        <div class="card-hover bg-white rounded-lg p-6 shadow-lg curriculum-card">
                            <div class="text-3xl mb-4">💰</div>
                            <h3 class="font-bold text-lg mb-2">Module 4</h3>
                            <p class="text-gray-600">Derivatives, Futures & Options</p>
                        </div>

                        <div class="card-hover bg-white rounded-lg p-6 shadow-lg curriculum-card">
                            <div class="text-3xl mb-4">🤝</div>
                            <h3 class="font-bold text-lg mb-2">Module 5</h3>
                            <p class="text-gray-600">Mutual Funds & ETFs</p>
                        </div>

                    </div>
                </div>
            </div>
        </section>



        <!-- ❓ Frequently Asked Questions -->
        <section class="topsection py-16 bg-white">
            <div class="tf-container full mx-auto px-6">
                <div class="w-full">
                    <h2 class="text-4xl font-bold text-center text-gray-800 mb-12"> </h2>

                    <div class="space-y-4">
                        <div class="border border-gray-200 rounded-lg">
                            <button
                                class="w-full px-6 py-4 text-left font-semibold text-gray-800 hover:bg-gray-50 flex justify-between items-center faq-toggle">
                                <span>Module 1: Stock Market Foundation </span>
                                <span class="text-2xl">+</span>
                            </button>
                            <div class="px-6 pb-6 hidden faq-content module-topics">
                                <ul class="module-topic-list">
                                    <li>Stock Market Introduction</li>
                                    <li>Who runs the market?</li>
                                    <li>Important terminologies (decoding important terms &amp; jargon)</li>
                                    <li>Price discovery mechanism</li>
                                    <li>The ecosystem of buying and selling</li>
                                    <li>Stock exchanges, stockbrokers and indices</li>
                                    <li>What drives stock prices?</li>
                                    <li>How to choose stocks to invest?</li>
                                    <li>Basic financial metrics</li>
                                    <li>Different types of stocks (growth, value, dividend and momentum stocks)</li>
                                    <li>How to trade?</li>
                                    <li>Basic chart reading &amp; interpretation</li>
                                    <li>Placing your first order</li>
                                    <li>Introduction to a stock portfolio</li>
                                    <li>Common mistakes to avoid</li>
                                    <li>Long-term wealth creation concepts</li>
                                    <li>Real-time illustrations and case studies</li>
                                    <li>Encourage Q&amp;A</li>
                                </ul>
                            </div>
                        </div>

                        <div class="border border-gray-200 rounded-lg">
                            <button
                                class="w-full px-6 py-4 text-left font-semibold text-gray-800 hover:bg-gray-50 flex justify-between items-center faq-toggle">
                                <span>Module 2: Trading Concepts & Technical Analysis</span>
                                <span class="text-2xl">+</span>
                            </button>
                            <div class="px-6 pb-6 hidden faq-content module-topics">
                                <ul class="module-topic-list">
                                    <li>Trading preparation</li>
                                    <li>Introduction to different types of trading charts (Line, Bar and Candlesticks,
                                        Price Action)</li>
                                    <li>Understanding trends (Uptrend, Downtrend, Sideways, Support &amp; Resistance,
                                        Breakouts, Pullbacks)</li>
                                    <li>Basic indicators (RSI, DMA, Volume)</li>
                                    <li>Simple trading set-ups</li>
                                    <li>Risk management &amp; trader psychology</li>
                                </ul>
                            </div>
                        </div>

                        <div class="border border-gray-200 rounded-lg">
                            <button
                                class="w-full px-6 py-4 text-left font-semibold text-gray-800 hover:bg-gray-50 flex justify-between items-center faq-toggle">
                                <span>Module 3: Investing concepts & Fundamental Analysis</span>
                                <span class="text-2xl">+</span>
                            </button>
                            <div class="px-6 pb-6 hidden faq-content module-topics">
                                <ul class="module-topic-list">
                                    <li>Investing Foundations</li>
                                    <li>Understanding financial statements (Income statement, Balance sheet, Cash flow
                                        statement)</li>
                                    <li>Financial Ratios (Profitability ratios, Valuation ratios, Safety ratios,
                                        Efficiency ratios)</li>
                                    <li>Understanding the economics of the business landscape (economic, industry &amp;
                                        business analysis)</li>
                                    <li>Red flags (when to stay away/when to exit a stock)</li>
                                    <li>Valuation Basics</li>
                                    <li>Portfolio Building &amp; Wealth Creation Strategy</li>
                                    <li>Investor Psychology</li>
                                </ul>
                            </div>
                        </div>

                        <div class="border border-gray-200 rounded-lg">
                            <button
                                class="w-full px-6 py-4 text-left font-semibold text-gray-800 hover:bg-gray-50 flex justify-between items-center faq-toggle">
                                <span>Module 4: Derivatives, Futures & Options</span>
                                <span class="text-2xl">+</span>
                            </button>
                            <div class="px-6 pb-6 hidden faq-content module-topics">
                                <ul class="module-topic-list">
                                    <li>Foundations of derivatives</li>
                                    <li>Futures market (Concepts &amp; Market Mechanics)</li>
                                    <li>Futures Trading &amp; Settlement and Margin Management</li>
                                    <li>Basics of Options (Introduction to Call &amp; Put Options)</li>
                                    <li>Payoffs and basic option strategies</li>
                                    <li>Risk, psychology &amp; practical application</li>
                                    <li>Traders' emotions (enemy and friend)</li>
                                </ul>
                            </div>
                        </div>

                        <div class="border border-gray-200 rounded-lg">
                            <button
                                class="w-full px-6 py-4 text-left font-semibold text-gray-800 hover:bg-gray-50 flex justify-between items-center faq-toggle">
                                <span>Module 5: Mutual Funds & ETFs</span>
                                <span class="text-2xl">+</span>
                            </button>
                            <div class="px-6 pb-6 hidden faq-content module-topics">
                                <ul class="module-topic-list">
                                    <li>Structure of mutual funds &amp; regulatory environment</li>
                                    <li>Core mutual fund categories (debt, equity, hybrid) and sub-categories</li>
                                    <li>Investor suitability (which category to choose – when and by whom)</li>
                                    <li>Investing options (growth, dividend (IDCW), regular, direct)</li>
                                    <li>Mode of investing (lump sum, SIP, STP, SWP and when to choose which option)</li>
                                    <li>Taxation</li>
                                    <li>How to choose funds/schemes before investing</li>
                                    <li>Introduction to Exchange Traded Funds (ETFs)</li>
                                    <li>ETFs v/s actively managed funds</li>
                                </ul>
                            </div>
                        </div>


                    </div>
                </div>
            </div>
        </section>





        <!-- Why Choose Paathshala? -->
        <section id="course" class="topsection bg-gradient-to-br from-teal-50 via-pink-50 to-indigo-50">
            <div class="tf-container full mx-auto px-6">
                <div class="w-full">
                    <!-- Header -->
                    <div class="text-center mb-16">
                        <h2 class="text-5xl font-bold text-gray-800 mb-6">Our Trainers</h2>
                        <div class="w-24 h-1 mx-auto mb-8"
                            style="background: linear-gradient(135deg, #0e6099, #24283E);">
                        </div>
                        <p class="text-xl text-gray-600 w-full leading-relaxed">
                            Transform your passion for creativity into a thriving career. The financial industry needs
                            enthusiastic professionals like you to revolutionize this growing sector.
                        </p>
                    </div>

                    <!-- Centered Trainer Card -->
                    <div class="max-w-4xl mx-auto mb-16 px-4">
                        <div
                            class="trainer-card bg-white rounded-3xl shadow-2xl overflow-hidden border border-blue-50 transition-all duration-500 hover:shadow-blue-100/50">
                            <!-- Lead Trainer Header -->
                            <div class="p-8 md:p-12 text-center bg-gradient-to-b from-blue-50/30 to-white">
                                <div class="relative inline-block mb-6">
                                    <div
                                        class="w-24 h-24 rounded-full bg-gradient-to-tr from-blue-600 to-indigo-900 flex items-center justify-center text-white shadow-xl">
                                        <span class="text-4xl">🎓</span>
                                    </div>
                                    <div
                                        class="absolute -bottom-2 -right-2 bg-yellow-400 text-blue-900 text-[10px] font-black px-2 py-1 rounded-md shadow-sm uppercase tracking-tighter alignwidth">
                                        Lead Trainer
                                    </div>
                                </div>
                                <div class="mb-4 top20">

                                    <h3 class="text-3xl md:text-4xl font-extrabold text-gray-900">Dr. Balaji Rao DG</h3>
                                </div>
                                <div class="w-16 h-1.5 bg-blue-600 mx-auto rounded-full mb-4"></div>
                            </div>

                            <!-- Panel of Trainers Divider -->
                            <div class="relative flex items-center px-12 mb-4">
                                <div class="flex-grow border-t border-gray-100"></div>
                                <span
                                    class="addcolors flex-shrink mx-4 text-gray-400 text-[10px] font-bold uppercase tracking-[0.2em]">Panel
                                    of Trainers</span>
                                <div class="flex-grow border-t border-gray-100"></div>
                            </div>

                            <!-- Panel of Trainers Section (Beautified Vertical) -->
                            <div class="p-8 md:p-12 pt-4 bg-white">
                                <div class="panel-trainers-container">
                                    <div class="panel-trainer-row">
                                        <div class="trainer-status-icon">
                                            <svg class="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                                                <path fill-rule="evenodd"
                                                    d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"
                                                    clip-rule="evenodd"></path>
                                            </svg>
                                        </div>
                                        <span>Venkitesh S. Iyer</span>
                                    </div>
                                    <div class="panel-trainer-row">
                                        <div class="trainer-status-icon">
                                            <svg class="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                                                <path fill-rule="evenodd"
                                                    d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"
                                                    clip-rule="evenodd"></path>
                                            </svg>
                                        </div>
                                        <span>Dr. Aiyappa</span>
                                    </div>
                                    <div class="panel-trainer-row">
                                        <div class="trainer-status-icon">
                                            <svg class="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                                                <path fill-rule="evenodd"
                                                    d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"
                                                    clip-rule="evenodd"></path>
                                            </svg>
                                        </div>
                                        <span>Dr. Alok Chajjer</span>
                                    </div>
                                    <div class="panel-trainer-row">
                                        <div class="trainer-status-icon">
                                            <svg class="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                                                <path fill-rule="evenodd"
                                                    d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"
                                                    clip-rule="evenodd"></path>
                                            </svg>
                                        </div>
                                        <span>Dr. Sathyanarayana</span>
                                    </div>
                                    <div class="panel-trainer-row">
                                        <div class="trainer-status-icon">
                                            <svg class="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                                                <path fill-rule="evenodd"
                                                    d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"
                                                    clip-rule="evenodd"></path>
                                            </svg>
                                        </div>
                                        <span>Bharath Kashyap</span>
                                    </div>
                                    <div class="panel-trainer-row">
                                        <div class="trainer-status-icon">
                                            <svg class="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                                                <path fill-rule="evenodd"
                                                    d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"
                                                    clip-rule="evenodd"></path>
                                            </svg>
                                        </div>
                                        <span>Prashanth Upadhyaya</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>


                </div>
            </div>
        </section>




        <!-- Course Investment -->
        <section id="pricing" class="topsection py-16 bg-gradient-to-br from-teal-50 to-gray-50">
            <div class="tf-container full mx-auto px-6">

                <div class="w-full">
                    <div class="rounded-2xl p-8 text-white text-center relative overflow-hidden"
                        style="background: linear-gradient(135deg, #0e6099, #24283E);">
                        <div
                            class="absolute top-4 right-4 bg-yellow-400 text-black px-4 py-2 rounded-full font-bold text-sm">
                            🔥 LIMITED OFFER
                        </div>
                        <h3 class="text-3xl font-bold mb-4 text-white">Pricing Structure </h3>
                        <div class="flex justify-center items-center gap-4 mb-6">
                            <div class="text-2xl line-through opacity-60">₹ 2999 per module + GST </div>
                            <div class="text-5xl font-bold">₹ 2199 per module + GST </div>
                        </div>


                        <div class="text-sm opacity-90 increasefont">
                            🔥 If registered for all five modules, the price will be <span id="registered-count">
                                Rs.8999 + GST; a discount of Rs.2000 </span>
                        </div>




                        <div class="bg-white/20 backdrop-blur-sm rounded-lg p-6 mb-8 reducebg">
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-left">
                                <div>✅ Stock Market Foundation</div>
                                <div>✅ Trading & Technical Analysis</div>
                                <div>✅ Investing & Fundamental Analysis</div>
                                <div>✅ Derivatives and Futures & Options</div>
                                <div>✅ Mutual Funds & ETFs(1 Year)</div>
                            </div>
                        </div>

                        <div class="mb-6">
                            <div class="text-yellow-300 font-bold text-xl mb-2">⚡ Price includes coffee/tea and
                                refreshments during the sessions</div>
                            <!--<div class="text-lg mb-4">Our 38th batch starts on 28<sup>th</sup> March, 2026</div>-->



                            <!-- Social Proof -->

                        </div>
                        <button
                            class="addbtns bg-white px-8 py-4 rounded-full text-xl font-bold hover:bg-gray-100 transition-colors pulse-glow"
                            style="color: #0e6099;" data-bs-toggle="modal" data-bs-target="#enrollModal">
                            🎯 Secure Your Spot Now!
                        </button>
                    </div>
                </div>
            </div>
        </section>




        <!-- 💬 What Our Students Say -->
        <section class="topsection py-16 bg-gradient-to-br from-blue-50 to-purple-50 testims">
            <div class="tf-container full mx-auto px-6">
                <div class="w-full">


                    <div class="flex flex-wrap justify-center gap-12 mb-16 thstwo">
                        <!-- Card 1: Offline -->
                        <div
                            class="bg-white rounded-3xl p-8 shadow-lg hover:shadow-2xl transition-all duration-300 w-full md:w-[calc(50%-30px)] lg:w-[480px] max-w-lg border border-blue-50">
                            <div class="flex items-center mb-6">
                                <div class="w-14 h-14 rounded-full flex items-center justify-center text-white shadow-lg itemicon"
                                    style="background: linear-gradient(135deg, #0e6099, #24283E);">
                                    <span class="text-2xl">🏫</span>
                                </div>
                                <div class="ml-8">
                                    <h4 class="font-bold text-xl text-gray-800 leading-tight">Scheduling of Offline
                                        Classes</h4>
                                    <div class="text-sm font-medium text-blue-600 tracking-wide uppercase mt-1">Modules
                                        1 to 5</div>
                                </div>
                            </div>
                            <div class="text-yellow-400 mb-5 flex space-x-1">
                                <span>⭐</span><span>⭐</span><span>⭐</span><span>⭐</span><span>⭐</span>
                            </div>
                            <div class="schedule-list space-y-5 mb-6">
                                <div
                                    class="schedule-item flex items-center p-4 bg-blue-50/40 rounded-2xl border border-blue-100/50 transition-all hover:bg-white hover:shadow-lg group">
                                    <div
                                        class="schedule-icon w-12 h-12 rounded-xl bg-blue-600 text-white flex items-center justify-center mr-5 shadow-md group-hover:scale-110 transition-transform">
                                        <span class="text-xs font-black">SAT</span>
                                    </div>
                                    <div>
                                        <div class="text-xs font-bold text-blue-600 uppercase tracking-widest mb-0.5">
                                            Saturday</div>
                                        <div class="text-lg text-gray-900 font-bold">2:00 PM — 5:15 PM</div>
                                    </div>
                                </div>

                                <div
                                    class="schedule-item flex items-center p-4 bg-blue-50/40 rounded-2xl border border-blue-100/50 transition-all hover:bg-white hover:shadow-lg group">
                                    <div
                                        class="schedule-icon w-12 h-12 rounded-xl bg-gradient-to-tr from-blue-700 to-indigo-900 text-white flex items-center justify-center mr-5 shadow-md group-hover:scale-110 transition-transform">
                                        <span class="text-xs font-black">SUN</span>
                                    </div>
                                    <div>
                                        <div class="text-xs font-bold text-indigo-600 uppercase tracking-widest mb-0.5">
                                            Sunday</div>
                                        <div class="text-lg text-gray-900 font-bold">10:00 AM — 1:15 PM</div>
                                    </div>
                                </div>

                                <div
                                    class="mt-6 flex items-center text-sm font-medium text-gray-600 bg-gray-50/80 p-4 rounded-xl border border-dashed border-gray-300">
                                    <span class="text-xl mr-3">📅</span>
                                    <span>5 modules delivered over 5 weekends</span>
                                </div>
                            </div>
                        </div>

                        <!-- Card 2: Online -->
                        <div
                            class="bg-white rounded-3xl p-8 shadow-lg hover:shadow-2xl transition-all duration-300 w-full md:w-[calc(50%-30px)] lg:w-[480px] max-w-lg border border-blue-50">
                            <div class="flex items-center mb-6">
                                <div class="w-14 h-14 rounded-full flex items-center justify-center text-white shadow-lg itemicon"
                                    style="background: linear-gradient(135deg, #0e6099, #24283E);">
                                    <span class="text-2xl">🌐</span>
                                </div>
                                <div class="ml-8">
                                    <h4 class="font-bold text-xl text-gray-800 leading-tight">Scheduling of Online
                                        Classes</h4>
                                    <div class="text-sm font-medium text-blue-600 tracking-wide uppercase mt-1">Weekday
                                        Batch</div>
                                </div>
                            </div>
                            <div class="text-yellow-400 mb-5 flex space-x-1">
                                <span>⭐</span><span>⭐</span><span>⭐</span><span>⭐</span><span>⭐</span>
                            </div>
                            <div class="schedule-list space-y-5 mb-6">
                                <div
                                    class="schedule-item flex items-center p-4 bg-blue-50/40 rounded-2xl border border-blue-100/50 transition-all hover:bg-white hover:shadow-lg group">
                                    <div
                                        class="schedule-icon w-12 h-12 rounded-xl bg-blue-600 text-white flex items-center justify-center mr-5 shadow-md group-hover:scale-110 transition-transform">
                                        <span class="text-xs font-black">M-T</span>
                                    </div>
                                    <div>
                                        <div class="text-xs font-bold text-blue-600 uppercase tracking-widest mb-0.5">
                                            Mondays to Thursdays</div>
                                        <div class="text-lg text-gray-900 font-bold">7:00 PM — 8:30 PM</div>
                                    </div>
                                </div>

                                <div
                                    class="mt-6 flex items-center text-sm font-medium text-gray-600 bg-gray-50/80 p-4 rounded-xl border border-dashed border-gray-300">
                                    <span class="text-xl mr-3">⏱️</span>
                                    <span>1.50 hours x 4 days per module</span>
                                </div>
                            </div>
                        </div>


                    </div>

                </div>
            </div>
        </section>






        <!-- Ready to Transform Your Future? -->
        <section class="topsection py-16 text-white buttns finalsz"
            style="background: linear-gradient(135deg, #0e6099, #24283E);">
            <div class="tf-container full mx-auto px-6 text-center">
                <h2 class="text-4xl font-bold mb-6 text-white">Live Streaming of the Stock Market</h2>
                <p class="text-xl mb-8 w-full">
                    Every Friday, we conduct live streaming of the stock market from 9.00 am to 11.15 am for those
                    <br /> who
                    want to learn and understand how the market functions in real time
                </p>
                <div class="flex flex-col md:flex-row gap-4 justify-center alignbtns">

                    <div class="col-md-12">
                        <button
                            class="bg-white px-8 py-4 rounded-full text-lg font-bold hover:bg-gray-100 transition-colors"
                            style="color: #0e6099;">
                            <a>A nominal fee of Rs.499 + GST per participant for this special live streaming session</a>

                        </button>
                    </div>


                </div>
            </div>
        </section>






        <!-- Enroll Now Modal (Themed) -->
        <div class="modal fade" id="enrollModal" tabindex="-1" aria-labelledby="enrollModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content premium-theme">
                    <!-- Header with Gradient -->
                    <div class="modal-header themed-header">
                        <div class="w-full text-center">
                            <h5 class="modal-title" id="enrollModalLabel">
                                Start your financial learning journey today 🚀
                            </h5>

                        </div>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"
                            style="right: 2rem !important; left: auto !important;"></button>
                    </div>

                    <div class="modal-body themed-body">
                        <div id="enrollForm">
                            <!-- Triple Field Row -->
                            <div class="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
                                <!-- Full Name -->
                                <div class="form-group">
                                    <label for="name" class="form-label themed-label text-left">Full Name</label>
                                    <input type="text" class="form-control premium-input" id="name"
                                        placeholder="John Doe" required>
                                </div>

                                <!-- Mobile Number -->
                                <div class="form-group">
                                    <label for="mobile" class="form-label themed-label text-left">Mobile Number</label>
                                    <input type="number" class="form-control premium-input" id="mobile"
                                        placeholder="98765 43210" maxlength="10"
                                        oninput="javascript: if (this.value.length > this.maxLength) this.value = this.value.slice(0, this.maxLength);"
                                        required>
                                </div>

                                <!-- Email Address -->
                                <div class="form-group">
                                    <label for="email" class="form-label themed-label text-left">Email Address</label>
                                    <input type="email" class="form-control premium-input" id="email"
                                        placeholder="name@email.com" required>
                                </div>
                            </div>

                            <!-- Action Buttons -->
                            <div class="flex flex-col md:flex-row gap-4 justify-end finalbutns">
                                <button type="button" class="btn-cancel w-full md:w-auto"
                                    data-bs-dismiss="modal">Later</button>
                                <button type="button" class="btn-submit w-full md:w-64" id="addItem">
                                    Secure My Spot 🎯
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>


        <!-- All ContenT Ends Here -->

        <?php
        include 'common/footer.php';
        include 'common/footerfiles.php';
        ?>
        <script>
            document.addEventListener('DOMContentLoaded', function () {
                const faqToggles = document.querySelectorAll('.faq-toggle');
                faqToggles.forEach(toggle => {
                    toggle.addEventListener('click', () => {
                        const content = toggle.nextElementSibling;
                        const icon = toggle.querySelector('span:last-child');

                        // Close all other FAQs
                        document.querySelectorAll('.faq-content').forEach(c => {
                            if (c !== content) {
                                c.classList.add('hidden');
                                c.previousElementSibling.querySelector('span:last-child').textContent = '+';
                            }
                        });

                        // Toggle current FAQ
                        content.classList.toggle('hidden');
                        icon.textContent = content.classList.contains('hidden') ? '+' : '-';
                    });
                });
            });
        </script>