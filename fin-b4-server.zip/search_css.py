
import os

files = [
    r"d:/xampp/htdocs/finatoniq/sample/Service Details 01 __ FinWice - Business & Finance Consulting - React Nextjs Template_files/9a4d224d4bafe09d.css",
    r"d:/xampp/htdocs/finatoniq/sample/Service Details 01 __ FinWice - Business & Finance Consulting - React Nextjs Template_files/b784873dca77473d.css"
]

targets = ["page-title", "bg-img-6", "breadkcum"]

for file_path in files:
    print(f"Scanning {os.path.basename(file_path)}...")
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
            for target in targets:
                index = content.find(target)
                if index != -1:
                    print(f"  FOUND {target} at index {index}")
                    # Print context (50 chars before and 200 after)
                    start = max(0, index - 50)
                    end = min(len(content), index + 500) # Increased context
                    print(f"  Context: ...{content[start:end]}...")
                else:
                    print(f"  {target} NOT FOUND")
    except Exception as e:
        print(f"  Error reading file: {e}")
