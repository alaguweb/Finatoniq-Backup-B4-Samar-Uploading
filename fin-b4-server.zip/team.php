<?php
include 'common/config.php';

$pageTitle = "Team - Finatoniq";
$pageMetaDesc = "Meet the team behind Finatoniq.";
$pageUrl = $base_url . "team.php";
$pageImage = $base_url . "assets/images/logo/logo.png";
$activeMenu = 'team';

// Layout Configuration
$showTopBar = true; // Sample has top bar
$headerClass = 'style-absolute'; // Sample has absolute header

include 'common/header.php';
include 'common/menu.php';

function getTeamMemberImage($id)
{
    $extensions = ['jpg', 'JPG', 'jpeg', 'JPEG', 'png', 'PNG'];
    $basePath = 'image/team/';

    foreach ($extensions as $ext) {
        if (file_exists($basePath . $id . '.' . $ext)) {
            return $basePath . $id . '.' . $ext;
        }
    }
    // Fallback to jpg if not found (or handle as needed)
    return $basePath . $id . '.jpg';
}
?>


<link rel="stylesheet" href="assets/css/pages.css">
<link rel="stylesheet" href="assets/css/innerpage.css">

<!-- Page Title / Banner -->
<div class="page-title style-1 bg-img-6">
    <div class="tf-container">
        <div class="page-title-content">
            <div class="breadkcum">
                <a class="caption-1 home" href="<?php echo $base_url; ?>">Homepage</a>

                <span class="arrow-svg">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                        <g clip-path="url(#clip0_9360_28061)">
                            <path d="M3.125 10H16.875" stroke="#A2A3AB" stroke-linecap="round" stroke-linejoin="round">
                            </path>
                            <path d="M11.25 4.375L16.875 10L11.25 15.625" stroke="#A2A3AB" stroke-linecap="round"
                                stroke-linejoin="round"></path>
                        </g>
                    </svg>
                </span>

            </div>
            <h2 class="title-page-title">Team</h2>
            <div class="sub-title body-2">

            </div>
        </div>
    </div>
</div>







<div class="main-content inner">
    <div class="tf-container tf-spacing-2">
        <h2 class="text-center mb-40" style="color: #24283e;">People Powering Finatoniq</h2>
        <div class="row row-cols-1 row-cols-sm-2 row-cols-lg-5 rg-40">
            <!-- Team Member 1 -->


            <!-- Team Member 2 -->
            <div class="col">
                <div class="flip-card">
                    <div class="flip-card-inner">
                        <div class="flip-card-front">
                            <img src="<?php echo getTeamMemberImage(2); ?>" alt="Giri Balasubramaniam">
                            <div class="front-active-content">
                                <h5>Giri Balasubramaniam</h5>
                                <a href="https://www.linkedin.com/in/giribalasubramaniam/overlay/about-this-profile/?lipi=urn%3Ali%3Apage%3Ad_flagship3_profile_view_base%3BkRBMv5UvS%2F6%2BAau1GFyWPQ%3D%3D"
                                    class="btn-linkedin-front" target="_blank">LinkedIn</a>
                            </div>
                        </div>
                        <div class="flip-card-back">
                            <h5>Giri Balasubramaniam</h5>

                            <a href="https://www.linkedin.com/in/giribalasubramaniam/overlay/about-this-profile/?lipi=urn%3Ali%3Apage%3Ad_flagship3_profile_view_base%3BkRBMv5UvS%2F6%2BAau1GFyWPQ%3D%3D"
                                class="btn-linkedin" target="_blank">
                                LinkedIn
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Team Member 3 -->
            <div class="col">
                <div class="flip-card">
                    <div class="flip-card-inner">
                        <div class="flip-card-front">
                            <img src="<?php echo getTeamMemberImage(3); ?>" alt="Krishan Sharma">
                            <div class="front-active-content">
                                <h5>Krishan Sharma</h5>
                                <a href="https://www.linkedin.com/in/krishan-sharma-a3ab5624/overlay/about-this-profile/?lipi=urn%3Ali%3Apage%3Ad_flagship3_profile_view_base%3BVnTtG5oGTM%2B7sSrxNghDWQ%3D%3D"
                                    class="btn-linkedin-front" target="_blank">LinkedIn</a>
                            </div>
                        </div>
                        <div class="flip-card-back">
                            <h5>Krishan Sharma</h5>

                            <a href="https://www.linkedin.com/in/krishan-sharma-a3ab5624/overlay/about-this-profile/?lipi=urn%3Ali%3Apage%3Ad_flagship3_profile_view_base%3BVnTtG5oGTM%2B7sSrxNghDWQ%3D%3D"
                                class="btn-linkedin" target="_blank">
                                LinkedIn
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Team Member 4 -->
            <div class="col">
                <div class="flip-card">
                    <div class="flip-card-inner">
                        <div class="flip-card-front">
                            <img src="<?php echo getTeamMemberImage(4); ?>" alt="Prasad Ramani">
                            <div class="front-active-content">
                                <h5>Prasad Ramani</h5>
                                <a href="https://www.linkedin.com/in/prasadramani/overlay/about-this-profile/?lipi=urn%3Ali%3Apage%3Ad_flagship3_profile_view_base%3B8n5z%2BcDbQUOFCG0O833vfQ%3D%3D"
                                    class="btn-linkedin-front" target="_blank">LinkedIn</a>
                            </div>
                        </div>
                        <div class="flip-card-back">
                            <h5>Prasad Ramani</h5>

                            <a href="https://www.linkedin.com/in/prasadramani/overlay/about-this-profile/?lipi=urn%3Ali%3Apage%3Ad_flagship3_profile_view_base%3B8n5z%2BcDbQUOFCG0O833vfQ%3D%3D"
                                class="btn-linkedin" target="_blank">
                                LinkedIn
                            </a>
                        </div>
                    </div>
                </div>
            </div>





            <!-- Team Member 5 -->
            <div class="col">
                <div class="flip-card">
                    <div class="flip-card-inner">
                        <div class="flip-card-front">
                            <img src="<?php echo getTeamMemberImage(5); ?>" alt="Dr Balaji Rao DG">
                            <div class="front-active-content">
                                <h5>Dr Balaji Rao DG</h5>
                                <a href="https://www.linkedin.com/in/dr-balaji-rao-dg-82a47023/overlay/about-this-profile/?lipi=urn%3Ali%3Apage%3Ad_flagship3_profile_view_base%3BIxXinG%2FUS5Kr%2FsbLIaTrGg%3D%3D"
                                    class="btn-linkedin-front" target="_blank">LinkedIn</a>
                            </div>
                        </div>
                        <div class="flip-card-back">
                            <h5>Dr Balaji Rao DG</h5>

                            <a href="https://www.linkedin.com/in/dr-balaji-rao-dg-82a47023/overlay/about-this-profile/?lipi=urn%3Ali%3Apage%3Ad_flagship3_profile_view_base%3BIxXinG%2FUS5Kr%2FsbLIaTrGg%3D%3D"
                                class="btn-linkedin" target="_blank">
                                LinkedIn
                            </a>
                        </div>
                    </div>
                </div>
            </div>


            <div class="col">
                <div class="flip-card">
                    <div class="flip-card-inner">
                        <div class="flip-card-front">
                            <img src="<?php echo getTeamMemberImage(10); ?>" alt="Nisary Mahesh">
                            <div class="front-active-content">
                                <h5>Nisary Mahesh</h5>
                                <a href="https://www.linkedin.com/in/nisarymahesh/overlay/about-this-profile/?lipi=urn%3Ali%3Apage%3Ad_flagship3_profile_view_base%3BmPFLa9m9S2SklPxe0BDp6g%3D%3D"
                                    class="btn-linkedin-front" target="_blank">LinkedIn</a>
                            </div>
                        </div>
                        <div class="flip-card-back">
                            <h5>Nisary Mahesh</h5>

                            <a href="https://www.linkedin.com/in/nisarymahesh/overlay/about-this-profile/?lipi=urn%3Ali%3Apage%3Ad_flagship3_profile_view_base%3BmPFLa9m9S2SklPxe0BDp6g%3D%3D"
                                class="btn-linkedin" target="_blank">
                                LinkedIn
                            </a>
                        </div>
                    </div>
                </div>
            </div>



            <!-- Team Member 6 -->
            <div class="col">
                <div class="flip-card">
                    <div class="flip-card-inner">
                        <div class="flip-card-front">
                            <img src="<?php echo getTeamMemberImage(6); ?>" alt="Harish Rao">
                            <div class="front-active-content">
                                <h5>Harish Rao</h5>
                                <a href="https://www.linkedin.com/in/harish-rao-83a81a14/overlay/about-this-profile/?lipi=urn%3Ali%3Apage%3Ad_flagship3_profile_view_base%3BDb0AJ6eOSgmydUXh8x%2F%2Bhw%3D%3D"
                                    class="btn-linkedin-front" target="_blank">LinkedIn</a>
                            </div>
                        </div>
                        <div class="flip-card-back">
                            <h5>Harish Rao</h5>

                            <a href="https://www.linkedin.com/in/harish-rao-83a81a14/overlay/about-this-profile/?lipi=urn%3Ali%3Apage%3Ad_flagship3_profile_view_base%3BDb0AJ6eOSgmydUXh8x%2F%2Bhw%3D%3D"
                                class="btn-linkedin" target="_blank">
                                LinkedIn
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Team Member 7 -->
            <div class="col">
                <div class="flip-card">
                    <div class="flip-card-inner">
                        <div class="flip-card-front">
                            <img src="<?php echo getTeamMemberImage(7); ?>" alt="Venkitesh Iyer">
                            <div class="front-active-content">
                                <h5>Venkitesh Iyer</h5>
                                <a href="https://www.linkedin.com/in/venkitesh-subramonia-iyer-cfa-8b611216/overlay/about-this-profile/?lipi=urn%3Ali%3Apage%3Ad_flagship3_profile_view_base%3BYyK%2FmL%2BNQXuq6ohdhA7X0g%3D%3D"
                                    class="btn-linkedin-front" target="_blank">LinkedIn</a>
                            </div>
                        </div>
                        <div class="flip-card-back">
                            <h5>Venkitesh Iyer</h5>

                            <a href="https://www.linkedin.com/in/venkitesh-subramonia-iyer-cfa-8b611216/overlay/about-this-profile/?lipi=urn%3Ali%3Apage%3Ad_flagship3_profile_view_base%3BYyK%2FmL%2BNQXuq6ohdhA7X0g%3D%3D"
                                class="btn-linkedin" target="_blank">
                                LinkedIn
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Team Member 8 -->
            <div class="col">
                <div class="flip-card">
                    <div class="flip-card-inner">
                        <div class="flip-card-front">
                            <img src="<?php echo getTeamMemberImage(8); ?>" alt="Kashyap Kompella">
                            <div class="front-active-content">
                                <h5>Kashyap Kompella</h5>
                                <a href="https://www.linkedin.com/in/kashyapkompella/overlay/about-this-profile/?lipi=urn%3Ali%3Apage%3Ad_flagship3_profile_view_base%3BxKkbjidEQM%2B9LG59tvVBJQ%3D%3D"
                                    class="btn-linkedin-front" target="_blank">LinkedIn</a>
                            </div>
                        </div>
                        <div class="flip-card-back">
                            <h5>Kashyap Kompella</h5>

                            <a href="https://www.linkedin.com/in/kashyapkompella/overlay/about-this-profile/?lipi=urn%3Ali%3Apage%3Ad_flagship3_profile_view_base%3BxKkbjidEQM%2B9LG59tvVBJQ%3D%3D"
                                class="btn-linkedin" target="_blank">
                                LinkedIn
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Team Member 9 -->
            <div class="col">
                <div class="flip-card">
                    <div class="flip-card-inner">
                        <div class="flip-card-front">
                            <img src="<?php echo getTeamMemberImage(9); ?>" alt="Amit Trivedi">
                            <div class="front-active-content">
                                <h5>Amit Trivedi</h5>
                                <a href="https://www.linkedin.com/in/amitmtrivedi/overlay/about-this-profile/?lipi=urn%3Ali%3Apage%3Ad_flagship3_profile_view_base%3BSOG%2FB3CrRlWd8vdnBnOnmg%3D%3D"
                                    class="btn-linkedin-front" target="_blank">LinkedIn</a>
                            </div>
                        </div>
                        <div class="flip-card-back">
                            <h5>Amit Trivedi</h5>

                            <a href="https://www.linkedin.com/in/amitmtrivedi/overlay/about-this-profile/?lipi=urn%3Ali%3Apage%3Ad_flagship3_profile_view_base%3BSOG%2FB3CrRlWd8vdnBnOnmg%3D%3D"
                                class="btn-linkedin" target="_blank">
                                LinkedIn
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Team Member 10 -->




            <div class="col">
                <div class="flip-card">
                    <div class="flip-card-inner">
                        <div class="flip-card-front">
                            <img src="<?php echo getTeamMemberImage(1); ?>" alt="Srikanth G">
                            <div class="front-active-content">
                                <h5> G Srikanth</h5>
                                <a href="https://www.linkedin.com/in/srikanthg701222/overlay/about-this-profile/?lipi=urn%3Ali%3Apage%3Ad_flagship3_profile_view_base%3BgZ%2BZGPPASbqAKmohmJFUAQ%3D%3D"
                                    class="btn-linkedin-front" target="_blank">LinkedIn</a>
                            </div>
                        </div>
                        <div class="flip-card-back">
                            <h5>G Srikanth </h5>

                            <a href="https://www.linkedin.com/in/srikanthg701222/overlay/about-this-profile/?lipi=urn%3Ali%3Apage%3Ad_flagship3_profile_view_base%3BgZ%2BZGPPASbqAKmohmJFUAQ%3D%3D"
                                class="btn-linkedin" target="_blank">
                                LinkedIn
                            </a>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>







<?php
include 'common/footer.php';
include 'common/footerfiles.php';
?>