
$css = @"

/* Custom Banner Update */
.page-title.bg-img-6 {
    background-image: url(../../image/page-title-home-1-custom.jpg) !important;
}

.page-title-inner.img-h1-1 {
    background-image: url(../../image/page-title-home-1-custom.jpg) !important;
    background-size: cover;
    background-position: center center;
    background-repeat: no-repeat;
}
"@

Add-Content -Path "d:/xampp/htdocs/finatoniq/assets/css/pages.css" -Value $css
Write-Output "Banner CSS updated successfully."
