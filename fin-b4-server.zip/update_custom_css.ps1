
$css = @"

/* Custom Banner Update for Homepage */
.page-title-inner.img-h1-1 {
    background-image: url(../../image/page-title-home-1.034313cd.jpg) !important;
    background-size: cover;
    background-position: center center;
    background-repeat: no-repeat;
}
"@

Add-Content -Path "d:/xampp/htdocs/finatoniq/assets/css/custom.css" -Value $css
Write-Output "Homepage banner CSS added to custom.css."
