
$css = @"

/* Update opacity for Investment Solutions Banner */
.page-title.bg-img-6::before {
    opacity: 0.3 !important;
}
"@

Add-Content -Path "d:/xampp/htdocs/finatoniq/assets/css/pages.css" -Value $css
Write-Output "Breadcrumb opacity updated to 0.3."
