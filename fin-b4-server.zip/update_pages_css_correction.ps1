
$css = @"

/* Ensure Investment Solutions page also uses the specific image requested by user */
.page-title.bg-img-6 {
    background-image: url(../../image/page-title-home-1.034313cd.jpg) !important;
}
"@

Add-Content -Path "d:/xampp/htdocs/finatoniq/assets/css/pages.css" -Value $css
Write-Output "Investment Solutions banner CSS updated in pages.css."
