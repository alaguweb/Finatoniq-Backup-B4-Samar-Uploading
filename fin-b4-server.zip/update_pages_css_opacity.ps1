
$css = @"

/* Custom Banner Update for Investment Solutions - Page Title 7 with Opacity */
.page-title.bg-img-6 {
    background-image: none !important;
    position: relative;
    z-index: 1;
}

.page-title.bg-img-6::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-image: url(../../image/page-title/page-title-7.jpg) !important;
    background-size: cover;
    background-position: center center;
    background-repeat: no-repeat;
    background-color: transparent !important; /* Override previous blue overlay */
    opacity: 0.5;
    z-index: -1;
}
"@

Add-Content -Path "d:/xampp/htdocs/finatoniq/assets/css/pages.css" -Value $css
Write-Output "Investment Solutions banner CSS updated with page-title-7 and opacity."
